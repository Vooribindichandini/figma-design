(function(B) {
    typeof define == "function" && define.amd ? define(B) : B()
})(function() {
    "use strict";
    var pg = Object.defineProperty;
    var hg = (B, We, St) => We in B ? pg(B, We, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: St
    }) : B[We] = St;
    var me = (B, We, St) => (hg(B, typeof We != "symbol" ? We + "" : We, St), St);
    var B = typeof globalThis < "u" ? globalThis : typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {};

    function We(e) {
        return e && e.__esModule && Object.prototype.hasOwnProperty.call(e, "default") ? e.default : e
    }

    function St(e) {
        var t = e.default;
        if (typeof t == "function") {
            var n = function() {
                return t.apply(this, arguments)
            };
            n.prototype = t.prototype
        } else n = {};
        return Object.defineProperty(n, "__esModule", {
            value: !0
        }), Object.keys(e).forEach(function(r) {
            var i = Object.getOwnPropertyDescriptor(e, r);
            Object.defineProperty(n, r, i.get ? i : {
                enumerable: !0,
                get: function() {
                    return e[r]
                }
            })
        }), n
    }
    var ae = {},
        It = {};
    Object.defineProperty(It, "__esModule", {
        value: !0
    });
    var ti = function() {
        function e() {}
        return e.prototype.handleError = function(t) {}, e
    }();
    It.NoopErrorHandler = ti;
    var ni = new ti;

    function hc(e) {
        ni = e
    }
    It.setErrorHandler = hc;

    function vc() {
        return ni
    }
    It.getErrorHandler = vc;

    function mc() {
        ni = new ti
    }
    It.resetErrorHandler = mc;
    var ri = {};
    (function(e) {
        Object.defineProperty(e, "__esModule", {
                value: !0
            }),
            function(t) {
                t[t.NOTSET = 0] = "NOTSET", t[t.DEBUG = 1] = "DEBUG", t[t.INFO = 2] = "INFO", t[t.WARNING = 3] = "WARNING", t[t.ERROR = 4] = "ERROR"
            }(e.LogLevel || (e.LogLevel = {}))
    })(ri);
    var ut = {},
        $t = {},
        Zn = {
            exports: {}
        },
        aa = typeof crypto < "u" && crypto.getRandomValues && crypto.getRandomValues.bind(crypto) || typeof msCrypto < "u" && typeof window.msCrypto.getRandomValues == "function" && msCrypto.getRandomValues.bind(msCrypto);
    if (aa) {
        var sa = new Uint8Array(16);
        Zn.exports = function() {
            return aa(sa), sa
        }
    } else {
        var la = new Array(16);
        Zn.exports = function() {
            for (var t = 0, n; t < 16; t++)(t & 3) === 0 && (n = Math.random() * 4294967296), la[t] = n >>> ((t & 3) << 3) & 255;
            return la
        }
    }
    for (var ua = [], Xn = 0; Xn < 256; ++Xn) ua[Xn] = (Xn + 256).toString(16).substr(1);

    function gc(e, t) {
        var n = t || 0,
            r = ua;
        return [r[e[n++]], r[e[n++]], r[e[n++]], r[e[n++]], "-", r[e[n++]], r[e[n++]], "-", r[e[n++]], r[e[n++]], "-", r[e[n++]], r[e[n++]], "-", r[e[n++]], r[e[n++]], r[e[n++]], r[e[n++]], r[e[n++]], r[e[n++]]].join("")
    }
    var ca = gc,
        _c = Zn.exports,
        yc = ca,
        da, ii, oi = 0,
        ai = 0;

    function wc(e, t, n) {
        var r = t && n || 0,
            i = t || [];
        e = e || {};
        var o = e.node || da,
            a = e.clockseq !== void 0 ? e.clockseq : ii;
        if (o == null || a == null) {
            var s = _c();
            o == null && (o = da = [s[0] | 1, s[1], s[2], s[3], s[4], s[5]]), a == null && (a = ii = (s[6] << 8 | s[7]) & 16383)
        }
        var l = e.msecs !== void 0 ? e.msecs : new Date().getTime(),
            u = e.nsecs !== void 0 ? e.nsecs : ai + 1,
            c = l - oi + (u - ai) / 1e4;
        if (c < 0 && e.clockseq === void 0 && (a = a + 1 & 16383), (c < 0 || l > oi) && e.nsecs === void 0 && (u = 0), u >= 1e4) throw new Error("uuid.v1(): Can't create more than 10M uuids/sec");
        oi = l, ai = u, ii = a, l += 122192928e5;
        var f = ((l & 268435455) * 1e4 + u) % 4294967296;
        i[r++] = f >>> 24 & 255, i[r++] = f >>> 16 & 255, i[r++] = f >>> 8 & 255, i[r++] = f & 255;
        var d = l / 4294967296 * 1e4 & 268435455;
        i[r++] = d >>> 8 & 255, i[r++] = d & 255, i[r++] = d >>> 24 & 15 | 16, i[r++] = d >>> 16 & 255, i[r++] = a >>> 8 | 128, i[r++] = a & 255;
        for (var p = 0; p < 6; ++p) i[r + p] = o[p];
        return t || yc(i)
    }
    var bc = wc,
        Ec = Zn.exports,
        xc = ca;

    function Cc(e, t, n) {
        var r = t && n || 0;
        typeof e == "string" && (t = e === "binary" ? new Array(16) : null, e = null), e = e || {};
        var i = e.random || (e.rng || Ec)();
        if (i[6] = i[6] & 15 | 64, i[8] = i[8] & 63 | 128, t)
            for (var o = 0; o < 16; ++o) t[r + o] = i[o];
        return t || xc(i)
    }
    var Sc = Cc,
        Ic = bc,
        fa = Sc,
        si = fa;
    si.v1 = Ic, si.v4 = fa;
    var kc = si;
    (function(e) {
        Object.defineProperty(e, "__esModule", {
            value: !0
        });
        var t = kc;

        function n() {
            return t.v4()
        }
        e.generateUUID = n;

        function r() {
            return new Date().getTime()
        }
        e.getTimestamp = r;

        function i(f, d) {
            for (var p = !1, h = Object.keys(f), v = 0; v < h.length; v++)
                if (d === f[h[v]]) {
                    p = !0;
                    break
                }
            return p
        }
        e.isValidEnum = i;

        function o(f, d) {
            var p = {};
            return f.forEach(function(h) {
                var v = d(h);
                p[v] = p[v] || [], p[v].push(h)
            }), a(p)
        }
        e.groupBy = o;

        function a(f) {
            return Object.keys(f).map(function(d) {
                return f[d]
            })
        }
        e.objectValues = a;

        function s(f) {
            return Object.keys(f).map(function(d) {
                return [d, f[d]]
            })
        }
        e.objectEntries = s;

        function l(f, d) {
            for (var p, h = 0, v = f; h < v.length; h++) {
                var m = v[h];
                if (d(m)) {
                    p = m;
                    break
                }
            }
            return p
        }
        e.find = l;

        function u(f, d) {
            var p = {};
            return f.forEach(function(h) {
                var v = d(h);
                p[v] = h
            }), p
        }
        e.keyBy = u;

        function c(f) {
            for (var d = [], p = 1; p < arguments.length; p++) d[p - 1] = arguments[p];
            var h = 0;
            return f.replace(/%s/g, function() {
                var v = d[h++],
                    m = typeof v;
                return m === "function" ? v() : m === "string" ? v : String(v)
            })
        }
        e.sprintf = c,
            function(f) {
                f.ACTIVATE = "ACTIVATE:experiment, user_id,attributes, variation, event", f.DECISION = "DECISION:type, userId, attributes, decisionInfo", f.LOG_EVENT = "LOG_EVENT:logEvent", f.OPTIMIZELY_CONFIG_UPDATE = "OPTIMIZELY_CONFIG_UPDATE", f.TRACK = "TRACK:event_key, user_id, attributes, event_tags, event"
            }(e.NOTIFICATION_TYPES || (e.NOTIFICATION_TYPES = {}))
    })($t);
    var Tc = B && B.__spreadArrays || function() {
        for (var e = 0, t = 0, n = arguments.length; t < n; t++) e += arguments[t].length;
        for (var r = Array(e), i = 0, t = 0; t < n; t++)
            for (var o = arguments[t], a = 0, s = o.length; a < s; a++, i++) r[i] = o[a];
        return r
    };
    Object.defineProperty(ut, "__esModule", {
        value: !0
    });
    var Lc = It,
        Jn = $t,
        ne = ri,
        pa = {
            NOTSET: 0,
            DEBUG: 1,
            INFO: 2,
            WARNING: 3,
            ERROR: 4
        };

    function li(e) {
        return typeof e != "string" || (e = e.toUpperCase(), e === "WARN" && (e = "WARNING"), !pa[e]) ? e : pa[e]
    }
    var ha = function() {
            function e() {
                this.defaultLoggerFacade = new va, this.loggers = {}
            }
            return e.prototype.getLogger = function(t) {
                return t ? (this.loggers[t] || (this.loggers[t] = new va({
                    messagePrefix: t
                })), this.loggers[t]) : this.defaultLoggerFacade
            }, e
        }(),
        Rc = function() {
            function e(t) {
                t === void 0 && (t = {}), this.logLevel = ne.LogLevel.NOTSET, t.logLevel !== void 0 && Jn.isValidEnum(ne.LogLevel, t.logLevel) && this.setLogLevel(t.logLevel), this.logToConsole = t.logToConsole !== void 0 ? !!t.logToConsole : !0, this.prefix = t.prefix !== void 0 ? t.prefix : "[OPTIMIZELY]"
            }
            return e.prototype.log = function(t, n) {
                if (!(!this.shouldLog(t) || !this.logToConsole)) {
                    var r = this.prefix + " - " + this.getLogLevelName(t) + " " + this.getTime() + " " + n;
                    this.consoleLog(t, [r])
                }
            }, e.prototype.setLogLevel = function(t) {
                t = li(t), !Jn.isValidEnum(ne.LogLevel, t) || t === void 0 ? this.logLevel = ne.LogLevel.ERROR : this.logLevel = t
            }, e.prototype.getTime = function() {
                return new Date().toISOString()
            }, e.prototype.shouldLog = function(t) {
                return t >= this.logLevel
            }, e.prototype.getLogLevelName = function(t) {
                switch (t) {
                    case ne.LogLevel.DEBUG:
                        return "DEBUG";
                    case ne.LogLevel.INFO:
                        return "INFO ";
                    case ne.LogLevel.WARNING:
                        return "WARN ";
                    case ne.LogLevel.ERROR:
                        return "ERROR";
                    default:
                        return "NOTSET"
                }
            }, e.prototype.consoleLog = function(t, n) {
                switch (t) {
                    case ne.LogLevel.DEBUG:
                        console.log.apply(console, n);
                        break;
                    case ne.LogLevel.INFO:
                        console.info.apply(console, n);
                        break;
                    case ne.LogLevel.WARNING:
                        console.warn.apply(console, n);
                        break;
                    case ne.LogLevel.ERROR:
                        console.error.apply(console, n);
                        break;
                    default:
                        console.log.apply(console, n)
                }
            }, e
        }();
    ut.ConsoleLogHandler = Rc;
    var vn = ne.LogLevel.NOTSET,
        ui = null,
        va = function() {
            function e(t) {
                t === void 0 && (t = {}), this.messagePrefix = "", t.messagePrefix && (this.messagePrefix = t.messagePrefix)
            }
            return e.prototype.log = function(t, n) {
                for (var r = [], i = 2; i < arguments.length; i++) r[i - 2] = arguments[i];
                this.internalLog(li(t), {
                    message: n,
                    splat: r
                })
            }, e.prototype.info = function(t) {
                for (var n = [], r = 1; r < arguments.length; r++) n[r - 1] = arguments[r];
                this.namedLog(ne.LogLevel.INFO, t, n)
            }, e.prototype.debug = function(t) {
                for (var n = [], r = 1; r < arguments.length; r++) n[r - 1] = arguments[r];
                this.namedLog(ne.LogLevel.DEBUG, t, n)
            }, e.prototype.warn = function(t) {
                for (var n = [], r = 1; r < arguments.length; r++) n[r - 1] = arguments[r];
                this.namedLog(ne.LogLevel.WARNING, t, n)
            }, e.prototype.error = function(t) {
                for (var n = [], r = 1; r < arguments.length; r++) n[r - 1] = arguments[r];
                this.namedLog(ne.LogLevel.ERROR, t, n)
            }, e.prototype.format = function(t) {
                return (this.messagePrefix ? this.messagePrefix + ": " : "") + Jn.sprintf.apply(void 0, Tc([t.message], t.splat))
            }, e.prototype.internalLog = function(t, n) {
                !ui || t < vn || (ui.log(t, this.format(n)), n.error && n.error instanceof Error && Lc.getErrorHandler().handleError(n.error))
            }, e.prototype.namedLog = function(t, n, r) {
                var i;
                if (n instanceof Error) {
                    i = n, n = i.message, this.internalLog(t, {
                        error: i,
                        message: n,
                        splat: r
                    });
                    return
                }
                if (r.length === 0) {
                    this.internalLog(t, {
                        message: n,
                        splat: r
                    });
                    return
                }
                var o = r[r.length - 1];
                o instanceof Error && (i = o, r.splice(-1)), this.internalLog(t, {
                    message: n,
                    error: i,
                    splat: r
                })
            }, e
        }(),
        ma = new ha;

    function Ac(e) {
        return ma.getLogger(e)
    }
    ut.getLogger = Ac;

    function Oc(e) {
        ui = e
    }
    ut.setLogHandler = Oc;

    function Dc(e) {
        e = li(e), !Jn.isValidEnum(ne.LogLevel, e) || e === void 0 ? vn = ne.LogLevel.ERROR : vn = e
    }
    ut.setLogLevel = Dc;

    function Uc() {
        return vn
    }
    ut.getLogLevel = Uc;

    function Pc() {
        ma = new ha, vn = ne.LogLevel.NOTSET
    }
    ut.resetLogger = Pc,
        function(e) {
            function t(n) {
                for (var r in n) e.hasOwnProperty(r) || (e[r] = n[r])
            }
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), t(It), t(ri), t(ut)
        }(ae);
    var Nc = {},
        mn = {};
    Object.defineProperty(mn, "__esModule", {
        value: !0
    }), mn.areEventContextsEqual = void 0;

    function Mc(e, t) {
        var n = e.context,
            r = t.context;
        return n.accountId === r.accountId && n.projectId === r.projectId && n.clientName === r.clientName && n.clientVersion === r.clientVersion && n.revision === r.revision && n.anonymizeIP === r.anonymizeIP && n.botFiltering === r.botFiltering
    }
    mn.areEventContextsEqual = Mc;
    var ci = {},
        Gt = {};
    Object.defineProperty(Gt, "__esModule", {
        value: !0
    }), Gt.DefaultEventQueue = Gt.SingleEventQueue = void 0;
    var jc = ae,
        Vc = jc.getLogger("EventProcessor"),
        Fc = function() {
            function e(t) {
                var n = t.timeout,
                    r = t.callback;
                this.timeout = Math.max(n, 0), this.callback = r
            }
            return e.prototype.start = function() {
                this.timeoutId = setTimeout(this.callback, this.timeout)
            }, e.prototype.refresh = function() {
                this.stop(), this.start()
            }, e.prototype.stop = function() {
                this.timeoutId && clearTimeout(this.timeoutId)
            }, e
        }(),
        Bc = function() {
            function e(t) {
                var n = t.sink;
                this.sink = n
            }
            return e.prototype.start = function() {}, e.prototype.stop = function() {
                return Promise.resolve()
            }, e.prototype.enqueue = function(t) {
                this.sink([t])
            }, e
        }();
    Gt.SingleEventQueue = Bc;
    var Hc = function() {
        function e(t) {
            var n = t.flushInterval,
                r = t.maxQueueSize,
                i = t.sink,
                o = t.batchComparator;
            this.buffer = [], this.maxQueueSize = Math.max(r, 1), this.sink = i, this.batchComparator = o, this.timer = new Fc({
                callback: this.flush.bind(this),
                timeout: n
            }), this.started = !1
        }
        return e.prototype.start = function() {
            this.started = !0
        }, e.prototype.stop = function() {
            this.started = !1;
            var t = this.sink(this.buffer);
            return this.buffer = [], this.timer.stop(), t
        }, e.prototype.enqueue = function(t) {
            if (!this.started) {
                Vc.warn("Queue is stopped, not accepting event");
                return
            }
            var n = this.buffer[0];
            n && !this.batchComparator(n, t) && this.flush(), this.buffer.length === 0 && this.timer.refresh(), this.buffer.push(t), this.buffer.length >= this.maxQueueSize && this.flush()
        }, e.prototype.flush = function() {
            this.sink(this.buffer), this.buffer = [], this.timer.stop()
        }, e
    }();
    Gt.DefaultEventQueue = Hc,
        function(e) {
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.sendEventNotification = e.getQueue = e.validateAndGetBatchSize = e.validateAndGetFlushInterval = e.DEFAULT_BATCH_SIZE = e.DEFAULT_FLUSH_INTERVAL = void 0;
            var t = Gt,
                n = ae,
                r = $t;
            e.DEFAULT_FLUSH_INTERVAL = 3e4, e.DEFAULT_BATCH_SIZE = 10;
            var i = n.getLogger("EventProcessor");

            function o(u) {
                return u <= 0 && (i.warn("Invalid flushInterval " + u + ", defaulting to " + e.DEFAULT_FLUSH_INTERVAL), u = e.DEFAULT_FLUSH_INTERVAL), u
            }
            e.validateAndGetFlushInterval = o;

            function a(u) {
                return u = Math.floor(u), u < 1 && (i.warn("Invalid batchSize " + u + ", defaulting to " + e.DEFAULT_BATCH_SIZE), u = e.DEFAULT_BATCH_SIZE), u = Math.max(1, u), u
            }
            e.validateAndGetBatchSize = a;

            function s(u, c, f, d) {
                var p;
                return u > 1 ? p = new t.DefaultEventQueue({
                    flushInterval: c,
                    maxQueueSize: u,
                    sink: f,
                    batchComparator: d
                }) : p = new t.SingleEventQueue({
                    sink: f
                }), p
            }
            e.getQueue = s;

            function l(u, c) {
                u && u.sendNotifications(r.NOTIFICATION_TYPES.LOG_EVENT, c)
            }
            e.sendEventNotification = l
        }(ci);
    var ga = {};
    Object.defineProperty(ga, "__esModule", {
        value: !0
    });
    var _a = {};
    Object.defineProperty(_a, "__esModule", {
        value: !0
    });
    var qt = {},
        er = {};
    Object.defineProperty(er, "__esModule", {
        value: !0
    }), er.LocalStorageStore = void 0;
    var Kc = $t,
        $c = ae,
        ya = $c.getLogger("EventProcessor"),
        Gc = function() {
            function e(t) {
                var n = t.key,
                    r = t.maxValues,
                    i = r === void 0 ? 1e3 : r;
                this.LS_KEY = n, this.maxValues = i
            }
            return e.prototype.get = function(t) {
                return this.getMap()[t] || null
            }, e.prototype.set = function(t, n) {
                var r = this.getMap();
                r[t] = n, this.replace(r)
            }, e.prototype.remove = function(t) {
                var n = this.getMap();
                delete n[t], this.replace(n)
            }, e.prototype.values = function() {
                return Kc.objectValues(this.getMap())
            }, e.prototype.clear = function() {
                this.replace({})
            }, e.prototype.replace = function(t) {
                try {
                    window.localStorage && localStorage.setItem(this.LS_KEY, JSON.stringify(t)), this.clean()
                } catch (n) {
                    ya.error(n)
                }
            }, e.prototype.clean = function() {
                var t = this.getMap(),
                    n = Object.keys(t),
                    r = n.length - this.maxValues;
                if (!(r < 1)) {
                    var i = n.map(function(a) {
                        return {
                            key: a,
                            value: t[a]
                        }
                    });
                    i.sort(function(a, s) {
                        return a.value.timestamp - s.value.timestamp
                    });
                    for (var o = 0; o < r; o++) delete t[i[o].key];
                    this.replace(t)
                }
            }, e.prototype.getMap = function() {
                try {
                    var t = window.localStorage && localStorage.getItem(this.LS_KEY);
                    if (t) return JSON.parse(t) || {}
                } catch (n) {
                    ya.error(n)
                }
                return {}
            }, e
        }();
    er.LocalStorageStore = Gc;
    var qc = B && B.__extends || function() {
        var e = function(t, n) {
            return e = Object.setPrototypeOf || {
                __proto__: []
            }
            instanceof Array && function(r, i) {
                r.__proto__ = i
            } || function(r, i) {
                for (var o in i) Object.prototype.hasOwnProperty.call(i, o) && (r[o] = i[o])
            }, e(t, n)
        };
        return function(t, n) {
            e(t, n);

            function r() {
                this.constructor = t
            }
            t.prototype = n === null ? Object.create(n) : (r.prototype = n.prototype, new r)
        }
    }();
    Object.defineProperty(qt, "__esModule", {
        value: !0
    }), qt.LocalStoragePendingEventsDispatcher = qt.PendingEventsDispatcher = void 0;
    var zc = ae,
        Wc = er,
        wa = $t,
        Yc = zc.getLogger("EventProcessor"),
        ba = function() {
            function e(t) {
                var n = t.eventDispatcher,
                    r = t.store;
                this.dispatcher = n, this.store = r
            }
            return e.prototype.dispatchEvent = function(t, n) {
                this.send({
                    uuid: wa.generateUUID(),
                    timestamp: wa.getTimestamp(),
                    request: t
                }, n)
            }, e.prototype.sendPendingEvents = function() {
                var t = this,
                    n = this.store.values();
                Yc.debug("Sending %s pending events from previous page", n.length), n.forEach(function(r) {
                    try {
                        t.send(r, function() {})
                    } catch {}
                })
            }, e.prototype.send = function(t, n) {
                var r = this;
                this.store.set(t.uuid, t), this.dispatcher.dispatchEvent(t.request, function(i) {
                    r.store.remove(t.uuid), n(i)
                })
            }, e
        }();
    qt.PendingEventsDispatcher = ba;
    var Qc = function(e) {
        qc(t, e);

        function t(n) {
            var r = n.eventDispatcher;
            return e.call(this, {
                eventDispatcher: r,
                store: new Wc.LocalStorageStore({
                    maxValues: 100,
                    key: "fs_optly_pending_events"
                })
            }) || this
        }
        return t
    }(ba);
    qt.LocalStoragePendingEventsDispatcher = Qc;
    var Te = {},
        di = B && B.__assign || function() {
            return di = Object.assign || function(e) {
                for (var t, n = 1, r = arguments.length; n < r; n++) {
                    t = arguments[n];
                    for (var i in t) Object.prototype.hasOwnProperty.call(t, i) && (e[i] = t[i])
                }
                return e
            }, di.apply(this, arguments)
        };
    Object.defineProperty(Te, "__esModule", {
        value: !0
    }), Te.formatEvents = Te.buildConversionEventV1 = Te.buildImpressionEventV1 = Te.makeBatchedEventV1 = void 0;
    var Zc = "campaign_activated",
        Xc = "custom",
        Ea = "$opt_bot_filtering";

    function xa(e) {
        var t = [],
            n = e[0];
        return e.forEach(function(r) {
            if (r.type === "conversion" || r.type === "impression") {
                var i = fi(r);
                r.type === "impression" ? i.snapshots.push(Sa(r)) : r.type === "conversion" && i.snapshots.push(Ca(r)), t.push(i)
            }
        }), {
            client_name: n.context.clientName,
            client_version: n.context.clientVersion,
            account_id: n.context.accountId,
            project_id: n.context.projectId,
            revision: n.context.revision,
            anonymize_ip: n.context.anonymizeIP,
            enrich_decisions: !0,
            visitors: t
        }
    }
    Te.makeBatchedEventV1 = xa;

    function Ca(e) {
        var t = di({}, e.tags);
        delete t.revenue, delete t.value;
        var n = {
            entity_id: e.event.id,
            key: e.event.key,
            timestamp: e.timestamp,
            uuid: e.uuid
        };
        return e.tags && (n.tags = e.tags), e.value != null && (n.value = e.value), e.revenue != null && (n.revenue = e.revenue), {
            events: [n]
        }
    }

    function Sa(e) {
        var t, n, r = e.layer,
            i = e.experiment,
            o = e.variation,
            a = e.ruleKey,
            s = e.flagKey,
            l = e.ruleType,
            u = e.enabled,
            c = r ? r.id : null,
            f = (t = i == null ? void 0 : i.id) !== null && t !== void 0 ? t : "",
            d = (n = o == null ? void 0 : o.id) !== null && n !== void 0 ? n : "",
            p = o ? o.key : "";
        return {
            decisions: [{
                campaign_id: c,
                experiment_id: f,
                variation_id: d,
                metadata: {
                    flag_key: s,
                    rule_key: a,
                    rule_type: l,
                    variation_key: p,
                    enabled: u
                }
            }],
            events: [{
                entity_id: c,
                timestamp: e.timestamp,
                key: Zc,
                uuid: e.uuid
            }]
        }
    }

    function fi(e) {
        var t = {
            snapshots: [],
            visitor_id: e.user.id,
            attributes: []
        };
        return e.user.attributes.forEach(function(n) {
            t.attributes.push({
                entity_id: n.entityId,
                key: n.key,
                type: "custom",
                value: n.value
            })
        }), typeof e.context.botFiltering == "boolean" && t.attributes.push({
            entity_id: Ea,
            key: Ea,
            type: Xc,
            value: e.context.botFiltering
        }), t
    }

    function Jc(e) {
        var t = fi(e);
        return t.snapshots.push(Sa(e)), {
            client_name: e.context.clientName,
            client_version: e.context.clientVersion,
            account_id: e.context.accountId,
            project_id: e.context.projectId,
            revision: e.context.revision,
            anonymize_ip: e.context.anonymizeIP,
            enrich_decisions: !0,
            visitors: [t]
        }
    }
    Te.buildImpressionEventV1 = Jc;

    function ed(e) {
        var t = fi(e);
        return t.snapshots.push(Ca(e)), {
            client_name: e.context.clientName,
            client_version: e.context.clientVersion,
            account_id: e.context.accountId,
            project_id: e.context.projectId,
            revision: e.context.revision,
            anonymize_ip: e.context.anonymizeIP,
            enrich_decisions: !0,
            visitors: [t]
        }
    }
    Te.buildConversionEventV1 = ed;

    function td(e) {
        return {
            url: "https://logx.optimizely.com/v1/events",
            httpVerb: "POST",
            params: xa(e)
        }
    }
    Te.formatEvents = td;
    var tr = {},
        pi = {};
    Object.defineProperty(pi, "__esModule", {
        value: !0
    });
    var nd = function() {
        function e() {
            this.reqsInFlightCount = 0, this.reqsCompleteResolvers = []
        }
        return e.prototype.trackRequest = function(t) {
            var n = this;
            this.reqsInFlightCount++;
            var r = function() {
                n.reqsInFlightCount--, n.reqsInFlightCount === 0 && (n.reqsCompleteResolvers.forEach(function(i) {
                    return i()
                }), n.reqsCompleteResolvers = [])
            };
            t.then(r, r)
        }, e.prototype.onRequestsComplete = function() {
            var t = this;
            return new Promise(function(n) {
                t.reqsInFlightCount === 0 ? n() : t.reqsCompleteResolvers.push(n)
            })
        }, e
    }();
    pi.default = nd;
    var rd = B && B.__awaiter || function(e, t, n, r) {
            function i(o) {
                return o instanceof n ? o : new n(function(a) {
                    a(o)
                })
            }
            return new(n || (n = Promise))(function(o, a) {
                function s(c) {
                    try {
                        u(r.next(c))
                    } catch (f) {
                        a(f)
                    }
                }

                function l(c) {
                    try {
                        u(r.throw(c))
                    } catch (f) {
                        a(f)
                    }
                }

                function u(c) {
                    c.done ? o(c.value) : i(c.value).then(s, l)
                }
                u((r = r.apply(e, t || [])).next())
            })
        },
        id = B && B.__generator || function(e, t) {
            var n = {
                    label: 0,
                    sent: function() {
                        if (o[0] & 1) throw o[1];
                        return o[1]
                    },
                    trys: [],
                    ops: []
                },
                r, i, o, a;
            return a = {
                next: s(0),
                throw: s(1),
                return: s(2)
            }, typeof Symbol == "function" && (a[Symbol.iterator] = function() {
                return this
            }), a;

            function s(u) {
                return function(c) {
                    return l([u, c])
                }
            }

            function l(u) {
                if (r) throw new TypeError("Generator is already executing.");
                for (; n;) try {
                    if (r = 1, i && (o = u[0] & 2 ? i.return : u[0] ? i.throw || ((o = i.return) && o.call(i), 0) : i.next) && !(o = o.call(i, u[1])).done) return o;
                    switch (i = 0, o && (u = [u[0] & 2, o.value]), u[0]) {
                        case 0:
                        case 1:
                            o = u;
                            break;
                        case 4:
                            return n.label++, {
                                value: u[1],
                                done: !1
                            };
                        case 5:
                            n.label++, i = u[1], u = [0];
                            continue;
                        case 7:
                            u = n.ops.pop(), n.trys.pop();
                            continue;
                        default:
                            if (o = n.trys, !(o = o.length > 0 && o[o.length - 1]) && (u[0] === 6 || u[0] === 2)) {
                                n = 0;
                                continue
                            }
                            if (u[0] === 3 && (!o || u[1] > o[0] && u[1] < o[3])) {
                                n.label = u[1];
                                break
                            }
                            if (u[0] === 6 && n.label < o[1]) {
                                n.label = o[1], o = u;
                                break
                            }
                            if (o && n.label < o[2]) {
                                n.label = o[2], n.ops.push(u);
                                break
                            }
                            o[2] && n.ops.pop(), n.trys.pop();
                            continue
                    }
                    u = t.call(e, n)
                } catch (c) {
                    u = [6, c], i = 0
                } finally {
                    r = o = 0
                }
                if (u[0] & 5) throw u[1];
                return {
                    value: u[0] ? u[1] : void 0,
                    done: !0
                }
            }
        },
        od = B && B.__importDefault || function(e) {
            return e && e.__esModule ? e : {
                default: e
            }
        };
    Object.defineProperty(tr, "__esModule", {
        value: !0
    }), tr.LogTierV1EventProcessor = void 0;
    var ad = ae,
        zt = ci,
        sd = od(pi),
        ld = mn,
        ud = Te,
        Ia = ad.getLogger("LogTierV1EventProcessor"),
        cd = function() {
            function e(t) {
                var n = t.dispatcher,
                    r = t.flushInterval,
                    i = r === void 0 ? zt.DEFAULT_FLUSH_INTERVAL : r,
                    o = t.batchSize,
                    a = o === void 0 ? zt.DEFAULT_BATCH_SIZE : o,
                    s = t.notificationCenter;
                this.dispatcher = n, this.notificationCenter = s, this.requestTracker = new sd.default, i = zt.validateAndGetFlushInterval(i), a = zt.validateAndGetBatchSize(a), this.queue = zt.getQueue(a, i, this.drainQueue.bind(this), ld.areEventContextsEqual)
            }
            return e.prototype.drainQueue = function(t) {
                var n = this,
                    r = new Promise(function(i) {
                        if (Ia.debug("draining queue with %s events", t.length), t.length === 0) {
                            i();
                            return
                        }
                        var o = ud.formatEvents(t);
                        n.dispatcher.dispatchEvent(o, function() {
                            i()
                        }), zt.sendEventNotification(n.notificationCenter, o)
                    });
                return this.requestTracker.trackRequest(r), r
            }, e.prototype.process = function(t) {
                this.queue.enqueue(t)
            }, e.prototype.stop = function() {
                try {
                    return this.queue.stop(), this.requestTracker.onRequestsComplete()
                } catch (t) {
                    Ia.error('Error stopping EventProcessor: "%s"', t.message, t)
                }
                return Promise.resolve()
            }, e.prototype.start = function() {
                return rd(this, void 0, void 0, function() {
                    return id(this, function(t) {
                        return this.queue.start(), [2]
                    })
                })
            }, e
        }();
    tr.LogTierV1EventProcessor = cd,
        function(e) {
            var t = B && B.__createBinding || (Object.create ? function(r, i, o, a) {
                    a === void 0 && (a = o), Object.defineProperty(r, a, {
                        enumerable: !0,
                        get: function() {
                            return i[o]
                        }
                    })
                } : function(r, i, o, a) {
                    a === void 0 && (a = o), r[a] = i[o]
                }),
                n = B && B.__exportStar || function(r, i) {
                    for (var o in r) o !== "default" && !Object.prototype.hasOwnProperty.call(i, o) && t(i, r, o)
                };
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), n(mn, e), n(ci, e), n(ga, e), n(_a, e), n(qt, e), n(Te, e), n(tr, e)
        }(Nc);
    var nr = {
            exports: {}
        },
        ka = typeof crypto < "u" && crypto.getRandomValues && crypto.getRandomValues.bind(crypto) || typeof msCrypto < "u" && typeof window.msCrypto.getRandomValues == "function" && msCrypto.getRandomValues.bind(msCrypto);
    if (ka) {
        var Ta = new Uint8Array(16);
        nr.exports = function() {
            return ka(Ta), Ta
        }
    } else {
        var La = new Array(16);
        nr.exports = function() {
            for (var t = 0, n; t < 16; t++)(t & 3) === 0 && (n = Math.random() * 4294967296), La[t] = n >>> ((t & 3) << 3) & 255;
            return La
        }
    }
    for (var Ra = [], rr = 0; rr < 256; ++rr) Ra[rr] = (rr + 256).toString(16).substr(1);

    function dd(e, t) {
        var n = t || 0,
            r = Ra;
        return [r[e[n++]], r[e[n++]], r[e[n++]], r[e[n++]], "-", r[e[n++]], r[e[n++]], "-", r[e[n++]], r[e[n++]], "-", r[e[n++]], r[e[n++]], "-", r[e[n++]], r[e[n++]], r[e[n++]], r[e[n++]], r[e[n++]], r[e[n++]]].join("")
    }
    var Aa = dd,
        fd = nr.exports,
        pd = Aa,
        Oa, hi, vi = 0,
        mi = 0;

    function hd(e, t, n) {
        var r = t && n || 0,
            i = t || [];
        e = e || {};
        var o = e.node || Oa,
            a = e.clockseq !== void 0 ? e.clockseq : hi;
        if (o == null || a == null) {
            var s = fd();
            o == null && (o = Oa = [s[0] | 1, s[1], s[2], s[3], s[4], s[5]]), a == null && (a = hi = (s[6] << 8 | s[7]) & 16383)
        }
        var l = e.msecs !== void 0 ? e.msecs : new Date().getTime(),
            u = e.nsecs !== void 0 ? e.nsecs : mi + 1,
            c = l - vi + (u - mi) / 1e4;
        if (c < 0 && e.clockseq === void 0 && (a = a + 1 & 16383), (c < 0 || l > vi) && e.nsecs === void 0 && (u = 0), u >= 1e4) throw new Error("uuid.v1(): Can't create more than 10M uuids/sec");
        vi = l, mi = u, hi = a, l += 122192928e5;
        var f = ((l & 268435455) * 1e4 + u) % 4294967296;
        i[r++] = f >>> 24 & 255, i[r++] = f >>> 16 & 255, i[r++] = f >>> 8 & 255, i[r++] = f & 255;
        var d = l / 4294967296 * 1e4 & 268435455;
        i[r++] = d >>> 8 & 255, i[r++] = d & 255, i[r++] = d >>> 24 & 15 | 16, i[r++] = d >>> 16 & 255, i[r++] = a >>> 8 | 128, i[r++] = a & 255;
        for (var p = 0; p < 6; ++p) i[r + p] = o[p];
        return t || pd(i)
    }
    var vd = hd,
        md = nr.exports,
        gd = Aa;

    function _d(e, t, n) {
        var r = t && n || 0;
        typeof e == "string" && (t = e === "binary" ? new Array(16) : null, e = null), e = e || {};
        var i = e.random || (e.rng || md)();
        if (i[6] = i[6] & 15 | 64, i[8] = i[8] & 63 | 128, t)
            for (var o = 0; o < 16; ++o) t[r + o] = i[o];
        return t || gd(i)
    }
    var yd = _d,
        wd = vd,
        Da = yd,
        Ua = Da;
    Ua.v1 = wd, Ua.v4 = Da;
    var bd = {
        exports: {}
    };
    (function(e) {
        (function() {
            function t(i, o) {
                for (var a = i.length, s = o ^ a, l = 0, u; a >= 4;) u = i.charCodeAt(l) & 255 | (i.charCodeAt(++l) & 255) << 8 | (i.charCodeAt(++l) & 255) << 16 | (i.charCodeAt(++l) & 255) << 24, u = (u & 65535) * 1540483477 + (((u >>> 16) * 1540483477 & 65535) << 16), u ^= u >>> 24, u = (u & 65535) * 1540483477 + (((u >>> 16) * 1540483477 & 65535) << 16), s = (s & 65535) * 1540483477 + (((s >>> 16) * 1540483477 & 65535) << 16) ^ u, a -= 4, ++l;
                switch (a) {
                    case 3:
                        s ^= (i.charCodeAt(l + 2) & 255) << 16;
                    case 2:
                        s ^= (i.charCodeAt(l + 1) & 255) << 8;
                    case 1:
                        s ^= i.charCodeAt(l) & 255, s = (s & 65535) * 1540483477 + (((s >>> 16) * 1540483477 & 65535) << 16)
                }
                return s ^= s >>> 13, s = (s & 65535) * 1540483477 + (((s >>> 16) * 1540483477 & 65535) << 16), s ^= s >>> 15, s >>> 0
            }

            function n(i, o) {
                var a, s, l, u, c, f, d, p;
                for (a = i.length & 3, s = i.length - a, l = o, c = 3432918353, f = 461845907, p = 0; p < s;) d = i.charCodeAt(p) & 255 | (i.charCodeAt(++p) & 255) << 8 | (i.charCodeAt(++p) & 255) << 16 | (i.charCodeAt(++p) & 255) << 24, ++p, d = (d & 65535) * c + (((d >>> 16) * c & 65535) << 16) & 4294967295, d = d << 15 | d >>> 17, d = (d & 65535) * f + (((d >>> 16) * f & 65535) << 16) & 4294967295, l ^= d, l = l << 13 | l >>> 19, u = (l & 65535) * 5 + (((l >>> 16) * 5 & 65535) << 16) & 4294967295, l = (u & 65535) + 27492 + (((u >>> 16) + 58964 & 65535) << 16);
                switch (d = 0, a) {
                    case 3:
                        d ^= (i.charCodeAt(p + 2) & 255) << 16;
                    case 2:
                        d ^= (i.charCodeAt(p + 1) & 255) << 8;
                    case 1:
                        d ^= i.charCodeAt(p) & 255, d = (d & 65535) * c + (((d >>> 16) * c & 65535) << 16) & 4294967295, d = d << 15 | d >>> 17, d = (d & 65535) * f + (((d >>> 16) * f & 65535) << 16) & 4294967295, l ^= d
                }
                return l ^= i.length, l ^= l >>> 16, l = (l & 65535) * 2246822507 + (((l >>> 16) * 2246822507 & 65535) << 16) & 4294967295, l ^= l >>> 13, l = (l & 65535) * 3266489909 + (((l >>> 16) * 3266489909 & 65535) << 16) & 4294967295, l ^= l >>> 16, l >>> 0
            }
            var r = n;
            r.v2 = t, r.v3 = n, e.exports = r
        })()
    })(bd);
    var Pa = {},
        gi = {},
        _i = {},
        Pe = {};
    Object.defineProperty(Pe, "__esModule", {
        value: !0
    }), Pe.DEFAULT_UPDATE_INTERVAL = 5 * 60 * 1e3, Pe.MIN_UPDATE_INTERVAL = 1e3, Pe.DEFAULT_URL_TEMPLATE = "https://cdn.optimizely.com/datafiles/%s.json", Pe.DEFAULT_AUTHENTICATED_URL_TEMPLATE = "https://config.optimizely.com/datafiles/auth/%s.json", Pe.BACKOFF_BASE_WAIT_SECONDS_BY_ERROR_COUNT = [0, 8, 16, 32, 64, 128, 256, 512], Pe.REQUEST_TIMEOUT_MS = 60 * 1e3, Object.defineProperty(_i, "__esModule", {
        value: !0
    });
    var Ed = Pe,
        xd = ae,
        Cd = xd.getLogger("DatafileManager"),
        Sd = "GET",
        Id = 4;

    function kd(e) {
        var t = e.getAllResponseHeaders();
        if (t === null) return {};
        var n = t.split(`\r
`),
            r = {};
        return n.forEach(function(i) {
            var o = i.indexOf(": ");
            if (o > -1) {
                var a = i.slice(0, o),
                    s = i.slice(o + 2);
                s.length > 0 && (r[a] = s)
            }
        }), r
    }

    function Td(e, t) {
        Object.keys(e).forEach(function(n) {
            var r = e[n];
            t.setRequestHeader(n, r)
        })
    }

    function Ld(e, t) {
        var n = new XMLHttpRequest,
            r = new Promise(function(i, o) {
                n.open(Sd, e, !0), Td(t, n), n.onreadystatechange = function() {
                    if (n.readyState === Id) {
                        var a = n.status;
                        if (a === 0) {
                            o(new Error("Request error"));
                            return
                        }
                        var s = kd(n),
                            l = {
                                statusCode: n.status,
                                body: n.responseText,
                                headers: s
                            };
                        i(l)
                    }
                }, n.timeout = Ed.REQUEST_TIMEOUT_MS, n.ontimeout = function() {
                    Cd.error("Request timed out")
                }, n.send()
            });
        return {
            responsePromise: r,
            abort: function() {
                n.abort()
            }
        }
    }
    _i.makeGetRequest = Ld;
    var yi = {},
        wi = {};
    Object.defineProperty(wi, "__esModule", {
        value: !0
    });
    var Rd = function() {
        function e() {
            this.listeners = {}, this.listenerId = 1
        }
        return e.prototype.on = function(t, n) {
            var r = this;
            this.listeners[t] || (this.listeners[t] = {});
            var i = String(this.listenerId);
            return this.listenerId++, this.listeners[t][i] = n,
                function() {
                    r.listeners[t] && delete r.listeners[t][i]
                }
        }, e.prototype.emit = function(t, n) {
            var r = this.listeners[t];
            r && Object.keys(r).forEach(function(i) {
                var o = r[i];
                o(n)
            })
        }, e.prototype.removeAllListeners = function() {
            this.listeners = {}
        }, e
    }();
    wi.default = Rd;
    var bi = {};
    Object.defineProperty(bi, "__esModule", {
        value: !0
    });
    var Ei = Pe;

    function Ad() {
        return Math.round(Math.random() * 1e3)
    }
    var Od = function() {
        function e() {
            this.errorCount = 0
        }
        return e.prototype.getDelay = function() {
            if (this.errorCount === 0) return 0;
            var t = Ei.BACKOFF_BASE_WAIT_SECONDS_BY_ERROR_COUNT[Math.min(Ei.BACKOFF_BASE_WAIT_SECONDS_BY_ERROR_COUNT.length - 1, this.errorCount)];
            return t * 1e3 + Ad()
        }, e.prototype.countError = function() {
            this.errorCount < Ei.BACKOFF_BASE_WAIT_SECONDS_BY_ERROR_COUNT.length - 1 && this.errorCount++
        }, e.prototype.reset = function() {
            this.errorCount = 0
        }, e
    }();
    bi.default = Od;
    var ir = B && B.__assign || function() {
            return ir = Object.assign || function(e) {
                for (var t, n = 1, r = arguments.length; n < r; n++) {
                    t = arguments[n];
                    for (var i in t) Object.prototype.hasOwnProperty.call(t, i) && (e[i] = t[i])
                }
                return e
            }, ir.apply(this, arguments)
        },
        Na = B && B.__importDefault || function(e) {
            return e && e.__esModule ? e : {
                default: e
            }
        };
    Object.defineProperty(yi, "__esModule", {
        value: !0
    });
    var Dd = ae,
        Ud = $t,
        Pd = Na(wi),
        gn = Pe,
        Nd = Na(bi),
        Ee = Dd.getLogger("DatafileManager"),
        Md = "update";

    function jd(e) {
        return e >= gn.MIN_UPDATE_INTERVAL
    }

    function Ma(e) {
        return e >= 200 && e < 400
    }
    var Vd = {
            get: function() {
                return Promise.resolve("")
            },
            set: function() {
                return Promise.resolve()
            },
            contains: function() {
                return Promise.resolve(!1)
            },
            remove: function() {
                return Promise.resolve()
            }
        },
        Fd = function() {
            function e(t) {
                var n = this,
                    r = ir(ir({}, this.getConfigDefaults()), t),
                    i = r.datafile,
                    o = r.autoUpdate,
                    a = o === void 0 ? !1 : o,
                    s = r.sdkKey,
                    l = r.updateInterval,
                    u = l === void 0 ? gn.DEFAULT_UPDATE_INTERVAL : l,
                    c = r.urlTemplate,
                    f = c === void 0 ? gn.DEFAULT_URL_TEMPLATE : c,
                    d = r.cache,
                    p = d === void 0 ? Vd : d;
                this.cache = p, this.cacheKey = "opt-datafile-" + s, this.isReadyPromiseSettled = !1, this.readyPromiseResolver = function() {}, this.readyPromiseRejecter = function() {}, this.readyPromise = new Promise(function(h, v) {
                    n.readyPromiseResolver = h, n.readyPromiseRejecter = v
                }), i ? (this.currentDatafile = i, s || this.resolveReadyPromise()) : this.currentDatafile = "", this.isStarted = !1, this.datafileUrl = Ud.sprintf(f, s), this.emitter = new Pd.default, this.autoUpdate = a, jd(u) ? this.updateInterval = u : (Ee.warn("Invalid updateInterval %s, defaulting to %s", u, gn.DEFAULT_UPDATE_INTERVAL), this.updateInterval = gn.DEFAULT_UPDATE_INTERVAL), this.currentTimeout = null, this.currentRequest = null, this.backoffController = new Nd.default, this.syncOnCurrentRequestComplete = !1
            }
            return e.prototype.get = function() {
                return this.currentDatafile
            }, e.prototype.start = function() {
                this.isStarted || (Ee.debug("Datafile manager started"), this.isStarted = !0, this.backoffController.reset(), this.setDatafileFromCacheIfAvailable(), this.syncDatafile())
            }, e.prototype.stop = function() {
                return Ee.debug("Datafile manager stopped"), this.isStarted = !1, this.currentTimeout && (clearTimeout(this.currentTimeout), this.currentTimeout = null), this.emitter.removeAllListeners(), this.currentRequest && (this.currentRequest.abort(), this.currentRequest = null), Promise.resolve()
            }, e.prototype.onReady = function() {
                return this.readyPromise
            }, e.prototype.on = function(t, n) {
                return this.emitter.on(t, n)
            }, e.prototype.onRequestRejected = function(t) {
                !this.isStarted || (this.backoffController.countError(), t instanceof Error ? Ee.error("Error fetching datafile: %s", t.message, t) : typeof t == "string" ? Ee.error("Error fetching datafile: %s", t) : Ee.error("Error fetching datafile"))
            }, e.prototype.onRequestResolved = function(t) {
                if (!!this.isStarted) {
                    typeof t.statusCode < "u" && Ma(t.statusCode) ? this.backoffController.reset() : this.backoffController.countError(), this.trySavingLastModified(t.headers);
                    var n = this.getNextDatafileFromResponse(t);
                    if (n !== "")
                        if (Ee.info("Updating datafile from response"), this.currentDatafile = n, this.cache.set(this.cacheKey, n), !this.isReadyPromiseSettled) this.resolveReadyPromise();
                        else {
                            var r = {
                                datafile: n
                            };
                            this.emitter.emit(Md, r)
                        }
                }
            }, e.prototype.onRequestComplete = function() {
                !this.isStarted || (this.currentRequest = null, !this.isReadyPromiseSettled && !this.autoUpdate && this.rejectReadyPromise(new Error("Failed to become ready")), this.autoUpdate && this.syncOnCurrentRequestComplete && this.syncDatafile(), this.syncOnCurrentRequestComplete = !1)
            }, e.prototype.syncDatafile = function() {
                var t = this,
                    n = {};
                this.lastResponseLastModified && (n["if-modified-since"] = this.lastResponseLastModified), Ee.debug("Making datafile request to url %s with headers: %s", this.datafileUrl, function() {
                    return JSON.stringify(n)
                }), this.currentRequest = this.makeGetRequest(this.datafileUrl, n);
                var r = function() {
                        t.onRequestComplete()
                    },
                    i = function(a) {
                        t.onRequestResolved(a)
                    },
                    o = function(a) {
                        t.onRequestRejected(a)
                    };
                this.currentRequest.responsePromise.then(i, o).then(r, r), this.autoUpdate && this.scheduleNextUpdate()
            }, e.prototype.resolveReadyPromise = function() {
                this.readyPromiseResolver(), this.isReadyPromiseSettled = !0
            }, e.prototype.rejectReadyPromise = function(t) {
                this.readyPromiseRejecter(t), this.isReadyPromiseSettled = !0
            }, e.prototype.scheduleNextUpdate = function() {
                var t = this,
                    n = this.backoffController.getDelay(),
                    r = Math.max(n, this.updateInterval);
                Ee.debug("Scheduling sync in %s ms", r), this.currentTimeout = setTimeout(function() {
                    t.currentRequest ? t.syncOnCurrentRequestComplete = !0 : t.syncDatafile()
                }, r)
            }, e.prototype.getNextDatafileFromResponse = function(t) {
                return Ee.debug("Response status code: %s", t.statusCode), typeof t.statusCode > "u" || t.statusCode === 304 ? "" : Ma(t.statusCode) ? t.body : ""
            }, e.prototype.trySavingLastModified = function(t) {
                var n = t["last-modified"] || t["Last-Modified"];
                typeof n < "u" && (this.lastResponseLastModified = n, Ee.debug("Saved last modified header value from response: %s", this.lastResponseLastModified))
            }, e.prototype.setDatafileFromCacheIfAvailable = function() {
                var t = this;
                this.cache.get(this.cacheKey).then(function(n) {
                    t.isStarted && !t.isReadyPromiseSettled && n !== "" && (Ee.debug("Using datafile from cache"), t.currentDatafile = n, t.resolveReadyPromise())
                })
            }, e
        }();
    yi.default = Fd;
    var Bd = B && B.__extends || function() {
            var e = function(t, n) {
                return e = Object.setPrototypeOf || {
                    __proto__: []
                }
                instanceof Array && function(r, i) {
                    r.__proto__ = i
                } || function(r, i) {
                    for (var o in i) i.hasOwnProperty(o) && (r[o] = i[o])
                }, e(t, n)
            };
            return function(t, n) {
                e(t, n);

                function r() {
                    this.constructor = t
                }
                t.prototype = n === null ? Object.create(n) : (r.prototype = n.prototype, new r)
            }
        }(),
        Hd = B && B.__importDefault || function(e) {
            return e && e.__esModule ? e : {
                default: e
            }
        };
    Object.defineProperty(gi, "__esModule", {
        value: !0
    });
    var Kd = _i,
        $d = Hd(yi),
        Gd = function(e) {
            Bd(t, e);

            function t() {
                return e !== null && e.apply(this, arguments) || this
            }
            return t.prototype.makeGetRequest = function(n, r) {
                return Kd.makeGetRequest(n, r)
            }, t.prototype.getConfigDefaults = function() {
                return {
                    autoUpdate: !1
                }
            }, t
        }($d.default);
    gi.default = Gd, Object.defineProperty(Pa, "__esModule", {
        value: !0
    });
    var qd = gi;
    Pa.HttpPollingDatafileManager = qd.default;
    var zd = {
            NOTSET: 0,
            DEBUG: 1,
            INFO: 2,
            WARNING: 3,
            ERROR: 4
        },
        Wd = {
            CONDITION_EVALUATOR_ERROR: "%s: Error evaluating audience condition of type %s: %s",
            DATAFILE_AND_SDK_KEY_MISSING: "%s: You must provide at least one of sdkKey or datafile. Cannot start Optimizely",
            EXPERIMENT_KEY_NOT_IN_DATAFILE: "%s: Experiment key %s is not in datafile.",
            FEATURE_NOT_IN_DATAFILE: "%s: Feature key %s is not in datafile.",
            IMPROPERLY_FORMATTED_EXPERIMENT: "%s: Experiment key %s is improperly formatted.",
            INVALID_ATTRIBUTES: "%s: Provided attributes are in an invalid format.",
            INVALID_BUCKETING_ID: "%s: Unable to generate hash for bucketing ID %s: %s",
            INVALID_DATAFILE: "%s: Datafile is invalid - property %s: %s",
            INVALID_DATAFILE_MALFORMED: "%s: Datafile is invalid because it is malformed.",
            INVALID_CONFIG: "%s: Provided Optimizely config is in an invalid format.",
            INVALID_JSON: "%s: JSON object is not valid.",
            INVALID_ERROR_HANDLER: '%s: Provided "errorHandler" is in an invalid format.',
            INVALID_EVENT_DISPATCHER: '%s: Provided "eventDispatcher" is in an invalid format.',
            INVALID_EVENT_TAGS: "%s: Provided event tags are in an invalid format.",
            INVALID_EXPERIMENT_KEY: "%s: Experiment key %s is not in datafile. It is either invalid, paused, or archived.",
            INVALID_EXPERIMENT_ID: "%s: Experiment ID %s is not in datafile.",
            INVALID_GROUP_ID: "%s: Group ID %s is not in datafile.",
            INVALID_LOGGER: '%s: Provided "logger" is in an invalid format.',
            INVALID_ROLLOUT_ID: "%s: Invalid rollout ID %s attached to feature %s",
            INVALID_USER_ID: "%s: Provided user ID is in an invalid format.",
            INVALID_USER_PROFILE_SERVICE: "%s: Provided user profile service instance is in an invalid format: %s.",
            NO_DATAFILE_SPECIFIED: "%s: No datafile specified. Cannot start optimizely.",
            NO_JSON_PROVIDED: "%s: No JSON object to validate against schema.",
            NO_VARIATION_FOR_EXPERIMENT_KEY: "%s: No variation key %s defined in datafile for experiment %s.",
            UNDEFINED_ATTRIBUTE: "%s: Provided attribute: %s has an undefined value.",
            UNRECOGNIZED_ATTRIBUTE: "%s: Unrecognized attribute %s provided. Pruning before sending event to Optimizely.",
            UNABLE_TO_CAST_VALUE: "%s: Unable to cast value %s to type %s, returning null.",
            USER_NOT_IN_FORCED_VARIATION: "%s: User %s is not in the forced variation map. Cannot remove their forced variation.",
            USER_PROFILE_LOOKUP_ERROR: '%s: Error while looking up user profile for user ID "%s": %s.',
            USER_PROFILE_SAVE_ERROR: '%s: Error while saving user profile for user ID "%s": %s.',
            VARIABLE_KEY_NOT_IN_DATAFILE: '%s: Variable with key "%s" associated with feature with key "%s" is not in datafile.',
            VARIATION_ID_NOT_IN_DATAFILE: "%s: No variation ID %s defined in datafile for experiment %s.",
            VARIATION_ID_NOT_IN_DATAFILE_NO_EXPERIMENT: "%s: Variation ID %s is not in the datafile.",
            INVALID_INPUT_FORMAT: "%s: Provided %s is in an invalid format.",
            INVALID_DATAFILE_VERSION: "%s: This version of the JavaScript SDK does not support the given datafile version: %s",
            INVALID_VARIATION_KEY: "%s: Provided variation key is in an invalid format."
        },
        Yd = {
            ACTIVATE_USER: "%s: Activating user %s in experiment %s.",
            DISPATCH_CONVERSION_EVENT: "%s: Dispatching conversion event to URL %s with params %s.",
            DISPATCH_IMPRESSION_EVENT: "%s: Dispatching impression event to URL %s with params %s.",
            DEPRECATED_EVENT_VALUE: "%s: Event value is deprecated in %s call.",
            EVENT_KEY_NOT_FOUND: "%s: Event key %s is not in datafile.",
            EXPERIMENT_NOT_RUNNING: "%s: Experiment %s is not running.",
            FEATURE_ENABLED_FOR_USER: "%s: Feature %s is enabled for user %s.",
            FEATURE_NOT_ENABLED_FOR_USER: "%s: Feature %s is not enabled for user %s.",
            FEATURE_HAS_NO_EXPERIMENTS: "%s: Feature %s is not attached to any experiments.",
            FAILED_TO_PARSE_VALUE: '%s: Failed to parse event value "%s" from event tags.',
            FAILED_TO_PARSE_REVENUE: '%s: Failed to parse revenue value "%s" from event tags.',
            FORCED_BUCKETING_FAILED: "%s: Variation key %s is not in datafile. Not activating user %s.",
            INVALID_OBJECT: "%s: Optimizely object is not valid. Failing %s.",
            INVALID_CLIENT_ENGINE: "%s: Invalid client engine passed: %s. Defaulting to node-sdk.",
            INVALID_DEFAULT_DECIDE_OPTIONS: "%s: Provided default decide options is not an array.",
            INVALID_DECIDE_OPTIONS: "%s: Provided decide options is not an array. Using default decide options.",
            INVALID_VARIATION_ID: "%s: Bucketed into an invalid variation ID. Returning null.",
            NOTIFICATION_LISTENER_EXCEPTION: "%s: Notification listener for (%s) threw exception: %s",
            NO_ROLLOUT_EXISTS: "%s: There is no rollout of feature %s.",
            NOT_ACTIVATING_USER: "%s: Not activating user %s for experiment %s.",
            NOT_TRACKING_USER: "%s: Not tracking user %s.",
            PARSED_REVENUE_VALUE: '%s: Parsed revenue value "%s" from event tags.',
            PARSED_NUMERIC_VALUE: '%s: Parsed event value "%s" from event tags.',
            RETURNING_STORED_VARIATION: '%s: Returning previously activated variation "%s" of experiment "%s" for user "%s" from user profile.',
            ROLLOUT_HAS_NO_EXPERIMENTS: "%s: Rollout of feature %s has no experiments",
            SAVED_VARIATION: '%s: Saved variation "%s" of experiment "%s" for user "%s".',
            SAVED_VARIATION_NOT_FOUND: "%s: User %s was previously bucketed into variation with ID %s for experiment %s, but no matching variation was found.",
            SHOULD_NOT_DISPATCH_ACTIVATE: '%s: Experiment %s is not in "Running" state. Not activating user.',
            SKIPPING_JSON_VALIDATION: "%s: Skipping JSON schema validation.",
            TRACK_EVENT: "%s: Tracking event %s for user %s.",
            UNRECOGNIZED_DECIDE_OPTION: "%s: Unrecognized decide option %s provided.",
            USER_ASSIGNED_TO_EXPERIMENT_BUCKET: "%s: Assigned bucket %s to user with bucketing ID %s.",
            USER_BUCKETED_INTO_EXPERIMENT_IN_GROUP: "%s: User %s is in experiment %s of group %s.",
            USER_BUCKETED_INTO_TARGETING_RULE: "%s: User %s bucketed into targeting rule %s.",
            USER_IN_FEATURE_EXPERIMENT: "%s: User %s is in variation %s of experiment %s on the feature %s.",
            USER_IN_ROLLOUT: "%s: User %s is in rollout of feature %s.",
            USER_NOT_BUCKETED_INTO_EVERYONE_TARGETING_RULE: "%s: User %s not bucketed into everyone targeting rule due to traffic allocation.",
            USER_NOT_BUCKETED_INTO_EXPERIMENT_IN_GROUP: "%s: User %s is not in experiment %s of group %s.",
            USER_NOT_BUCKETED_INTO_ANY_EXPERIMENT_IN_GROUP: "%s: User %s is not in any experiment of group %s.",
            USER_NOT_BUCKETED_INTO_TARGETING_RULE: "%s User %s not bucketed into targeting rule %s due to traffic allocation. Trying everyone rule.",
            USER_NOT_IN_FEATURE_EXPERIMENT: "%s: User %s is not in any experiment on the feature %s.",
            USER_NOT_IN_ROLLOUT: "%s: User %s is not in rollout of feature %s.",
            USER_FORCED_IN_VARIATION: "%s: User %s is forced in variation %s.",
            USER_MAPPED_TO_FORCED_VARIATION: "%s: Set variation %s for experiment %s and user %s in the forced variation map.",
            USER_DOESNT_MEET_CONDITIONS_FOR_TARGETING_RULE: "%s: User %s does not meet conditions for targeting rule %s.",
            USER_MEETS_CONDITIONS_FOR_TARGETING_RULE: "%s: User %s meets conditions for targeting rule %s.",
            USER_HAS_VARIATION: "%s: User %s is in variation %s of experiment %s.",
            USER_HAS_FORCED_DECISION_WITH_RULE_SPECIFIED: "Variation (%s) is mapped to flag (%s), rule (%s) and user (%s) in the forced decision map.",
            USER_HAS_FORCED_DECISION_WITH_NO_RULE_SPECIFIED: "Variation (%s) is mapped to flag (%s) and user (%s) in the forced decision map.",
            USER_HAS_FORCED_DECISION_WITH_RULE_SPECIFIED_BUT_INVALID: "Invalid variation is mapped to flag (%s), rule (%s) and user (%s) in the forced decision map.",
            USER_HAS_FORCED_DECISION_WITH_NO_RULE_SPECIFIED_BUT_INVALID: "Invalid variation is mapped to flag (%s) and user (%s) in the forced decision map.",
            USER_HAS_FORCED_VARIATION: "%s: Variation %s is mapped to experiment %s and user %s in the forced variation map.",
            USER_HAS_NO_VARIATION: "%s: User %s is in no variation of experiment %s.",
            USER_HAS_NO_FORCED_VARIATION: "%s: User %s is not in the forced variation map.",
            USER_HAS_NO_FORCED_VARIATION_FOR_EXPERIMENT: "%s: No experiment %s mapped to user %s in the forced variation map.",
            USER_NOT_IN_ANY_EXPERIMENT: "%s: User %s is not in any experiment of group %s.",
            USER_NOT_IN_EXPERIMENT: "%s: User %s does not meet conditions to be in experiment %s.",
            USER_RECEIVED_DEFAULT_VARIABLE_VALUE: '%s: User "%s" is not in any variation or rollout rule. Returning default value for variable "%s" of feature flag "%s".',
            FEATURE_NOT_ENABLED_RETURN_DEFAULT_VARIABLE_VALUE: '%s: Feature "%s" is not enabled for user %s. Returning the default variable value "%s".',
            VARIABLE_NOT_USED_RETURN_DEFAULT_VARIABLE_VALUE: '%s: Variable "%s" is not used in variation "%s". Returning default value.',
            USER_RECEIVED_VARIABLE_VALUE: '%s: Got variable value "%s" for variable "%s" of feature flag "%s"',
            VALID_DATAFILE: "%s: Datafile is valid.",
            VALID_USER_PROFILE_SERVICE: "%s: Valid user profile service provided.",
            VARIATION_REMOVED_FOR_USER: "%s: Variation mapped to experiment %s has been removed for user %s.",
            VARIABLE_REQUESTED_WITH_WRONG_TYPE: '%s: Requested variable type "%s", but variable is of type "%s". Use correct API to retrieve value. Returning None.',
            VALID_BUCKETING_ID: '%s: BucketingId is valid: "%s"',
            BUCKETING_ID_NOT_STRING: "%s: BucketingID attribute is not a string. Defaulted to userId",
            EVALUATING_AUDIENCE: '%s: Starting to evaluate audience "%s" with conditions: %s.',
            EVALUATING_AUDIENCES_COMBINED: '%s: Evaluating audiences for %s "%s": %s.',
            AUDIENCE_EVALUATION_RESULT: '%s: Audience "%s" evaluated to %s.',
            AUDIENCE_EVALUATION_RESULT_COMBINED: "%s: Audiences for %s %s collectively evaluated to %s.",
            MISSING_ATTRIBUTE_VALUE: '%s: Audience condition %s evaluated to UNKNOWN because no value was passed for user attribute "%s".',
            UNEXPECTED_CONDITION_VALUE: "%s: Audience condition %s evaluated to UNKNOWN because the condition value is not supported.",
            UNEXPECTED_TYPE: '%s: Audience condition %s evaluated to UNKNOWN because a value of type "%s" was passed for user attribute "%s".',
            UNEXPECTED_TYPE_NULL: '%s: Audience condition %s evaluated to UNKNOWN because a null value was passed for user attribute "%s".',
            UNKNOWN_CONDITION_TYPE: "%s: Audience condition %s has an unknown condition type. You may need to upgrade to a newer release of the Optimizely SDK.",
            UNKNOWN_MATCH_TYPE: "%s: Audience condition %s uses an unknown match type. You may need to upgrade to a newer release of the Optimizely SDK.",
            UPDATED_OPTIMIZELY_CONFIG: "%s: Updated Optimizely config to revision %s (project id %s)",
            OUT_OF_BOUNDS: '%s: Audience condition %s evaluated to UNKNOWN because the number value for user attribute "%s" is not in the range [-2^53, +2^53].',
            UNABLE_TO_ATTACH_UNLOAD: '%s: unable to bind optimizely.close() to page unload event: "%s"'
        },
        Qd = {
            BOT_FILTERING: "$opt_bot_filtering",
            BUCKETING_ID: "$opt_bucketing_id",
            STICKY_BUCKETING_KEY: "$opt_experiment_bucket_map",
            USER_AGENT: "$opt_user_agent",
            FORCED_DECISION_NULL_RULE_KEY: "$opt_null_rule_key"
        },
        Zd = "javascript-sdk",
        Xd = "node-sdk",
        Jd = "react-sdk",
        ef = "react-native-sdk",
        tf = "react-native-js-sdk",
        nf = "4.9.4",
        rf = "4.9.4",
        of = {
            AB_TEST: "ab-test",
            FEATURE: "feature",
            FEATURE_TEST: "feature-test",
            FEATURE_VARIABLE: "feature-variable",
            ALL_FEATURE_VARIABLES: "all-feature-variables",
            FLAG: "flag"
        },
        af = {
            FEATURE_TEST: "feature-test",
            ROLLOUT: "rollout",
            EXPERIMENT: "experiment"
        },
        sf = {
            RULE: "rule",
            EXPERIMENT: "experiment"
        },
        lf = {
            BOOLEAN: "boolean",
            DOUBLE: "double",
            INTEGER: "integer",
            STRING: "string",
            JSON: "json"
        },
        or = {
            V2: "2",
            V3: "3",
            V4: "4"
        },
        uf = {
            SDK_NOT_READY: "Optimizely SDK not configured properly yet.",
            FLAG_KEY_INVALID: 'No flag was found for key "%s".',
            VARIABLE_VALUE_INVALID: 'Variable value for key "%s" is invalid or wrong type.'
        },
        xi;
    (function(e) {
        e.ACTIVATE = "ACTIVATE:experiment, user_id,attributes, variation, event", e.DECISION = "DECISION:type, userId, attributes, decisionInfo", e.LOG_EVENT = "LOG_EVENT:logEvent", e.OPTIMIZELY_CONFIG_UPDATE = "OPTIMIZELY_CONFIG_UPDATE", e.TRACK = "TRACK:event_key, user_id, attributes, event_tags, event"
    })(xi || (xi = {}));
    var cf = Object.freeze({
        __proto__: null,
        LOG_LEVEL: zd,
        ERROR_MESSAGES: Wd,
        LOG_MESSAGES: Yd,
        CONTROL_ATTRIBUTES: Qd,
        JAVASCRIPT_CLIENT_ENGINE: Zd,
        NODE_CLIENT_ENGINE: Xd,
        REACT_CLIENT_ENGINE: Jd,
        REACT_NATIVE_CLIENT_ENGINE: ef,
        REACT_NATIVE_JS_CLIENT_ENGINE: tf,
        BROWSER_CLIENT_VERSION: nf,
        NODE_CLIENT_VERSION: rf,
        DECISION_NOTIFICATION_TYPES: of ,
        DECISION_SOURCES: af,
        AUDIENCE_EVALUATION_TYPES: sf,
        FEATURE_VARIABLE_TYPES: lf,
        DATAFILE_VERSIONS: or,
        DECISION_MESSAGES: uf,
        get NOTIFICATION_TYPES() {
            return xi
        }
    });
    or.V2, or.V3, or.V4,
        function() {
            function e() {}
            return e.prototype.log = function() {}, e
        }();

    function df(e) {
        return new ae.ConsoleLogHandler(e)
    }
    var ja;
    (function(e) {
        e.BOOLEAN = "boolean", e.DOUBLE = "double", e.INTEGER = "integer", e.STRING = "string", e.JSON = "json"
    })(ja || (ja = {}));
    var Va;
    (function(e) {
        e.DISABLE_DECISION_EVENT = "DISABLE_DECISION_EVENT", e.ENABLED_FLAGS_ONLY = "ENABLED_FLAGS_ONLY", e.IGNORE_USER_PROFILE_SERVICE = "IGNORE_USER_PROFILE_SERVICE", e.INCLUDE_REASONS = "INCLUDE_REASONS", e.EXCLUDE_VARIABLES = "EXCLUDE_VARIABLES"
    })(Va || (Va = {})), ae.getLogger(), ae.getLogger(), ae.getLogger(), ae.getLogger(), ae.getLogger("EVENT_BUILDER"), ae.getLogger(), ae.setLogHandler(df()), ae.setLogLevel(ae.LogLevel.INFO);
    let ar;
    const ff = new Uint8Array(16);

    function pf() {
        if (!ar && (ar = typeof crypto < "u" && crypto.getRandomValues && crypto.getRandomValues.bind(crypto), !ar)) throw new Error("crypto.getRandomValues() not supported. See https://github.com/uuidjs/uuid#getrandomvalues-not-supported");
        return ar(ff)
    }
    const le = [];
    for (let e = 0; e < 256; ++e) le.push((e + 256).toString(16).slice(1));

    function hf(e, t = 0) {
        return (le[e[t + 0]] + le[e[t + 1]] + le[e[t + 2]] + le[e[t + 3]] + "-" + le[e[t + 4]] + le[e[t + 5]] + "-" + le[e[t + 6]] + le[e[t + 7]] + "-" + le[e[t + 8]] + le[e[t + 9]] + "-" + le[e[t + 10]] + le[e[t + 11]] + le[e[t + 12]] + le[e[t + 13]] + le[e[t + 14]] + le[e[t + 15]]).toLowerCase()
    }
    const Fa = {
        randomUUID: typeof crypto < "u" && crypto.randomUUID && crypto.randomUUID.bind(crypto)
    };

    function ct(e, t, n) {
        if (Fa.randomUUID && !t && !e) return Fa.randomUUID();
        e = e || {};
        const r = e.random || (e.rng || pf)();
        if (r[6] = r[6] & 15 | 64, r[8] = r[8] & 63 | 128, t) {
            n = n || 0;
            for (let i = 0; i < 16; ++i) t[n + i] = r[i];
            return t
        }
        return hf(r)
    }
    const Wt = "ul-app";
    var A = (e => (e.Caption = "ul-caption", e.CardContainer = "ul-card__container", e.CardMainContent = "ul-card-main-content", e.Choice = "choice", e.ChoiceCheckbox = "select-checkbox", e.ChoiceGroup = "ul-card__choices", e.ChoiceLabel = "select-label", e.ChoiceLabelContainer = "choice-label-container", e.ChoiceRadio = "select-radio", e.ChoiceTextEntryContainer = "choice-text-entry-container", e.ChoiceTextInput = "choice-text-input", e.CloseButton = "close-btn", e.CloseContainer = "close-container", e.ConsentLegalNameInput = "ul-consent-legal__name-input", e.CustomStyle = "ul-custom-style", e.DesktopSuffix = "--desktop", e.FadeInTransition = "fade-in-transition", e.LikertNumber = "likert-number", e.LikertSmiley = "likert-smiley", e.LikertStar = "likert-star", e.LoadingSpinner = "ul-loading-spinner", e.LoadingSpinnerContainer = "ul-loading-spinner-container", e.LoadingSpinnerFirst = "first", e.LoadingSpinnerFourth = "fourth", e.LoadingSpinnerSecond = "second", e.LoadingSpinnerThird = "third", e.MobileSuffix = "--mobile", e.NPSNumber = "nps-number", e.OpenTextInput = "ul-card-text__input", e.QuestionHeader = "ul-question", e.VideoCard = "ul-card--video", e.CheckmarkButton = "ul-button-checkmark", e.InactiveButton = "ul-button-inactive", e.LeftAlignButton = "ul-button-left-align", e.ButtonDisabled = "sprig-button-disabled", e))(A || {});
    const Ci = "#e6e6e6",
        _n = "#bd282a",
        vf = 500,
        mf = 1030;
    var Ye = (e => (e.Closed = "close.click", e.Complete = "survey.completed", e.PageChange = "page.change", e.API = "api", e.Override = "override", e))(Ye || {}),
        K = (e => (e.SDKReady = "sdk.ready", e.SurveyAppeared = "survey.appeared", e.SurveyClosed = "survey.closed", e.SurveyDimensions = "survey.dimensions", e.SurveyFadingOut = "survey.fadingOut", e.SurveyHeight = "survey.height", e.SurveyPresented = "survey.presented", e.SurveyLifeCycle = "survey.lifeCycle", e.SurveyWillClose = "survey.willClose", e.SurveyWillPresent = "survey.will.present", e.CloseSurveyOnOverlayClick = "close.survey.overlayClick", e.VisitorIDUpdated = "visitor.id.updated", e))(K || {}),
        Ba = (e => (e.SurveyId = "survey.id", e))(Ba || {});
    const Ha = {
        SDK_READY: "sdk.ready",
        SURVEY_APPEARED: "survey.appeared",
        SURVEY_CLOSED: "survey.closed",
        SURVEY_DIMENSIONS: "survey.dimensions",
        SURVEY_FADING_OUT: "survey.fadingOut",
        SURVEY_HEIGHT: "survey.height",
        SURVEY_PRESENTED: "survey.presented",
        SURVEY_LIFE_CYCLE: "survey.lifeCycle",
        SURVEY_WILL_CLOSE: "survey.willClose",
        SURVEY_WILL_PRESENT: "survey.will.present",
        CLOSE_SURVEY_ON_OVERLAY_CLICK: "close.survey.overlayClick",
        VISITOR_ID_UPDATED: "visitor.id.updated",
        DATA: {
            DISMISS_REASONS: {
                API: "api",
                CLOSED: "close.click",
                COMPLETE: "survey.completed",
                PAGE_CHANGE: "page.change",
                OVERRIDE: "override"
            },
            SURVEY_ID: "survey.id"
        }
    };
    var xe = (e => (e.VerifyViewVersion = "verify.view.version", e.CurrentQuestion = "survey.question", e.ViewPrototypeClick = "question.prototype.click", e.ViewAgreementClick = "question.agreement.click", e.RecordedTaskStart = "recorded.task.start", e.RecordedTaskPermissionScreen = "recorded.task.permission.screen", e.SurveyComplete = "survey.complete", e))(xe || {}),
        kt = (e => (e.ViewVersion = "view.version", e.QuestionId = "qid", e.Props = "props", e))(kt || {}),
        ge = (e => (e.Preview = "sprig.previewKey", e.Credentials = "userleap.ids", e.PageViews = "userleap.pageviews", e))(ge || {});
    const Ka = () => {
            try {
                return window.parent.Intercom
            } catch (e) {
                return console.error(e), null
            }
        },
        $a = [Object.freeze(Object.defineProperty({
            __proto__: null,
            enable: () => {
                const e = Ka();
                !e || (e.ul_wasVisible && e("update", {
                    hide_default_launcher: !1
                }), delete e.ul_wasVisible)
            },
            disable: () => {
                const e = Ka();
                !e || (e.ul_wasVisible = !!document.querySelector("iframe.intercom-launcher-frame"), e.ul_wasVisible && e("update", {
                    hide_default_launcher: !0
                }))
            }
        }, Symbol.toStringTag, {
            value: "Module"
        }))];
    class Si {
        static disable() {
            $a.forEach(t => t.disable())
        }
        static enable() {
            $a.forEach(t => t.enable())
        }
    }
    const gf = 1,
        Yt = e => e instanceof HTMLElement,
        _f = e => e instanceof HTMLInputElement,
        yn = e => e instanceof HTMLTextAreaElement,
        Ga = (e, t, n) => {
            const r = e.createElement("style");
            n && (r.nonce = n), r.textContent = t, r.id = A.CustomStyle, e.head.appendChild(r)
        },
        qa = e => {
            const t = e.querySelector(`.${A.CardContainer}`);
            let n = 600,
                r = 0;
            if (t) {
                n = t.scrollHeight;
                const i = getComputedStyle(t),
                    o = parseFloat(i.marginTop) + parseFloat(i.marginBottom),
                    a = parseFloat(i.borderTopWidth) + parseFloat(i.borderBottomWidth);
                r = o + a
            }
            return n + r + gf
        },
        yf = e => {
            const t = e.querySelector(`.${A.CardContainer}`);
            t && (t.scrollTop = 0)
        };
    var za = {},
        sr = {},
        wn = {};
    Object.defineProperty(wn, "__esModule", {
        value: !0
    }), wn.MemoryLeakError = void 0;
    class wf extends Error {
        constructor(t, n, r) {
            super(`Possible EventEmitter memory leak detected. ${r} ${n.toString()} listeners added. Use emitter.setMaxListeners() to increase limit`), this.emitter = t, this.type = n, this.count = r, this.name = "MaxListenersExceededWarning"
        }
    }
    wn.MemoryLeakError = wf, Object.defineProperty(sr, "__esModule", {
        value: !0
    }), sr.Emitter = void 0;
    const bf = wn;
    class lr {
        constructor() {
            this.events = new Map, this.maxListeners = lr.defaultMaxListeners, this.hasWarnedAboutPotentialMemoryLeak = !1
        }
        static listenerCount(t, n) {
            return t.listenerCount(n)
        }
        _emitInternalEvent(t, n, r) {
            this.emit(t, n, r)
        }
        _getListeners(t) {
            return this.events.get(t) || []
        }
        _removeListener(t, n) {
            const r = t.indexOf(n);
            return r > -1 && t.splice(r, 1), []
        }
        _wrapOnceListener(t, n) {
            const r = (...i) => {
                this.removeListener(t, r), n.apply(this, i)
            };
            return r
        }
        setMaxListeners(t) {
            return this.maxListeners = t, this
        }
        getMaxListeners() {
            return this.maxListeners
        }
        eventNames() {
            return Array.from(this.events.keys())
        }
        emit(t, ...n) {
            const r = this._getListeners(t);
            return r.forEach(i => {
                i.apply(this, n)
            }), r.length > 0
        }
        addListener(t, n) {
            this._emitInternalEvent("newListener", t, n);
            const r = this._getListeners(t).concat(n);
            if (this.events.set(t, r), this.maxListeners > 0 && this.listenerCount(t) > this.maxListeners && !this.hasWarnedAboutPotentialMemoryLeak) {
                this.hasWarnedAboutPotentialMemoryLeak = !0;
                const i = new bf.MemoryLeakError(this, t, this.listenerCount(t));
                console.warn(i)
            }
            return this
        }
        on(t, n) {
            return this.addListener(t, n)
        }
        once(t, n) {
            return this.addListener(t, this._wrapOnceListener(t, n))
        }
        prependListener(t, n) {
            const r = this._getListeners(t);
            if (r.length > 0) {
                const i = [n].concat(r);
                this.events.set(t, i)
            } else this.events.set(t, r.concat(n));
            return this
        }
        prependOnceListener(t, n) {
            return this.prependListener(t, this._wrapOnceListener(t, n))
        }
        removeListener(t, n) {
            const r = this._getListeners(t);
            return r.length > 0 && (this._removeListener(r, n), this.events.set(t, r), this._emitInternalEvent("removeListener", t, n)), this
        }
        off(t, n) {
            return this.removeListener(t, n)
        }
        removeAllListeners(t) {
            return t ? this.events.delete(t) : this.events.clear(), this
        }
        listeners(t) {
            return Array.from(this._getListeners(t))
        }
        listenerCount(t) {
            return this._getListeners(t).length
        }
        rawListeners(t) {
            return this.listeners(t)
        }
    }
    sr.Emitter = lr, lr.defaultMaxListeners = 10,
        function(e) {
            var t = B && B.__createBinding || (Object.create ? function(r, i, o, a) {
                    a === void 0 && (a = o);
                    var s = Object.getOwnPropertyDescriptor(i, o);
                    (!s || ("get" in s ? !i.__esModule : s.writable || s.configurable)) && (s = {
                        enumerable: !0,
                        get: function() {
                            return i[o]
                        }
                    }), Object.defineProperty(r, a, s)
                } : function(r, i, o, a) {
                    a === void 0 && (a = o), r[a] = i[o]
                }),
                n = B && B.__exportStar || function(r, i) {
                    for (var o in r) o !== "default" && !Object.prototype.hasOwnProperty.call(i, o) && t(i, r, o)
                };
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), n(sr, e), n(wn, e)
        }(za);
    const q = new za.Emitter;
    var bn = (e => (e.BottomLeft = "bottomLeft", e.BottomRight = "bottomRight", e.Center = "center", e.TopLeft = "topLeft", e.TopRight = "topRight", e))(bn || {}),
        Ne = (e => (e.Error = "x-ul-error", e.EnvironmentID = "x-ul-environment-id", e.InstallationMethod = "x-ul-installation-method", e.PartnerAnonymousId = "x-ul-anonymous-id", e.Platform = "userleap-platform", e.PreviewMode = "x-ul-preview-mode", e.UserID = "x-ul-user-id", e.VisitorID = "x-ul-visitor-id", e))(Ne || {}),
        Tt = (e => (e.Email = "email", e.Link = "link", e.Web = "web", e))(Tt || {}),
        Lt = (e => (e.Npm = "web-npm", e.Gtm = "web-gtm", e.Segment = "web-segment", e.SegmentAndroid = "android-segment", e.SegmentReactNative = "react-native-segment", e.SegmentIOS = "ios-segment", e.Snippet = "web-snippet", e))(Lt || {});
    const ur = e => new Promise(t => {
            setTimeout(() => {
                t()
            }, e)
        }),
        Qt = ({
            "userleap-platform": e
        }) => e !== Tt.Web,
        ie = (e, t) => {
            const n = t ? A.MobileSuffix : A.DesktopSuffix;
            return [e + n, e]
        },
        Me = (e, t) => [e, `${e}__${t}`];
    class Ef {
        constructor(t) {
            me(this, "payload");
            me(this, "promise");
            me(this, "reject", () => {});
            me(this, "resolve", () => {});
            this.payload = t, this.promise = new Promise((n, r) => {
                this.reject = r, this.resolve = n
            })
        }
        resolveRequest(t) {
            this.resolve(t)
        }
    }
    const xf = {
        RATELIMIT_RESET_DEFAULT: 10
    };
    let Wa = !1,
        Ya = "",
        cr = !1,
        dr = [];
    const Cf = e => e._config && e._config.installationMethod ? e._config.installationMethod : e._gtm ? Lt.Gtm : e._segment ? Lt.Segment : Lt.Snippet,
        Ii = (e = "") => {
            Wa = !0, Ya = e
        };

    function En(e = {}) {
        const t = {
            "Content-Type": "application/json",
            "userleap-platform": Tt.Web,
            "x-ul-sdk-version": "2.24.1",
            [Ne.InstallationMethod]: Cf(e)
        };
        if (e.envId && (t[Ne.EnvironmentID] = e.envId), e.token && (t.Authorization = "Bearer " + e.token), e.userId && (t[Ne.UserID] = e.userId), e.visitorId && (t[Ne.VisitorID] = e.visitorId), e.partnerAnonymousId && (t[Ne.PartnerAnonymousId] = e.partnerAnonymousId), e.mobileHeadersJSON) {
            const n = JSON.parse(e.mobileHeadersJSON);
            Object.assign(t, n)
        }
        return e.locale && (t["accept-language"] = e.locale), window.previewMode && (t[Ne.PreviewMode] = "1"), t
    }
    const Qa = async (e, t, n) => {
            if (e) return {
                status: 429
            }; {
                const r = new Ef(n);
                return dr.push(r), r.promise
            }
        },
        je = async (e, t, n = 0, r = !1, i = !1) => {
            const o = {
                url: e,
                options: t,
                attempt: n,
                shouldDropOnRateLimit: r
            };
            if (cr && !i) return Qa(r, i, o);
            const a = {
                ok: !1,
                reportError: !1
            };
            if (Wa) return console.info(`UserLeap - ${Ya}`), a;
            try {
                t.headers = Object.assign(En(), t.headers);
                const s = await fetch(e, t);
                if (s.status === 429)
                    if (!cr && !r || i) {
                        cr = !0;
                        const u = s.headers.has("ratelimit-reset") ? Number(s.headers.get("ratelimit-reset")) : xf.RATELIMIT_RESET_DEFAULT;
                        return await ur(u * 1e3), je(e, t, 0, r, !0)
                    } else return Qa(r, !1, o);
                if (cr = !1, dr.length && (dr.map(l => {
                        const {
                            url: u,
                            options: c,
                            attempt: f,
                            shouldDropOnRateLimit: d
                        } = l.payload;
                        je(u, c, f, d).then(p => {
                            l.resolveRequest(p)
                        })
                    }), dr = []), s.ok) {
                    if (s.status === 249) return Ii(), a;
                    const l = await s.text();
                    try {
                        return l && l !== "OK" && (s.json = JSON.parse(l)), s
                    } catch {
                        return {
                            ok: !1,
                            reportError: !1,
                            error: new Error(`failed parsing response json for ${e} - ${l}`)
                        }
                    }
                }
                return s
            } catch (s) {
                const l = n + 1;
                return l > 5 ? {
                    ok: !1,
                    reportError: !1,
                    error: s
                } : (await ur(Math.pow(2, n) * 1e3), je(e, t, l))
            }
        };
    var Za = {
        exports: {}
    };
    (function(e, t) {
        (function(n, r) {
            e.exports = r()
        })(B, function() {
            var n = function(o, a) {
                if (a = a || {}, typeof o != "function") throw new i("fetch must be a function");
                if (typeof a != "object") throw new i("defaults must be an object");
                if (a.retries !== void 0 && !r(a.retries)) throw new i("retries must be a positive integer");
                if (a.retryDelay !== void 0 && !r(a.retryDelay) && typeof a.retryDelay != "function") throw new i("retryDelay must be a positive integer or a function returning a positive integer");
                if (a.retryOn !== void 0 && !Array.isArray(a.retryOn) && typeof a.retryOn != "function") throw new i("retryOn property expects an array or function");
                var s = {
                    retries: 3,
                    retryDelay: 1e3,
                    retryOn: []
                };
                return a = Object.assign(s, a),
                    function(u, c) {
                        var f = a.retries,
                            d = a.retryDelay,
                            p = a.retryOn;
                        if (c && c.retries !== void 0)
                            if (r(c.retries)) f = c.retries;
                            else throw new i("retries must be a positive integer");
                        if (c && c.retryDelay !== void 0)
                            if (r(c.retryDelay) || typeof c.retryDelay == "function") d = c.retryDelay;
                            else throw new i("retryDelay must be a positive integer or a function returning a positive integer");
                        if (c && c.retryOn)
                            if (Array.isArray(c.retryOn) || typeof c.retryOn == "function") p = c.retryOn;
                            else throw new i("retryOn property expects an array or function");
                        return new Promise(function(h, v) {
                            var m = function(_) {
                                var E = typeof Request < "u" && u instanceof Request ? u.clone() : u;
                                o(E, c).then(function(b) {
                                    if (Array.isArray(p) && p.indexOf(b.status) === -1) h(b);
                                    else if (typeof p == "function") try {
                                        return Promise.resolve(p(_, null, b)).then(function(w) {
                                            w ? y(_, null, b) : h(b)
                                        }).catch(v)
                                    } catch (w) {
                                        v(w)
                                    } else _ < f ? y(_, null, b) : h(b)
                                }).catch(function(b) {
                                    if (typeof p == "function") try {
                                        Promise.resolve(p(_, b, null)).then(function(w) {
                                            w ? y(_, b, null) : v(b)
                                        }).catch(function(w) {
                                            v(w)
                                        })
                                    } catch (w) {
                                        v(w)
                                    } else _ < f ? y(_, b, null) : v(b)
                                })
                            };

                            function y(_, E, b) {
                                var w = typeof d == "function" ? d(_, E, b) : d;
                                setTimeout(function() {
                                    m(++_)
                                }, w)
                            }
                            m(0)
                        })
                    }
            };

            function r(o) {
                return Number.isInteger(o) && o >= 0
            }

            function i(o) {
                this.name = "ArgumentError", this.message = o
            }
            return n
        })
    })(Za);
    const Sf = Za.exports;
    class If {
        constructor(t) {
            me(this, "awaitingResolvers", []);
            me(this, "activeCount", 0);
            this.capacity = t
        }
        async acquire() {
            if (this.activeCount < this.capacity) {
                this.activeCount++;
                return
            }
            return new Promise(t => {
                this.awaitingResolvers.push(t)
            })
        }
        release() {
            const t = this.awaitingResolvers.shift();
            t && this.activeCount <= this.capacity ? t() : this.activeCount--
        }
        async execute(t) {
            try {
                return await this.acquire(), await t()
            } finally {
                this.release()
            }
        }
        setLimit(t) {
            this.capacity = t
        }
    }
    const Xa = new If(2),
        kf = e => Xa.setLimit(e),
        Tf = Sf(fetch),
        Lf = async (e, t = 3) => Xa.execute(async () => {
            const r = (await Tf(e.uploadUrl, {
                body: e.data,
                method: "PUT",
                retries: t,
                retryDelay: i => Math.pow(2, i) * 1e3
            })).headers.get("ETag");
            if (!r) throw new Error(`Upload response did not include etag for upload ${e.uploadId}, part ${e.chunkIndex}`);
            return r
        }),
        Rf = async ({
            apiUrl: e,
            surveyId: t,
            uploadId: n,
            etags: r,
            headers: i,
            responseGroupUuid: o,
            replayDuration: a
        }) => je(`${e}/sdk/1/completeSessionReplay`, {
            method: "POST",
            body: JSON.stringify({
                etags: r,
                uploadId: n,
                responseGroupUuid: o,
                surveyId: t,
                replayDuration: a
            }),
            headers: i
        });
    /*! *****************************************************************************
    Copyright (c) Microsoft Corporation.
    Permission to use, copy, modify, and/or distribute this software for any
    purpose with or without fee is hereby granted.
    THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
    REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
    AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
    INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
    LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
    OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
    PERFORMANCE OF THIS SOFTWARE.
    ***************************************************************************** */
    var $ = function() {
        return $ = Object.assign || function(t) {
            for (var n, r = 1, i = arguments.length; r < i; r++) {
                n = arguments[r];
                for (var o in n) Object.prototype.hasOwnProperty.call(n, o) && (t[o] = n[o])
            }
            return t
        }, $.apply(this, arguments)
    };

    function ki(e, t, n) {
        if (n || arguments.length === 2)
            for (var r = 0, i = t.length, o; r < i; r++)(o || !(r in t)) && (o || (o = Array.prototype.slice.call(t, 0, r)), o[r] = t[r]);
        return e.concat(o || Array.prototype.slice.call(t))
    }
    var Q = typeof globalThis < "u" ? globalThis : typeof self < "u" ? self : typeof window < "u" ? window : global,
        re = Object.keys,
        ce = Array.isArray;
    typeof Promise < "u" && !Q.Promise && (Q.Promise = Promise);

    function pe(e, t) {
        return typeof t != "object" || re(t).forEach(function(n) {
            e[n] = t[n]
        }), e
    }
    var xn = Object.getPrototypeOf,
        Af = {}.hasOwnProperty;

    function _e(e, t) {
        return Af.call(e, t)
    }

    function Zt(e, t) {
        typeof t == "function" && (t = t(xn(e))), (typeof Reflect > "u" ? re : Reflect.ownKeys)(t).forEach(function(n) {
            Qe(e, n, t[n])
        })
    }
    var Ja = Object.defineProperty;

    function Qe(e, t, n, r) {
        Ja(e, t, pe(n && _e(n, "get") && typeof n.get == "function" ? {
            get: n.get,
            set: n.set,
            configurable: !0
        } : {
            value: n,
            configurable: !0,
            writable: !0
        }, r))
    }

    function Xt(e) {
        return {
            from: function(t) {
                return e.prototype = Object.create(t.prototype), Qe(e.prototype, "constructor", e), {
                    extend: Zt.bind(null, e.prototype)
                }
            }
        }
    }
    var Of = Object.getOwnPropertyDescriptor;

    function Ti(e, t) {
        var n = Of(e, t),
            r;
        return n || (r = xn(e)) && Ti(r, t)
    }
    var Df = [].slice;

    function fr(e, t, n) {
        return Df.call(e, t, n)
    }

    function es(e, t) {
        return t(e)
    }

    function Cn(e) {
        if (!e) throw new Error("Assertion Failed")
    }

    function ts(e) {
        Q.setImmediate ? setImmediate(e) : setTimeout(e, 0)
    }

    function ns(e, t) {
        return e.reduce(function(n, r, i) {
            var o = t(r, i);
            return o && (n[o[0]] = o[1]), n
        }, {})
    }

    function Uf(e, t, n) {
        try {
            e.apply(null, n)
        } catch (r) {
            t && t(r)
        }
    }

    function Ze(e, t) {
        if (_e(e, t)) return e[t];
        if (!t) return e;
        if (typeof t != "string") {
            for (var n = [], r = 0, i = t.length; r < i; ++r) {
                var o = Ze(e, t[r]);
                n.push(o)
            }
            return n
        }
        var a = t.indexOf(".");
        if (a !== -1) {
            var s = e[t.substr(0, a)];
            return s === void 0 ? void 0 : Ze(s, t.substr(a + 1))
        }
    }

    function Le(e, t, n) {
        if (!(!e || t === void 0) && !("isFrozen" in Object && Object.isFrozen(e)))
            if (typeof t != "string" && "length" in t) {
                Cn(typeof n != "string" && "length" in n);
                for (var r = 0, i = t.length; r < i; ++r) Le(e, t[r], n[r])
            } else {
                var o = t.indexOf(".");
                if (o !== -1) {
                    var a = t.substr(0, o),
                        s = t.substr(o + 1);
                    if (s === "") n === void 0 ? ce(e) && !isNaN(parseInt(a)) ? e.splice(a, 1) : delete e[a] : e[a] = n;
                    else {
                        var l = e[a];
                        (!l || !_e(e, a)) && (l = e[a] = {}), Le(l, s, n)
                    }
                } else n === void 0 ? ce(e) && !isNaN(parseInt(t)) ? e.splice(t, 1) : delete e[t] : e[t] = n
            }
    }

    function Pf(e, t) {
        typeof t == "string" ? Le(e, t, void 0) : "length" in t && [].map.call(t, function(n) {
            Le(e, n, void 0)
        })
    }

    function rs(e) {
        var t = {};
        for (var n in e) _e(e, n) && (t[n] = e[n]);
        return t
    }
    var Nf = [].concat;

    function is(e) {
        return Nf.apply([], e)
    }
    var os = "Boolean,String,Date,RegExp,Blob,File,FileList,FileSystemFileHandle,ArrayBuffer,DataView,Uint8ClampedArray,ImageBitmap,ImageData,Map,Set,CryptoKey".split(",").concat(is([8, 16, 32, 64].map(function(e) {
            return ["Int", "Uint", "Float"].map(function(t) {
                return t + e + "Array"
            })
        }))).filter(function(e) {
            return Q[e]
        }),
        Mf = os.map(function(e) {
            return Q[e]
        });
    ns(os, function(e) {
        return [e, !0]
    });
    var dt = null;

    function Sn(e) {
        dt = typeof WeakMap < "u" && new WeakMap;
        var t = Li(e);
        return dt = null, t
    }

    function Li(e) {
        if (!e || typeof e != "object") return e;
        var t = dt && dt.get(e);
        if (t) return t;
        if (ce(e)) {
            t = [], dt && dt.set(e, t);
            for (var n = 0, r = e.length; n < r; ++n) t.push(Li(e[n]))
        } else if (Mf.indexOf(e.constructor) >= 0) t = e;
        else {
            var i = xn(e);
            t = i === Object.prototype ? {} : Object.create(i), dt && dt.set(e, t);
            for (var o in e) _e(e, o) && (t[o] = Li(e[o]))
        }
        return t
    }
    var jf = {}.toString;

    function Ri(e) {
        return jf.call(e).slice(8, -1)
    }
    var Ai = typeof Symbol < "u" ? Symbol.iterator : "@@iterator",
        Vf = typeof Ai == "symbol" ? function(e) {
            var t;
            return e != null && (t = e[Ai]) && t.apply(e)
        } : function() {
            return null
        },
        Jt = {};

    function Xe(e) {
        var t, n, r, i;
        if (arguments.length === 1) {
            if (ce(e)) return e.slice();
            if (this === Jt && typeof e == "string") return [e];
            if (i = Vf(e)) {
                for (n = []; r = i.next(), !r.done;) n.push(r.value);
                return n
            }
            if (e == null) return [e];
            if (t = e.length, typeof t == "number") {
                for (n = new Array(t); t--;) n[t] = e[t];
                return n
            }
            return [e]
        }
        for (t = arguments.length, n = new Array(t); t--;) n[t] = arguments[t];
        return n
    }
    var Oi = typeof Symbol < "u" ? function(e) {
            return e[Symbol.toStringTag] === "AsyncFunction"
        } : function() {
            return !1
        },
        Ve = typeof location < "u" && /^(http|https):\/\/(localhost|127\.0\.0\.1)/.test(location.href);

    function as(e, t) {
        Ve = e, ss = t
    }
    var ss = function() {
            return !0
        },
        Ff = !new Error("").stack;

    function Rt() {
        if (Ff) try {
            throw Rt.arguments, new Error
        } catch (e) {
            return e
        }
        return new Error
    }

    function Di(e, t) {
        var n = e.stack;
        return n ? (t = t || 0, n.indexOf(e.name) === 0 && (t += (e.name + e.message).split(`
`).length), n.split(`
`).slice(t).filter(ss).map(function(r) {
            return `
` + r
        }).join("")) : ""
    }
    var Bf = ["Modify", "Bulk", "OpenFailed", "VersionChange", "Schema", "Upgrade", "InvalidTable", "MissingAPI", "NoSuchDatabase", "InvalidArgument", "SubTransaction", "Unsupported", "Internal", "DatabaseClosed", "PrematureCommit", "ForeignAwait"],
        ls = ["Unknown", "Constraint", "Data", "TransactionInactive", "ReadOnly", "Version", "NotFound", "InvalidState", "InvalidAccess", "Abort", "Timeout", "QuotaExceeded", "Syntax", "DataClone"],
        Ui = Bf.concat(ls),
        Hf = {
            VersionChanged: "Database version changed by other database connection",
            DatabaseClosed: "Database has been closed",
            Abort: "Transaction aborted",
            TransactionInactive: "Transaction has already completed or failed",
            MissingAPI: "IndexedDB API missing. Please visit https://tinyurl.com/y2uuvskb"
        };

    function en(e, t) {
        this._e = Rt(), this.name = e, this.message = t
    }
    Xt(en).from(Error).extend({
        stack: {
            get: function() {
                return this._stack || (this._stack = this.name + ": " + this.message + Di(this._e, 2))
            }
        },
        toString: function() {
            return this.name + ": " + this.message
        }
    });

    function us(e, t) {
        return e + ". Errors: " + Object.keys(t).map(function(n) {
            return t[n].toString()
        }).filter(function(n, r, i) {
            return i.indexOf(n) === r
        }).join(`
`)
    }

    function pr(e, t, n, r) {
        this._e = Rt(), this.failures = t, this.failedKeys = r, this.successCount = n, this.message = us(e, t)
    }
    Xt(pr).from(en);

    function In(e, t) {
        this._e = Rt(), this.name = "BulkError", this.failures = Object.keys(t).map(function(n) {
            return t[n]
        }), this.failuresByPos = t, this.message = us(e, t)
    }
    Xt(In).from(en);
    var Pi = Ui.reduce(function(e, t) {
            return e[t] = t + "Error", e
        }, {}),
        Kf = en,
        j = Ui.reduce(function(e, t) {
            var n = t + "Error";

            function r(i, o) {
                this._e = Rt(), this.name = n, i ? typeof i == "string" ? (this.message = "" + i + (o ? `
 ` + o : ""), this.inner = o || null) : typeof i == "object" && (this.message = i.name + " " + i.message, this.inner = i) : (this.message = Hf[t] || n, this.inner = null)
            }
            return Xt(r).from(Kf), e[t] = r, e
        }, {});
    j.Syntax = SyntaxError, j.Type = TypeError, j.Range = RangeError;
    var cs = ls.reduce(function(e, t) {
        return e[t + "Error"] = j[t], e
    }, {});

    function $f(e, t) {
        if (!e || e instanceof en || e instanceof TypeError || e instanceof SyntaxError || !e.name || !cs[e.name]) return e;
        var n = new cs[e.name](t || e.message, e);
        return "stack" in e && Qe(n, "stack", {
            get: function() {
                return this.inner.stack
            }
        }), n
    }
    var hr = Ui.reduce(function(e, t) {
        return ["Syntax", "Type", "Range"].indexOf(t) === -1 && (e[t + "Error"] = j[t]), e
    }, {});
    hr.ModifyError = pr, hr.DexieError = en, hr.BulkError = In;

    function W() {}

    function kn(e) {
        return e
    }

    function Gf(e, t) {
        return e == null || e === kn ? t : function(n) {
            return t(e(n))
        }
    }

    function At(e, t) {
        return function() {
            e.apply(this, arguments), t.apply(this, arguments)
        }
    }

    function qf(e, t) {
        return e === W ? t : function() {
            var n = e.apply(this, arguments);
            n !== void 0 && (arguments[0] = n);
            var r = this.onsuccess,
                i = this.onerror;
            this.onsuccess = null, this.onerror = null;
            var o = t.apply(this, arguments);
            return r && (this.onsuccess = this.onsuccess ? At(r, this.onsuccess) : r), i && (this.onerror = this.onerror ? At(i, this.onerror) : i), o !== void 0 ? o : n
        }
    }

    function zf(e, t) {
        return e === W ? t : function() {
            e.apply(this, arguments);
            var n = this.onsuccess,
                r = this.onerror;
            this.onsuccess = this.onerror = null, t.apply(this, arguments), n && (this.onsuccess = this.onsuccess ? At(n, this.onsuccess) : n), r && (this.onerror = this.onerror ? At(r, this.onerror) : r)
        }
    }

    function Wf(e, t) {
        return e === W ? t : function(n) {
            var r = e.apply(this, arguments);
            pe(n, r);
            var i = this.onsuccess,
                o = this.onerror;
            this.onsuccess = null, this.onerror = null;
            var a = t.apply(this, arguments);
            return i && (this.onsuccess = this.onsuccess ? At(i, this.onsuccess) : i), o && (this.onerror = this.onerror ? At(o, this.onerror) : o), r === void 0 ? a === void 0 ? void 0 : a : pe(r, a)
        }
    }

    function Yf(e, t) {
        return e === W ? t : function() {
            return t.apply(this, arguments) === !1 ? !1 : e.apply(this, arguments)
        }
    }

    function Ni(e, t) {
        return e === W ? t : function() {
            var n = e.apply(this, arguments);
            if (n && typeof n.then == "function") {
                for (var r = this, i = arguments.length, o = new Array(i); i--;) o[i] = arguments[i];
                return n.then(function() {
                    return t.apply(r, o)
                })
            }
            return t.apply(this, arguments)
        }
    }
    var Tn = {},
        Qf = 100,
        Zf = 20,
        ds = 100,
        Mi = typeof Promise > "u" ? [] : function() {
            var e = Promise.resolve();
            if (typeof crypto > "u" || !crypto.subtle) return [e, xn(e), e];
            var t = crypto.subtle.digest("SHA-512", new Uint8Array([0]));
            return [t, xn(t), e]
        }(),
        ji = Mi[0],
        vr = Mi[1],
        Vi = Mi[2],
        fs = vr && vr.then,
        mr = ji && ji.constructor,
        Fi = !!Vi,
        Bi = !1,
        Xf = Vi ? function() {
            Vi.then(wr)
        } : Q.setImmediate ? setImmediate.bind(null, wr) : Q.MutationObserver ? function() {
            var e = document.createElement("div");
            new MutationObserver(function() {
                wr(), e = null
            }).observe(e, {
                attributes: !0
            }), e.setAttribute("i", "1")
        } : function() {
            setTimeout(wr, 0)
        },
        Ln = function(e, t) {
            Rn.push([e, t]), gr && (Xf(), gr = !1)
        },
        Hi = !0,
        gr = !0,
        Ot = [],
        _r = [],
        Ki = null,
        $i = kn,
        tn = {
            id: "global",
            global: !0,
            ref: 0,
            unhandleds: [],
            onunhandled: Es,
            pgp: !1,
            env: {},
            finalize: function() {
                this.unhandleds.forEach(function(e) {
                    try {
                        Es(e[0], e[1])
                    } catch {}
                })
            }
        },
        N = tn,
        Rn = [],
        Dt = 0,
        yr = [];

    function O(e) {
        if (typeof this != "object") throw new TypeError("Promises must be constructed via new");
        this._listeners = [], this.onuncatched = W, this._lib = !1;
        var t = this._PSD = N;
        if (Ve && (this._stackHolder = Rt(), this._prev = null, this._numPrev = 0), typeof e != "function") {
            if (e !== Tn) throw new TypeError("Not a function");
            this._state = arguments[1], this._value = arguments[2], this._state === !1 && qi(this, this._value);
            return
        }
        this._state = null, this._value = null, ++t.ref, hs(this, e)
    }
    var Gi = {
        get: function() {
            var e = N,
                t = xr;

            function n(r, i) {
                var o = this,
                    a = !e.global && (e !== N || t !== xr),
                    s = a && !Je(),
                    l = new O(function(u, c) {
                        zi(o, new ps(Sr(r, e, a, s), Sr(i, e, a, s), u, c, e))
                    });
                return Ve && gs(l, this), l
            }
            return n.prototype = Tn, n
        },
        set: function(e) {
            Qe(this, "then", e && e.prototype === Tn ? Gi : {
                get: function() {
                    return e
                },
                set: Gi.set
            })
        }
    };
    Zt(O.prototype, {
        then: Gi,
        _then: function(e, t) {
            zi(this, new ps(null, null, e, t, N))
        },
        catch: function(e) {
            if (arguments.length === 1) return this.then(null, e);
            var t = arguments[0],
                n = arguments[1];
            return typeof t == "function" ? this.then(null, function(r) {
                return r instanceof t ? n(r) : br(r)
            }) : this.then(null, function(r) {
                return r && r.name === t ? n(r) : br(r)
            })
        },
        finally: function(e) {
            return this.then(function(t) {
                return e(), t
            }, function(t) {
                return e(), br(t)
            })
        },
        stack: {
            get: function() {
                if (this._stack) return this._stack;
                try {
                    Bi = !0;
                    var e = ms(this, [], Zf),
                        t = e.join(`
From previous: `);
                    return this._state !== null && (this._stack = t), t
                } finally {
                    Bi = !1
                }
            }
        },
        timeout: function(e, t) {
            var n = this;
            return e < 1 / 0 ? new O(function(r, i) {
                var o = setTimeout(function() {
                    return i(new j.Timeout(t))
                }, e);
                n.then(r, i).finally(clearTimeout.bind(null, o))
            }) : this
        }
    }), typeof Symbol < "u" && Symbol.toStringTag && Qe(O.prototype, Symbol.toStringTag, "Dexie.Promise"), tn.env = _s();

    function ps(e, t, n, r, i) {
        this.onFulfilled = typeof e == "function" ? e : null, this.onRejected = typeof t == "function" ? t : null, this.resolve = n, this.reject = r, this.psd = i
    }
    Zt(O, {
        all: function() {
            var e = Xe.apply(null, arguments).map(Cr);
            return new O(function(t, n) {
                e.length === 0 && t([]);
                var r = e.length;
                e.forEach(function(i, o) {
                    return O.resolve(i).then(function(a) {
                        e[o] = a, --r || t(e)
                    }, n)
                })
            })
        },
        resolve: function(e) {
            if (e instanceof O) return e;
            if (e && typeof e.then == "function") return new O(function(n, r) {
                e.then(n, r)
            });
            var t = new O(Tn, !0, e);
            return gs(t, Ki), t
        },
        reject: br,
        race: function() {
            var e = Xe.apply(null, arguments).map(Cr);
            return new O(function(t, n) {
                e.map(function(r) {
                    return O.resolve(r).then(t, n)
                })
            })
        },
        PSD: {
            get: function() {
                return N
            },
            set: function(e) {
                return N = e
            }
        },
        totalEchoes: {
            get: function() {
                return xr
            }
        },
        newPSD: ft,
        usePSD: rn,
        scheduler: {
            get: function() {
                return Ln
            },
            set: function(e) {
                Ln = e
            }
        },
        rejectionMapper: {
            get: function() {
                return $i
            },
            set: function(e) {
                $i = e
            }
        },
        follow: function(e, t) {
            return new O(function(n, r) {
                return ft(function(i, o) {
                    var a = N;
                    a.unhandleds = [], a.onunhandled = o, a.finalize = At(function() {
                        var s = this;
                        ep(function() {
                            s.unhandleds.length === 0 ? i() : o(s.unhandleds[0])
                        })
                    }, a.finalize), e()
                }, t, n, r)
            })
        }
    }), mr && (mr.allSettled && Qe(O, "allSettled", function() {
        var e = Xe.apply(null, arguments).map(Cr);
        return new O(function(t) {
            e.length === 0 && t([]);
            var n = e.length,
                r = new Array(n);
            e.forEach(function(i, o) {
                return O.resolve(i).then(function(a) {
                    return r[o] = {
                        status: "fulfilled",
                        value: a
                    }
                }, function(a) {
                    return r[o] = {
                        status: "rejected",
                        reason: a
                    }
                }).then(function() {
                    return --n || t(r)
                })
            })
        })
    }), mr.any && typeof AggregateError < "u" && Qe(O, "any", function() {
        var e = Xe.apply(null, arguments).map(Cr);
        return new O(function(t, n) {
            e.length === 0 && n(new AggregateError([]));
            var r = e.length,
                i = new Array(r);
            e.forEach(function(o, a) {
                return O.resolve(o).then(function(s) {
                    return t(s)
                }, function(s) {
                    i[a] = s, --r || n(new AggregateError(i))
                })
            })
        })
    }));

    function hs(e, t) {
        try {
            t(function(n) {
                if (e._state === null) {
                    if (n === e) throw new TypeError("A promise cannot be resolved with itself.");
                    var r = e._lib && An();
                    n && typeof n.then == "function" ? hs(e, function(i, o) {
                        n instanceof O ? n._then(i, o) : n.then(i, o)
                    }) : (e._state = !0, e._value = n, vs(e)), r && On()
                }
            }, qi.bind(null, e))
        } catch (n) {
            qi(e, n)
        }
    }

    function qi(e, t) {
        if (_r.push(t), e._state === null) {
            var n = e._lib && An();
            t = $i(t), e._state = !1, e._value = t, Ve && t !== null && typeof t == "object" && !t._promise && Uf(function() {
                var r = Ti(t, "stack");
                t._promise = e, Qe(t, "stack", {
                    get: function() {
                        return Bi ? r && (r.get ? r.get.apply(t) : r.value) : e.stack
                    }
                })
            }), tp(e), vs(e), n && On()
        }
    }

    function vs(e) {
        var t = e._listeners;
        e._listeners = [];
        for (var n = 0, r = t.length; n < r; ++n) zi(e, t[n]);
        var i = e._PSD;
        --i.ref || i.finalize(), Dt === 0 && (++Dt, Ln(function() {
            --Dt === 0 && Wi()
        }, []))
    }

    function zi(e, t) {
        if (e._state === null) {
            e._listeners.push(t);
            return
        }
        var n = e._state ? t.onFulfilled : t.onRejected;
        if (n === null) return (e._state ? t.resolve : t.reject)(e._value);
        ++t.psd.ref, ++Dt, Ln(Jf, [n, e, t])
    }

    function Jf(e, t, n) {
        try {
            Ki = t;
            var r, i = t._value;
            t._state ? r = e(i) : (_r.length && (_r = []), r = e(i), _r.indexOf(i) === -1 && np(t)), n.resolve(r)
        } catch (o) {
            n.reject(o)
        } finally {
            Ki = null, --Dt === 0 && Wi(), --n.psd.ref || n.psd.finalize()
        }
    }

    function ms(e, t, n) {
        if (t.length === n) return t;
        var r = "";
        if (e._state === !1) {
            var i = e._value,
                o, a;
            i != null ? (o = i.name || "Error", a = i.message || i, r = Di(i, 0)) : (o = i, a = ""), t.push(o + (a ? ": " + a : "") + r)
        }
        return Ve && (r = Di(e._stackHolder, 2), r && t.indexOf(r) === -1 && t.push(r), e._prev && ms(e._prev, t, n)), t
    }

    function gs(e, t) {
        var n = t ? t._numPrev + 1 : 0;
        n < Qf && (e._prev = t, e._numPrev = n)
    }

    function wr() {
        An() && On()
    }

    function An() {
        var e = Hi;
        return Hi = !1, gr = !1, e
    }

    function On() {
        var e, t, n;
        do
            for (; Rn.length > 0;)
                for (e = Rn, Rn = [], n = e.length, t = 0; t < n; ++t) {
                    var r = e[t];
                    r[0].apply(null, r[1])
                }
        while (Rn.length > 0);
        Hi = !0, gr = !0
    }

    function Wi() {
        var e = Ot;
        Ot = [], e.forEach(function(r) {
            r._PSD.onunhandled.call(null, r._value, r)
        });
        for (var t = yr.slice(0), n = t.length; n;) t[--n]()
    }

    function ep(e) {
        function t() {
            e(), yr.splice(yr.indexOf(t), 1)
        }
        yr.push(t), ++Dt, Ln(function() {
            --Dt === 0 && Wi()
        }, [])
    }

    function tp(e) {
        Ot.some(function(t) {
            return t._value === e._value
        }) || Ot.push(e)
    }

    function np(e) {
        for (var t = Ot.length; t;)
            if (Ot[--t]._value === e._value) {
                Ot.splice(t, 1);
                return
            }
    }

    function br(e) {
        return new O(Tn, !1, e)
    }

    function J(e, t) {
        var n = N;
        return function() {
            var r = An(),
                i = N;
            try {
                return pt(n, !0), e.apply(this, arguments)
            } catch (o) {
                t && t(o)
            } finally {
                pt(i, !1), r && On()
            }
        }
    }
    var de = {
            awaits: 0,
            echoes: 0,
            id: 0
        },
        rp = 0,
        Er = [],
        Yi = 0,
        xr = 0,
        ip = 0;

    function ft(e, t, n, r) {
        var i = N,
            o = Object.create(i);
        o.parent = i, o.ref = 0, o.global = !1, o.id = ++ip;
        var a = tn.env;
        o.env = Fi ? {
            Promise: O,
            PromiseProp: {
                value: O,
                configurable: !0,
                writable: !0
            },
            all: O.all,
            race: O.race,
            allSettled: O.allSettled,
            any: O.any,
            resolve: O.resolve,
            reject: O.reject,
            nthen: ws(a.nthen, o),
            gthen: ws(a.gthen, o)
        } : {}, t && pe(o, t), ++i.ref, o.finalize = function() {
            --this.parent.ref || this.parent.finalize()
        };
        var s = rn(o, e, n, r);
        return o.ref === 0 && o.finalize(), s
    }

    function nn() {
        return de.id || (de.id = ++rp), ++de.awaits, de.echoes += ds, de.id
    }

    function Je() {
        return de.awaits ? (--de.awaits === 0 && (de.id = 0), de.echoes = de.awaits * ds, !0) : !1
    }("" + fs).indexOf("[native code]") === -1 && (nn = Je = W);

    function Cr(e) {
        return de.echoes && e && e.constructor === mr ? (nn(), e.then(function(t) {
            return Je(), t
        }, function(t) {
            return Je(), oe(t)
        })) : e
    }

    function op(e) {
        ++xr, (!de.echoes || --de.echoes === 0) && (de.echoes = de.id = 0), Er.push(N), pt(e, !0)
    }

    function ap() {
        var e = Er[Er.length - 1];
        Er.pop(), pt(e, !1)
    }

    function pt(e, t) {
        var n = N;
        if ((t ? de.echoes && (!Yi++ || e !== N) : Yi && (!--Yi || e !== N)) && ys(t ? op.bind(null, e) : ap), e !== N && (N = e, n === tn && (tn.env = _s()), Fi)) {
            var r = tn.env.Promise,
                i = e.env;
            vr.then = i.nthen, r.prototype.then = i.gthen, (n.global || e.global) && (Object.defineProperty(Q, "Promise", i.PromiseProp), r.all = i.all, r.race = i.race, r.resolve = i.resolve, r.reject = i.reject, i.allSettled && (r.allSettled = i.allSettled), i.any && (r.any = i.any))
        }
    }

    function _s() {
        var e = Q.Promise;
        return Fi ? {
            Promise: e,
            PromiseProp: Object.getOwnPropertyDescriptor(Q, "Promise"),
            all: e.all,
            race: e.race,
            allSettled: e.allSettled,
            any: e.any,
            resolve: e.resolve,
            reject: e.reject,
            nthen: vr.then,
            gthen: e.prototype.then
        } : {}
    }

    function rn(e, t, n, r, i) {
        var o = N;
        try {
            return pt(e, !0), t(n, r, i)
        } finally {
            pt(o, !1)
        }
    }

    function ys(e) {
        fs.call(ji, e)
    }

    function Sr(e, t, n, r) {
        return typeof e != "function" ? e : function() {
            var i = N;
            n && nn(), pt(t, !0);
            try {
                return e.apply(this, arguments)
            } finally {
                pt(i, !1), r && ys(Je)
            }
        }
    }

    function ws(e, t) {
        return function(n, r) {
            return e.call(this, Sr(n, t), Sr(r, t))
        }
    }
    var bs = "unhandledrejection";

    function Es(e, t) {
        var n;
        try {
            n = t.onuncatched(e)
        } catch {}
        if (n !== !1) try {
            var r, i = {
                promise: t,
                reason: e
            };
            if (Q.document && document.createEvent ? (r = document.createEvent("Event"), r.initEvent(bs, !0, !0), pe(r, i)) : Q.CustomEvent && (r = new CustomEvent(bs, {
                    detail: i
                }), pe(r, i)), r && Q.dispatchEvent && (dispatchEvent(r), !Q.PromiseRejectionEvent && Q.onunhandledrejection)) try {
                Q.onunhandledrejection(r)
            } catch {}
            Ve && r && !r.defaultPrevented && console.warn("Unhandled rejection: " + (e.stack || e))
        } catch {}
    }
    var oe = O.reject;

    function Qi(e, t, n, r) {
        if (!e.idbdb || !e._state.openComplete && !N.letThrough && !e._vip) {
            if (e._state.openComplete) return oe(new j.DatabaseClosed(e._state.dbOpenError));
            if (!e._state.isBeingOpened) {
                if (!e._options.autoOpen) return oe(new j.DatabaseClosed);
                e.open().catch(W)
            }
            return e._state.dbReadyPromise.then(function() {
                return Qi(e, t, n, r)
            })
        } else {
            var i = e._createTransaction(t, n, e._dbSchema);
            try {
                i.create(), e._state.PR1398_maxLoop = 3
            } catch (o) {
                return o.name === Pi.InvalidState && e.isOpen() && --e._state.PR1398_maxLoop > 0 ? (console.warn("Dexie: Need to reopen db"), e._close(), e.open().then(function() {
                    return Qi(e, t, n, r)
                })) : oe(o)
            }
            return i._promise(t, function(o, a) {
                return ft(function() {
                    return N.trans = i, r(o, a, i)
                })
            }).then(function(o) {
                return i._completion.then(function() {
                    return o
                })
            })
        }
    }
    var xs = "3.2.3",
        Ut = String.fromCharCode(65535),
        Zi = -1 / 0,
        et = "Invalid key provided. Keys must be of type string, number, Date or Array<string | number | Date>.",
        Cs = "String expected.",
        Dn = [],
        Ir = typeof navigator < "u" && /(MSIE|Trident|Edge)/.test(navigator.userAgent),
        sp = Ir,
        lp = Ir,
        Ss = function(e) {
            return !/(dexie\.js|dexie\.min\.js)/.test(e)
        },
        kr = "__dbnames",
        Xi = "readonly",
        Ji = "readwrite";

    function Pt(e, t) {
        return e ? t ? function() {
            return e.apply(this, arguments) && t.apply(this, arguments)
        } : e : t
    }
    var Is = {
        type: 3,
        lower: -1 / 0,
        lowerOpen: !1,
        upper: [
            []
        ],
        upperOpen: !1
    };

    function Tr(e) {
        return typeof e == "string" && !/\./.test(e) ? function(t) {
            return t[e] === void 0 && e in t && (t = Sn(t), delete t[e]), t
        } : function(t) {
            return t
        }
    }
    var up = function() {
        function e() {}
        return e.prototype._trans = function(t, n, r) {
            var i = this._tx || N.trans,
                o = this.name;

            function a(l, u, c) {
                if (!c.schema[o]) throw new j.NotFound("Table " + o + " not part of transaction");
                return n(c.idbtrans, c)
            }
            var s = An();
            try {
                return i && i.db === this.db ? i === N.trans ? i._promise(t, a, r) : ft(function() {
                    return i._promise(t, a, r)
                }, {
                    trans: i,
                    transless: N.transless || N
                }) : Qi(this.db, t, [this.name], a)
            } finally {
                s && On()
            }
        }, e.prototype.get = function(t, n) {
            var r = this;
            return t && t.constructor === Object ? this.where(t).first(n) : this._trans("readonly", function(i) {
                return r.core.get({
                    trans: i,
                    key: t
                }).then(function(o) {
                    return r.hook.reading.fire(o)
                })
            }).then(n)
        }, e.prototype.where = function(t) {
            if (typeof t == "string") return new this.db.WhereClause(this, t);
            if (ce(t)) return new this.db.WhereClause(this, "[" + t.join("+") + "]");
            var n = re(t);
            if (n.length === 1) return this.where(n[0]).equals(t[n[0]]);
            var r = this.schema.indexes.concat(this.schema.primKey).filter(function(c) {
                return c.compound && n.every(function(f) {
                    return c.keyPath.indexOf(f) >= 0
                }) && c.keyPath.every(function(f) {
                    return n.indexOf(f) >= 0
                })
            })[0];
            if (r && this.db._maxKey !== Ut) return this.where(r.name).equals(r.keyPath.map(function(c) {
                return t[c]
            }));
            !r && Ve && console.warn("The query " + JSON.stringify(t) + " on " + this.name + " would benefit of a " + ("compound index [" + n.join("+") + "]"));
            var i = this.schema.idxByName,
                o = this.db._deps.indexedDB;

            function a(c, f) {
                try {
                    return o.cmp(c, f) === 0
                } catch {
                    return !1
                }
            }
            var s = n.reduce(function(c, f) {
                    var d = c[0],
                        p = c[1],
                        h = i[f],
                        v = t[f];
                    return [d || h, d || !h ? Pt(p, h && h.multi ? function(m) {
                        var y = Ze(m, f);
                        return ce(y) && y.some(function(_) {
                            return a(v, _)
                        })
                    } : function(m) {
                        return a(v, Ze(m, f))
                    }) : p]
                }, [null, null]),
                l = s[0],
                u = s[1];
            return l ? this.where(l.name).equals(t[l.keyPath]).filter(u) : r ? this.filter(u) : this.where(n).equals("")
        }, e.prototype.filter = function(t) {
            return this.toCollection().and(t)
        }, e.prototype.count = function(t) {
            return this.toCollection().count(t)
        }, e.prototype.offset = function(t) {
            return this.toCollection().offset(t)
        }, e.prototype.limit = function(t) {
            return this.toCollection().limit(t)
        }, e.prototype.each = function(t) {
            return this.toCollection().each(t)
        }, e.prototype.toArray = function(t) {
            return this.toCollection().toArray(t)
        }, e.prototype.toCollection = function() {
            return new this.db.Collection(new this.db.WhereClause(this))
        }, e.prototype.orderBy = function(t) {
            return new this.db.Collection(new this.db.WhereClause(this, ce(t) ? "[" + t.join("+") + "]" : t))
        }, e.prototype.reverse = function() {
            return this.toCollection().reverse()
        }, e.prototype.mapToClass = function(t) {
            this.schema.mappedClass = t;
            var n = function(r) {
                if (!r) return r;
                var i = Object.create(t.prototype);
                for (var o in r)
                    if (_e(r, o)) try {
                        i[o] = r[o]
                    } catch {}
                return i
            };
            return this.schema.readHook && this.hook.reading.unsubscribe(this.schema.readHook), this.schema.readHook = n, this.hook("reading", n), t
        }, e.prototype.defineClass = function() {
            function t(n) {
                pe(this, n)
            }
            return this.mapToClass(t)
        }, e.prototype.add = function(t, n) {
            var r = this,
                i = this.schema.primKey,
                o = i.auto,
                a = i.keyPath,
                s = t;
            return a && o && (s = Tr(a)(t)), this._trans("readwrite", function(l) {
                return r.core.mutate({
                    trans: l,
                    type: "add",
                    keys: n != null ? [n] : null,
                    values: [s]
                })
            }).then(function(l) {
                return l.numFailures ? O.reject(l.failures[0]) : l.lastResult
            }).then(function(l) {
                if (a) try {
                    Le(t, a, l)
                } catch {}
                return l
            })
        }, e.prototype.update = function(t, n) {
            if (typeof t == "object" && !ce(t)) {
                var r = Ze(t, this.schema.primKey.keyPath);
                if (r === void 0) return oe(new j.InvalidArgument("Given object does not contain its primary key"));
                try {
                    typeof n != "function" ? re(n).forEach(function(i) {
                        Le(t, i, n[i])
                    }) : n(t, {
                        value: t,
                        primKey: r
                    })
                } catch {}
                return this.where(":id").equals(r).modify(n)
            } else return this.where(":id").equals(t).modify(n)
        }, e.prototype.put = function(t, n) {
            var r = this,
                i = this.schema.primKey,
                o = i.auto,
                a = i.keyPath,
                s = t;
            return a && o && (s = Tr(a)(t)), this._trans("readwrite", function(l) {
                return r.core.mutate({
                    trans: l,
                    type: "put",
                    values: [s],
                    keys: n != null ? [n] : null
                })
            }).then(function(l) {
                return l.numFailures ? O.reject(l.failures[0]) : l.lastResult
            }).then(function(l) {
                if (a) try {
                    Le(t, a, l)
                } catch {}
                return l
            })
        }, e.prototype.delete = function(t) {
            var n = this;
            return this._trans("readwrite", function(r) {
                return n.core.mutate({
                    trans: r,
                    type: "delete",
                    keys: [t]
                })
            }).then(function(r) {
                return r.numFailures ? O.reject(r.failures[0]) : void 0
            })
        }, e.prototype.clear = function() {
            var t = this;
            return this._trans("readwrite", function(n) {
                return t.core.mutate({
                    trans: n,
                    type: "deleteRange",
                    range: Is
                })
            }).then(function(n) {
                return n.numFailures ? O.reject(n.failures[0]) : void 0
            })
        }, e.prototype.bulkGet = function(t) {
            var n = this;
            return this._trans("readonly", function(r) {
                return n.core.getMany({
                    keys: t,
                    trans: r
                }).then(function(i) {
                    return i.map(function(o) {
                        return n.hook.reading.fire(o)
                    })
                })
            })
        }, e.prototype.bulkAdd = function(t, n, r) {
            var i = this,
                o = Array.isArray(n) ? n : void 0;
            r = r || (o ? void 0 : n);
            var a = r ? r.allKeys : void 0;
            return this._trans("readwrite", function(s) {
                var l = i.schema.primKey,
                    u = l.auto,
                    c = l.keyPath;
                if (c && o) throw new j.InvalidArgument("bulkAdd(): keys argument invalid on tables with inbound keys");
                if (o && o.length !== t.length) throw new j.InvalidArgument("Arguments objects and keys must have the same length");
                var f = t.length,
                    d = c && u ? t.map(Tr(c)) : t;
                return i.core.mutate({
                    trans: s,
                    type: "add",
                    keys: o,
                    values: d,
                    wantResults: a
                }).then(function(p) {
                    var h = p.numFailures,
                        v = p.results,
                        m = p.lastResult,
                        y = p.failures,
                        _ = a ? v : m;
                    if (h === 0) return _;
                    throw new In(i.name + ".bulkAdd(): " + h + " of " + f + " operations failed", y)
                })
            })
        }, e.prototype.bulkPut = function(t, n, r) {
            var i = this,
                o = Array.isArray(n) ? n : void 0;
            r = r || (o ? void 0 : n);
            var a = r ? r.allKeys : void 0;
            return this._trans("readwrite", function(s) {
                var l = i.schema.primKey,
                    u = l.auto,
                    c = l.keyPath;
                if (c && o) throw new j.InvalidArgument("bulkPut(): keys argument invalid on tables with inbound keys");
                if (o && o.length !== t.length) throw new j.InvalidArgument("Arguments objects and keys must have the same length");
                var f = t.length,
                    d = c && u ? t.map(Tr(c)) : t;
                return i.core.mutate({
                    trans: s,
                    type: "put",
                    keys: o,
                    values: d,
                    wantResults: a
                }).then(function(p) {
                    var h = p.numFailures,
                        v = p.results,
                        m = p.lastResult,
                        y = p.failures,
                        _ = a ? v : m;
                    if (h === 0) return _;
                    throw new In(i.name + ".bulkPut(): " + h + " of " + f + " operations failed", y)
                })
            })
        }, e.prototype.bulkDelete = function(t) {
            var n = this,
                r = t.length;
            return this._trans("readwrite", function(i) {
                return n.core.mutate({
                    trans: i,
                    type: "delete",
                    keys: t
                })
            }).then(function(i) {
                var o = i.numFailures,
                    a = i.lastResult,
                    s = i.failures;
                if (o === 0) return a;
                throw new In(n.name + ".bulkDelete(): " + o + " of " + r + " operations failed", s)
            })
        }, e
    }();

    function Un(e) {
        var t = {},
            n = function(s, l) {
                if (l) {
                    for (var u = arguments.length, c = new Array(u - 1); --u;) c[u - 1] = arguments[u];
                    return t[s].subscribe.apply(null, c), e
                } else if (typeof s == "string") return t[s]
            };
        n.addEventType = o;
        for (var r = 1, i = arguments.length; r < i; ++r) o(arguments[r]);
        return n;

        function o(s, l, u) {
            if (typeof s == "object") return a(s);
            l || (l = Yf), u || (u = W);
            var c = {
                subscribers: [],
                fire: u,
                subscribe: function(f) {
                    c.subscribers.indexOf(f) === -1 && (c.subscribers.push(f), c.fire = l(c.fire, f))
                },
                unsubscribe: function(f) {
                    c.subscribers = c.subscribers.filter(function(d) {
                        return d !== f
                    }), c.fire = c.subscribers.reduce(l, u)
                }
            };
            return t[s] = n[s] = c, c
        }

        function a(s) {
            re(s).forEach(function(l) {
                var u = s[l];
                if (ce(u)) o(l, s[l][0], s[l][1]);
                else if (u === "asap") var c = o(l, kn, function() {
                    for (var d = arguments.length, p = new Array(d); d--;) p[d] = arguments[d];
                    c.subscribers.forEach(function(h) {
                        ts(function() {
                            h.apply(null, p)
                        })
                    })
                });
                else throw new j.InvalidArgument("Invalid event config")
            })
        }
    }

    function Pn(e, t) {
        return Xt(t).from({
            prototype: e
        }), t
    }

    function cp(e) {
        return Pn(up.prototype, function(n, r, i) {
            this.db = e, this._tx = i, this.name = n, this.schema = r, this.hook = e._allTables[n] ? e._allTables[n].hook : Un(null, {
                creating: [qf, W],
                reading: [Gf, kn],
                updating: [Wf, W],
                deleting: [zf, W]
            })
        })
    }

    function on(e, t) {
        return !(e.filter || e.algorithm || e.or) && (t ? e.justLimit : !e.replayFilter)
    }

    function eo(e, t) {
        e.filter = Pt(e.filter, t)
    }

    function to(e, t, n) {
        var r = e.replayFilter;
        e.replayFilter = r ? function() {
            return Pt(r(), t())
        } : t, e.justLimit = n && !r
    }

    function dp(e, t) {
        e.isMatch = Pt(e.isMatch, t)
    }

    function Lr(e, t) {
        if (e.isPrimKey) return t.primaryKey;
        var n = t.getIndexByKeyPath(e.index);
        if (!n) throw new j.Schema("KeyPath " + e.index + " on object store " + t.name + " is not indexed");
        return n
    }

    function ks(e, t, n) {
        var r = Lr(e, t.schema);
        return t.openCursor({
            trans: n,
            values: !e.keysOnly,
            reverse: e.dir === "prev",
            unique: !!e.unique,
            query: {
                index: r,
                range: e.range
            }
        })
    }

    function Rr(e, t, n, r) {
        var i = e.replayFilter ? Pt(e.filter, e.replayFilter()) : e.filter;
        if (e.or) {
            var o = {},
                a = function(s, l, u) {
                    if (!i || i(l, u, function(d) {
                            return l.stop(d)
                        }, function(d) {
                            return l.fail(d)
                        })) {
                        var c = l.primaryKey,
                            f = "" + c;
                        f === "[object ArrayBuffer]" && (f = "" + new Uint8Array(c)), _e(o, f) || (o[f] = !0, t(s, l, u))
                    }
                };
            return Promise.all([e.or._iterate(a, n), Ts(ks(e, r, n), e.algorithm, a, !e.keysOnly && e.valueMapper)])
        } else return Ts(ks(e, r, n), Pt(e.algorithm, i), t, !e.keysOnly && e.valueMapper)
    }

    function Ts(e, t, n, r) {
        var i = r ? function(a, s, l) {
                return n(r(a), s, l)
            } : n,
            o = J(i);
        return e.then(function(a) {
            if (a) return a.start(function() {
                var s = function() {
                    return a.continue()
                };
                (!t || t(a, function(l) {
                    return s = l
                }, function(l) {
                    a.stop(l), s = W
                }, function(l) {
                    a.fail(l), s = W
                })) && o(a.value, a, function(l) {
                    return s = l
                }), s()
            })
        })
    }

    function he(e, t) {
        try {
            var n = Ls(e),
                r = Ls(t);
            if (n !== r) return n === "Array" ? 1 : r === "Array" ? -1 : n === "binary" ? 1 : r === "binary" ? -1 : n === "string" ? 1 : r === "string" ? -1 : n === "Date" ? 1 : r !== "Date" ? NaN : -1;
            switch (n) {
                case "number":
                case "Date":
                case "string":
                    return e > t ? 1 : e < t ? -1 : 0;
                case "binary":
                    return pp(Rs(e), Rs(t));
                case "Array":
                    return fp(e, t)
            }
        } catch {}
        return NaN
    }

    function fp(e, t) {
        for (var n = e.length, r = t.length, i = n < r ? n : r, o = 0; o < i; ++o) {
            var a = he(e[o], t[o]);
            if (a !== 0) return a
        }
        return n === r ? 0 : n < r ? -1 : 1
    }

    function pp(e, t) {
        for (var n = e.length, r = t.length, i = n < r ? n : r, o = 0; o < i; ++o)
            if (e[o] !== t[o]) return e[o] < t[o] ? -1 : 1;
        return n === r ? 0 : n < r ? -1 : 1
    }

    function Ls(e) {
        var t = typeof e;
        if (t !== "object") return t;
        if (ArrayBuffer.isView(e)) return "binary";
        var n = Ri(e);
        return n === "ArrayBuffer" ? "binary" : n
    }

    function Rs(e) {
        return e instanceof Uint8Array ? e : ArrayBuffer.isView(e) ? new Uint8Array(e.buffer, e.byteOffset, e.byteLength) : new Uint8Array(e)
    }
    var hp = function() {
            function e() {}
            return e.prototype._read = function(t, n) {
                var r = this._ctx;
                return r.error ? r.table._trans(null, oe.bind(null, r.error)) : r.table._trans("readonly", t).then(n)
            }, e.prototype._write = function(t) {
                var n = this._ctx;
                return n.error ? n.table._trans(null, oe.bind(null, n.error)) : n.table._trans("readwrite", t, "locked")
            }, e.prototype._addAlgorithm = function(t) {
                var n = this._ctx;
                n.algorithm = Pt(n.algorithm, t)
            }, e.prototype._iterate = function(t, n) {
                return Rr(this._ctx, t, n, this._ctx.table.core)
            }, e.prototype.clone = function(t) {
                var n = Object.create(this.constructor.prototype),
                    r = Object.create(this._ctx);
                return t && pe(r, t), n._ctx = r, n
            }, e.prototype.raw = function() {
                return this._ctx.valueMapper = null, this
            }, e.prototype.each = function(t) {
                var n = this._ctx;
                return this._read(function(r) {
                    return Rr(n, t, r, n.table.core)
                })
            }, e.prototype.count = function(t) {
                var n = this;
                return this._read(function(r) {
                    var i = n._ctx,
                        o = i.table.core;
                    if (on(i, !0)) return o.count({
                        trans: r,
                        query: {
                            index: Lr(i, o.schema),
                            range: i.range
                        }
                    }).then(function(s) {
                        return Math.min(s, i.limit)
                    });
                    var a = 0;
                    return Rr(i, function() {
                        return ++a, !1
                    }, r, o).then(function() {
                        return a
                    })
                }).then(t)
            }, e.prototype.sortBy = function(t, n) {
                var r = t.split(".").reverse(),
                    i = r[0],
                    o = r.length - 1;

                function a(u, c) {
                    return c ? a(u[r[c]], c - 1) : u[i]
                }
                var s = this._ctx.dir === "next" ? 1 : -1;

                function l(u, c) {
                    var f = a(u, o),
                        d = a(c, o);
                    return f < d ? -s : f > d ? s : 0
                }
                return this.toArray(function(u) {
                    return u.sort(l)
                }).then(n)
            }, e.prototype.toArray = function(t) {
                var n = this;
                return this._read(function(r) {
                    var i = n._ctx;
                    if (i.dir === "next" && on(i, !0) && i.limit > 0) {
                        var o = i.valueMapper,
                            a = Lr(i, i.table.core.schema);
                        return i.table.core.query({
                            trans: r,
                            limit: i.limit,
                            values: !0,
                            query: {
                                index: a,
                                range: i.range
                            }
                        }).then(function(l) {
                            var u = l.result;
                            return o ? u.map(o) : u
                        })
                    } else {
                        var s = [];
                        return Rr(i, function(l) {
                            return s.push(l)
                        }, r, i.table.core).then(function() {
                            return s
                        })
                    }
                }, t)
            }, e.prototype.offset = function(t) {
                var n = this._ctx;
                return t <= 0 ? this : (n.offset += t, on(n) ? to(n, function() {
                    var r = t;
                    return function(i, o) {
                        return r === 0 ? !0 : r === 1 ? (--r, !1) : (o(function() {
                            i.advance(r), r = 0
                        }), !1)
                    }
                }) : to(n, function() {
                    var r = t;
                    return function() {
                        return --r < 0
                    }
                }), this)
            }, e.prototype.limit = function(t) {
                return this._ctx.limit = Math.min(this._ctx.limit, t), to(this._ctx, function() {
                    var n = t;
                    return function(r, i, o) {
                        return --n <= 0 && i(o), n >= 0
                    }
                }, !0), this
            }, e.prototype.until = function(t, n) {
                return eo(this._ctx, function(r, i, o) {
                    return t(r.value) ? (i(o), n) : !0
                }), this
            }, e.prototype.first = function(t) {
                return this.limit(1).toArray(function(n) {
                    return n[0]
                }).then(t)
            }, e.prototype.last = function(t) {
                return this.reverse().first(t)
            }, e.prototype.filter = function(t) {
                return eo(this._ctx, function(n) {
                    return t(n.value)
                }), dp(this._ctx, t), this
            }, e.prototype.and = function(t) {
                return this.filter(t)
            }, e.prototype.or = function(t) {
                return new this.db.WhereClause(this._ctx.table, t, this)
            }, e.prototype.reverse = function() {
                return this._ctx.dir = this._ctx.dir === "prev" ? "next" : "prev", this._ondirectionchange && this._ondirectionchange(this._ctx.dir), this
            }, e.prototype.desc = function() {
                return this.reverse()
            }, e.prototype.eachKey = function(t) {
                var n = this._ctx;
                return n.keysOnly = !n.isMatch, this.each(function(r, i) {
                    t(i.key, i)
                })
            }, e.prototype.eachUniqueKey = function(t) {
                return this._ctx.unique = "unique", this.eachKey(t)
            }, e.prototype.eachPrimaryKey = function(t) {
                var n = this._ctx;
                return n.keysOnly = !n.isMatch, this.each(function(r, i) {
                    t(i.primaryKey, i)
                })
            }, e.prototype.keys = function(t) {
                var n = this._ctx;
                n.keysOnly = !n.isMatch;
                var r = [];
                return this.each(function(i, o) {
                    r.push(o.key)
                }).then(function() {
                    return r
                }).then(t)
            }, e.prototype.primaryKeys = function(t) {
                var n = this._ctx;
                if (n.dir === "next" && on(n, !0) && n.limit > 0) return this._read(function(i) {
                    var o = Lr(n, n.table.core.schema);
                    return n.table.core.query({
                        trans: i,
                        values: !1,
                        limit: n.limit,
                        query: {
                            index: o,
                            range: n.range
                        }
                    })
                }).then(function(i) {
                    var o = i.result;
                    return o
                }).then(t);
                n.keysOnly = !n.isMatch;
                var r = [];
                return this.each(function(i, o) {
                    r.push(o.primaryKey)
                }).then(function() {
                    return r
                }).then(t)
            }, e.prototype.uniqueKeys = function(t) {
                return this._ctx.unique = "unique", this.keys(t)
            }, e.prototype.firstKey = function(t) {
                return this.limit(1).keys(function(n) {
                    return n[0]
                }).then(t)
            }, e.prototype.lastKey = function(t) {
                return this.reverse().firstKey(t)
            }, e.prototype.distinct = function() {
                var t = this._ctx,
                    n = t.index && t.table.schema.idxByName[t.index];
                if (!n || !n.multi) return this;
                var r = {};
                return eo(this._ctx, function(i) {
                    var o = i.primaryKey.toString(),
                        a = _e(r, o);
                    return r[o] = !0, !a
                }), this
            }, e.prototype.modify = function(t) {
                var n = this,
                    r = this._ctx;
                return this._write(function(i) {
                    var o;
                    if (typeof t == "function") o = t;
                    else {
                        var a = re(t),
                            s = a.length;
                        o = function(y) {
                            for (var _ = !1, E = 0; E < s; ++E) {
                                var b = a[E],
                                    w = t[b];
                                Ze(y, b) !== w && (Le(y, b, w), _ = !0)
                            }
                            return _
                        }
                    }
                    var l = r.table.core,
                        u = l.schema.primaryKey,
                        c = u.outbound,
                        f = u.extractKey,
                        d = n.db._options.modifyChunkSize || 200,
                        p = [],
                        h = 0,
                        v = [],
                        m = function(y, _) {
                            var E = _.failures,
                                b = _.numFailures;
                            h += y - b;
                            for (var w = 0, x = re(E); w < x.length; w++) {
                                var C = x[w];
                                p.push(E[C])
                            }
                        };
                    return n.clone().primaryKeys().then(function(y) {
                        var _ = function(E) {
                            var b = Math.min(d, y.length - E);
                            return l.getMany({
                                trans: i,
                                keys: y.slice(E, E + b),
                                cache: "immutable"
                            }).then(function(w) {
                                for (var x = [], C = [], I = c ? [] : null, k = [], L = 0; L < b; ++L) {
                                    var T = w[L],
                                        U = {
                                            value: Sn(T),
                                            primKey: y[E + L]
                                        };
                                    o.call(U, U.value, U) !== !1 && (U.value == null ? k.push(y[E + L]) : !c && he(f(T), f(U.value)) !== 0 ? (k.push(y[E + L]), x.push(U.value)) : (C.push(U.value), c && I.push(y[E + L])))
                                }
                                var S = on(r) && r.limit === 1 / 0 && (typeof t != "function" || t === no) && {
                                    index: r.index,
                                    range: r.range
                                };
                                return Promise.resolve(x.length > 0 && l.mutate({
                                    trans: i,
                                    type: "add",
                                    values: x
                                }).then(function(V) {
                                    for (var D in V.failures) k.splice(parseInt(D), 1);
                                    m(x.length, V)
                                })).then(function() {
                                    return (C.length > 0 || S && typeof t == "object") && l.mutate({
                                        trans: i,
                                        type: "put",
                                        keys: I,
                                        values: C,
                                        criteria: S,
                                        changeSpec: typeof t != "function" && t
                                    }).then(function(V) {
                                        return m(C.length, V)
                                    })
                                }).then(function() {
                                    return (k.length > 0 || S && t === no) && l.mutate({
                                        trans: i,
                                        type: "delete",
                                        keys: k,
                                        criteria: S
                                    }).then(function(V) {
                                        return m(k.length, V)
                                    })
                                }).then(function() {
                                    return y.length > E + b && _(E + d)
                                })
                            })
                        };
                        return _(0).then(function() {
                            if (p.length > 0) throw new pr("Error modifying one or more objects", p, h, v);
                            return y.length
                        })
                    })
                })
            }, e.prototype.delete = function() {
                var t = this._ctx,
                    n = t.range;
                return on(t) && (t.isPrimKey && !lp || n.type === 3) ? this._write(function(r) {
                    var i = t.table.core.schema.primaryKey,
                        o = n;
                    return t.table.core.count({
                        trans: r,
                        query: {
                            index: i,
                            range: o
                        }
                    }).then(function(a) {
                        return t.table.core.mutate({
                            trans: r,
                            type: "deleteRange",
                            range: o
                        }).then(function(s) {
                            var l = s.failures;
                            s.lastResult, s.results;
                            var u = s.numFailures;
                            if (u) throw new pr("Could not delete some values", Object.keys(l).map(function(c) {
                                return l[c]
                            }), a - u);
                            return a - u
                        })
                    })
                }) : this.modify(no)
            }, e
        }(),
        no = function(e, t) {
            return t.value = null
        };

    function vp(e) {
        return Pn(hp.prototype, function(n, r) {
            this.db = e;
            var i = Is,
                o = null;
            if (r) try {
                i = r()
            } catch (u) {
                o = u
            }
            var a = n._ctx,
                s = a.table,
                l = s.hook.reading.fire;
            this._ctx = {
                table: s,
                index: a.index,
                isPrimKey: !a.index || s.schema.primKey.keyPath && a.index === s.schema.primKey.name,
                range: i,
                keysOnly: !1,
                dir: "next",
                unique: "",
                algorithm: null,
                filter: null,
                replayFilter: null,
                justLimit: !0,
                isMatch: null,
                offset: 0,
                limit: 1 / 0,
                error: o,
                or: a.or,
                valueMapper: l !== kn ? l : null
            }
        })
    }

    function mp(e, t) {
        return e < t ? -1 : e === t ? 0 : 1
    }

    function gp(e, t) {
        return e > t ? -1 : e === t ? 0 : 1
    }

    function ye(e, t, n) {
        var r = e instanceof Os ? new e.Collection(e) : e;
        return r._ctx.error = n ? new n(t) : new TypeError(t), r
    }

    function an(e) {
        return new e.Collection(e, function() {
            return As("")
        }).limit(0)
    }

    function _p(e) {
        return e === "next" ? function(t) {
            return t.toUpperCase()
        } : function(t) {
            return t.toLowerCase()
        }
    }

    function yp(e) {
        return e === "next" ? function(t) {
            return t.toLowerCase()
        } : function(t) {
            return t.toUpperCase()
        }
    }

    function wp(e, t, n, r, i, o) {
        for (var a = Math.min(e.length, r.length), s = -1, l = 0; l < a; ++l) {
            var u = t[l];
            if (u !== r[l]) return i(e[l], n[l]) < 0 ? e.substr(0, l) + n[l] + n.substr(l + 1) : i(e[l], r[l]) < 0 ? e.substr(0, l) + r[l] + n.substr(l + 1) : s >= 0 ? e.substr(0, s) + t[s] + n.substr(s + 1) : null;
            i(e[l], u) < 0 && (s = l)
        }
        return a < r.length && o === "next" ? e + n.substr(e.length) : a < e.length && o === "prev" ? e.substr(0, n.length) : s < 0 ? null : e.substr(0, s) + r[s] + n.substr(s + 1)
    }

    function Ar(e, t, n, r) {
        var i, o, a, s, l, u, c, f = n.length;
        if (!n.every(function(v) {
                return typeof v == "string"
            })) return ye(e, Cs);

        function d(v) {
            i = _p(v), o = yp(v), a = v === "next" ? mp : gp;
            var m = n.map(function(y) {
                return {
                    lower: o(y),
                    upper: i(y)
                }
            }).sort(function(y, _) {
                return a(y.lower, _.lower)
            });
            s = m.map(function(y) {
                return y.upper
            }), l = m.map(function(y) {
                return y.lower
            }), u = v, c = v === "next" ? "" : r
        }
        d("next");
        var p = new e.Collection(e, function() {
            return ht(s[0], l[f - 1] + r)
        });
        p._ondirectionchange = function(v) {
            d(v)
        };
        var h = 0;
        return p._addAlgorithm(function(v, m, y) {
            var _ = v.key;
            if (typeof _ != "string") return !1;
            var E = o(_);
            if (t(E, l, h)) return !0;
            for (var b = null, w = h; w < f; ++w) {
                var x = wp(_, E, s[w], l[w], a, u);
                x === null && b === null ? h = w + 1 : (b === null || a(b, x) > 0) && (b = x)
            }
            return m(b !== null ? function() {
                v.continue(b + c)
            } : y), !1
        }), p
    }

    function ht(e, t, n, r) {
        return {
            type: 2,
            lower: e,
            upper: t,
            lowerOpen: n,
            upperOpen: r
        }
    }

    function As(e) {
        return {
            type: 1,
            lower: e,
            upper: e
        }
    }
    var Os = function() {
        function e() {}
        return Object.defineProperty(e.prototype, "Collection", {
            get: function() {
                return this._ctx.table.db.Collection
            },
            enumerable: !1,
            configurable: !0
        }), e.prototype.between = function(t, n, r, i) {
            r = r !== !1, i = i === !0;
            try {
                return this._cmp(t, n) > 0 || this._cmp(t, n) === 0 && (r || i) && !(r && i) ? an(this) : new this.Collection(this, function() {
                    return ht(t, n, !r, !i)
                })
            } catch {
                return ye(this, et)
            }
        }, e.prototype.equals = function(t) {
            return t == null ? ye(this, et) : new this.Collection(this, function() {
                return As(t)
            })
        }, e.prototype.above = function(t) {
            return t == null ? ye(this, et) : new this.Collection(this, function() {
                return ht(t, void 0, !0)
            })
        }, e.prototype.aboveOrEqual = function(t) {
            return t == null ? ye(this, et) : new this.Collection(this, function() {
                return ht(t, void 0, !1)
            })
        }, e.prototype.below = function(t) {
            return t == null ? ye(this, et) : new this.Collection(this, function() {
                return ht(void 0, t, !1, !0)
            })
        }, e.prototype.belowOrEqual = function(t) {
            return t == null ? ye(this, et) : new this.Collection(this, function() {
                return ht(void 0, t)
            })
        }, e.prototype.startsWith = function(t) {
            return typeof t != "string" ? ye(this, Cs) : this.between(t, t + Ut, !0, !0)
        }, e.prototype.startsWithIgnoreCase = function(t) {
            return t === "" ? this.startsWith(t) : Ar(this, function(n, r) {
                return n.indexOf(r[0]) === 0
            }, [t], Ut)
        }, e.prototype.equalsIgnoreCase = function(t) {
            return Ar(this, function(n, r) {
                return n === r[0]
            }, [t], "")
        }, e.prototype.anyOfIgnoreCase = function() {
            var t = Xe.apply(Jt, arguments);
            return t.length === 0 ? an(this) : Ar(this, function(n, r) {
                return r.indexOf(n) !== -1
            }, t, "")
        }, e.prototype.startsWithAnyOfIgnoreCase = function() {
            var t = Xe.apply(Jt, arguments);
            return t.length === 0 ? an(this) : Ar(this, function(n, r) {
                return r.some(function(i) {
                    return n.indexOf(i) === 0
                })
            }, t, Ut)
        }, e.prototype.anyOf = function() {
            var t = this,
                n = Xe.apply(Jt, arguments),
                r = this._cmp;
            try {
                n.sort(r)
            } catch {
                return ye(this, et)
            }
            if (n.length === 0) return an(this);
            var i = new this.Collection(this, function() {
                return ht(n[0], n[n.length - 1])
            });
            i._ondirectionchange = function(a) {
                r = a === "next" ? t._ascending : t._descending, n.sort(r)
            };
            var o = 0;
            return i._addAlgorithm(function(a, s, l) {
                for (var u = a.key; r(u, n[o]) > 0;)
                    if (++o, o === n.length) return s(l), !1;
                return r(u, n[o]) === 0 ? !0 : (s(function() {
                    a.continue(n[o])
                }), !1)
            }), i
        }, e.prototype.notEqual = function(t) {
            return this.inAnyRange([
                [Zi, t],
                [t, this.db._maxKey]
            ], {
                includeLowers: !1,
                includeUppers: !1
            })
        }, e.prototype.noneOf = function() {
            var t = Xe.apply(Jt, arguments);
            if (t.length === 0) return new this.Collection(this);
            try {
                t.sort(this._ascending)
            } catch {
                return ye(this, et)
            }
            var n = t.reduce(function(r, i) {
                return r ? r.concat([
                    [r[r.length - 1][1], i]
                ]) : [
                    [Zi, i]
                ]
            }, null);
            return n.push([t[t.length - 1], this.db._maxKey]), this.inAnyRange(n, {
                includeLowers: !1,
                includeUppers: !1
            })
        }, e.prototype.inAnyRange = function(t, n) {
            var r = this,
                i = this._cmp,
                o = this._ascending,
                a = this._descending,
                s = this._min,
                l = this._max;
            if (t.length === 0) return an(this);
            if (!t.every(function(w) {
                    return w[0] !== void 0 && w[1] !== void 0 && o(w[0], w[1]) <= 0
                })) return ye(this, "First argument to inAnyRange() must be an Array of two-value Arrays [lower,upper] where upper must not be lower than lower", j.InvalidArgument);
            var u = !n || n.includeLowers !== !1,
                c = n && n.includeUppers === !0;

            function f(w, x) {
                for (var C = 0, I = w.length; C < I; ++C) {
                    var k = w[C];
                    if (i(x[0], k[1]) < 0 && i(x[1], k[0]) > 0) {
                        k[0] = s(k[0], x[0]), k[1] = l(k[1], x[1]);
                        break
                    }
                }
                return C === I && w.push(x), w
            }
            var d = o;

            function p(w, x) {
                return d(w[0], x[0])
            }
            var h;
            try {
                h = t.reduce(f, []), h.sort(p)
            } catch {
                return ye(this, et)
            }
            var v = 0,
                m = c ? function(w) {
                    return o(w, h[v][1]) > 0
                } : function(w) {
                    return o(w, h[v][1]) >= 0
                },
                y = u ? function(w) {
                    return a(w, h[v][0]) > 0
                } : function(w) {
                    return a(w, h[v][0]) >= 0
                };

            function _(w) {
                return !m(w) && !y(w)
            }
            var E = m,
                b = new this.Collection(this, function() {
                    return ht(h[0][0], h[h.length - 1][1], !u, !c)
                });
            return b._ondirectionchange = function(w) {
                w === "next" ? (E = m, d = o) : (E = y, d = a), h.sort(p)
            }, b._addAlgorithm(function(w, x, C) {
                for (var I = w.key; E(I);)
                    if (++v, v === h.length) return x(C), !1;
                return _(I) ? !0 : (r._cmp(I, h[v][1]) === 0 || r._cmp(I, h[v][0]) === 0 || x(function() {
                    d === o ? w.continue(h[v][0]) : w.continue(h[v][1])
                }), !1)
            }), b
        }, e.prototype.startsWithAnyOf = function() {
            var t = Xe.apply(Jt, arguments);
            return t.every(function(n) {
                return typeof n == "string"
            }) ? t.length === 0 ? an(this) : this.inAnyRange(t.map(function(n) {
                return [n, n + Ut]
            })) : ye(this, "startsWithAnyOf() only works with strings")
        }, e
    }();

    function bp(e) {
        return Pn(Os.prototype, function(n, r, i) {
            this.db = e, this._ctx = {
                table: n,
                index: r === ":id" ? null : r,
                or: i
            };
            var o = e._deps.indexedDB;
            if (!o) throw new j.MissingAPI;
            this._cmp = this._ascending = o.cmp.bind(o), this._descending = function(a, s) {
                return o.cmp(s, a)
            }, this._max = function(a, s) {
                return o.cmp(a, s) > 0 ? a : s
            }, this._min = function(a, s) {
                return o.cmp(a, s) < 0 ? a : s
            }, this._IDBKeyRange = e._deps.IDBKeyRange
        })
    }

    function Fe(e) {
        return J(function(t) {
            return Nn(t), e(t.target.error), !1
        })
    }

    function Nn(e) {
        e.stopPropagation && e.stopPropagation(), e.preventDefault && e.preventDefault()
    }
    var Mn = "storagemutated",
        vt = "x-storagemutated-1",
        mt = Un(null, Mn),
        Ep = function() {
            function e() {}
            return e.prototype._lock = function() {
                return Cn(!N.global), ++this._reculock, this._reculock === 1 && !N.global && (N.lockOwnerFor = this), this
            }, e.prototype._unlock = function() {
                if (Cn(!N.global), --this._reculock === 0)
                    for (N.global || (N.lockOwnerFor = null); this._blockedFuncs.length > 0 && !this._locked();) {
                        var t = this._blockedFuncs.shift();
                        try {
                            rn(t[1], t[0])
                        } catch {}
                    }
                return this
            }, e.prototype._locked = function() {
                return this._reculock && N.lockOwnerFor !== this
            }, e.prototype.create = function(t) {
                var n = this;
                if (!this.mode) return this;
                var r = this.db.idbdb,
                    i = this.db._state.dbOpenError;
                if (Cn(!this.idbtrans), !t && !r) switch (i && i.name) {
                    case "DatabaseClosedError":
                        throw new j.DatabaseClosed(i);
                    case "MissingAPIError":
                        throw new j.MissingAPI(i.message, i);
                    default:
                        throw new j.OpenFailed(i)
                }
                if (!this.active) throw new j.TransactionInactive;
                return Cn(this._completion._state === null), t = this.idbtrans = t || (this.db.core ? this.db.core.transaction(this.storeNames, this.mode, {
                    durability: this.chromeTransactionDurability
                }) : r.transaction(this.storeNames, this.mode, {
                    durability: this.chromeTransactionDurability
                })), t.onerror = J(function(o) {
                    Nn(o), n._reject(t.error)
                }), t.onabort = J(function(o) {
                    Nn(o), n.active && n._reject(new j.Abort(t.error)), n.active = !1, n.on("abort").fire(o)
                }), t.oncomplete = J(function() {
                    n.active = !1, n._resolve(), "mutatedParts" in t && mt.storagemutated.fire(t.mutatedParts)
                }), this
            }, e.prototype._promise = function(t, n, r) {
                var i = this;
                if (t === "readwrite" && this.mode !== "readwrite") return oe(new j.ReadOnly("Transaction is readonly"));
                if (!this.active) return oe(new j.TransactionInactive);
                if (this._locked()) return new O(function(a, s) {
                    i._blockedFuncs.push([function() {
                        i._promise(t, n, r).then(a, s)
                    }, N])
                });
                if (r) return ft(function() {
                    var a = new O(function(s, l) {
                        i._lock();
                        var u = n(s, l, i);
                        u && u.then && u.then(s, l)
                    });
                    return a.finally(function() {
                        return i._unlock()
                    }), a._lib = !0, a
                });
                var o = new O(function(a, s) {
                    var l = n(a, s, i);
                    l && l.then && l.then(a, s)
                });
                return o._lib = !0, o
            }, e.prototype._root = function() {
                return this.parent ? this.parent._root() : this
            }, e.prototype.waitFor = function(t) {
                var n = this._root(),
                    r = O.resolve(t);
                if (n._waitingFor) n._waitingFor = n._waitingFor.then(function() {
                    return r
                });
                else {
                    n._waitingFor = r, n._waitingQueue = [];
                    var i = n.idbtrans.objectStore(n.storeNames[0]);
                    (function a() {
                        for (++n._spinCount; n._waitingQueue.length;) n._waitingQueue.shift()();
                        n._waitingFor && (i.get(-1 / 0).onsuccess = a)
                    })()
                }
                var o = n._waitingFor;
                return new O(function(a, s) {
                    r.then(function(l) {
                        return n._waitingQueue.push(J(a.bind(null, l)))
                    }, function(l) {
                        return n._waitingQueue.push(J(s.bind(null, l)))
                    }).finally(function() {
                        n._waitingFor === o && (n._waitingFor = null)
                    })
                })
            }, e.prototype.abort = function() {
                this.active && (this.active = !1, this.idbtrans && this.idbtrans.abort(), this._reject(new j.Abort))
            }, e.prototype.table = function(t) {
                var n = this._memoizedTables || (this._memoizedTables = {});
                if (_e(n, t)) return n[t];
                var r = this.schema[t];
                if (!r) throw new j.NotFound("Table " + t + " not part of transaction");
                var i = new this.db.Table(t, r, this);
                return i.core = this.db.core.table(t), n[t] = i, i
            }, e
        }();

    function xp(e) {
        return Pn(Ep.prototype, function(n, r, i, o, a) {
            var s = this;
            this.db = e, this.mode = n, this.storeNames = r, this.schema = i, this.chromeTransactionDurability = o, this.idbtrans = null, this.on = Un(this, "complete", "error", "abort"), this.parent = a || null, this.active = !0, this._reculock = 0, this._blockedFuncs = [], this._resolve = null, this._reject = null, this._waitingFor = null, this._waitingQueue = null, this._spinCount = 0, this._completion = new O(function(l, u) {
                s._resolve = l, s._reject = u
            }), this._completion.then(function() {
                s.active = !1, s.on.complete.fire()
            }, function(l) {
                var u = s.active;
                return s.active = !1, s.on.error.fire(l), s.parent ? s.parent._reject(l) : u && s.idbtrans && s.idbtrans.abort(), oe(l)
            })
        })
    }

    function ro(e, t, n, r, i, o, a) {
        return {
            name: e,
            keyPath: t,
            unique: n,
            multi: r,
            auto: i,
            compound: o,
            src: (n && !a ? "&" : "") + (r ? "*" : "") + (i ? "++" : "") + Ds(t)
        }
    }

    function Ds(e) {
        return typeof e == "string" ? e : e ? "[" + [].join.call(e, "+") + "]" : ""
    }

    function Us(e, t, n) {
        return {
            name: e,
            primKey: t,
            indexes: n,
            mappedClass: null,
            idxByName: ns(n, function(r) {
                return [r.name, r]
            })
        }
    }

    function Cp(e) {
        return e.length === 1 ? e[0] : e
    }
    var jn = function(e) {
        try {
            return e.only([
                []
            ]), jn = function() {
                return [
                    []
                ]
            }, [
                []
            ]
        } catch {
            return jn = function() {
                return Ut
            }, Ut
        }
    };

    function io(e) {
        return e == null ? function() {} : typeof e == "string" ? Sp(e) : function(t) {
            return Ze(t, e)
        }
    }

    function Sp(e) {
        var t = e.split(".");
        return t.length === 1 ? function(n) {
            return n[e]
        } : function(n) {
            return Ze(n, e)
        }
    }

    function Ps(e) {
        return [].slice.call(e)
    }
    var Ip = 0;

    function Vn(e) {
        return e == null ? ":id" : typeof e == "string" ? e : "[" + e.join("+") + "]"
    }

    function kp(e, t, n) {
        function r(f, d) {
            var p = Ps(f.objectStoreNames);
            return {
                schema: {
                    name: f.name,
                    tables: p.map(function(h) {
                        return d.objectStore(h)
                    }).map(function(h) {
                        var v = h.keyPath,
                            m = h.autoIncrement,
                            y = ce(v),
                            _ = v == null,
                            E = {},
                            b = {
                                name: h.name,
                                primaryKey: {
                                    name: null,
                                    isPrimaryKey: !0,
                                    outbound: _,
                                    compound: y,
                                    keyPath: v,
                                    autoIncrement: m,
                                    unique: !0,
                                    extractKey: io(v)
                                },
                                indexes: Ps(h.indexNames).map(function(w) {
                                    return h.index(w)
                                }).map(function(w) {
                                    var x = w.name,
                                        C = w.unique,
                                        I = w.multiEntry,
                                        k = w.keyPath,
                                        L = ce(k),
                                        T = {
                                            name: x,
                                            compound: L,
                                            keyPath: k,
                                            unique: C,
                                            multiEntry: I,
                                            extractKey: io(k)
                                        };
                                    return E[Vn(k)] = T, T
                                }),
                                getIndexByKeyPath: function(w) {
                                    return E[Vn(w)]
                                }
                            };
                        return E[":id"] = b.primaryKey, v != null && (E[Vn(v)] = b.primaryKey), b
                    })
                },
                hasGetAll: p.length > 0 && "getAll" in d.objectStore(p[0]) && !(typeof navigator < "u" && /Safari/.test(navigator.userAgent) && !/(Chrome\/|Edge\/)/.test(navigator.userAgent) && [].concat(navigator.userAgent.match(/Safari\/(\d*)/))[1] < 604)
            }
        }

        function i(f) {
            if (f.type === 3) return null;
            if (f.type === 4) throw new Error("Cannot convert never type to IDBKeyRange");
            var d = f.lower,
                p = f.upper,
                h = f.lowerOpen,
                v = f.upperOpen,
                m = d === void 0 ? p === void 0 ? null : t.upperBound(p, !!v) : p === void 0 ? t.lowerBound(d, !!h) : t.bound(d, p, !!h, !!v);
            return m
        }

        function o(f) {
            var d = f.name;

            function p(m) {
                var y = m.trans,
                    _ = m.type,
                    E = m.keys,
                    b = m.values,
                    w = m.range;
                return new Promise(function(x, C) {
                    x = J(x);
                    var I = y.objectStore(d),
                        k = I.keyPath == null,
                        L = _ === "put" || _ === "add";
                    if (!L && _ !== "delete" && _ !== "deleteRange") throw new Error("Invalid operation type: " + _);
                    var T = (E || b || {
                        length: 1
                    }).length;
                    if (E && b && E.length !== b.length) throw new Error("Given keys array must have same length as given values array.");
                    if (T === 0) return x({
                        numFailures: 0,
                        failures: {},
                        results: [],
                        lastResult: void 0
                    });
                    var U, S = [],
                        V = [],
                        D = 0,
                        X = function(ze) {
                            ++D, Nn(ze)
                        };
                    if (_ === "deleteRange") {
                        if (w.type === 4) return x({
                            numFailures: D,
                            failures: V,
                            results: [],
                            lastResult: void 0
                        });
                        w.type === 3 ? S.push(U = I.clear()) : S.push(U = I.delete(i(w)))
                    } else {
                        var z = L ? k ? [b, E] : [b, null] : [E, null],
                            ve = z[0],
                            qe = z[1];
                        if (L)
                            for (var ke = 0; ke < T; ++ke) S.push(U = qe && qe[ke] !== void 0 ? I[_](ve[ke], qe[ke]) : I[_](ve[ke])), U.onerror = X;
                        else
                            for (var ke = 0; ke < T; ++ke) S.push(U = I[_](ve[ke])), U.onerror = X
                    }
                    var Ct = function(ze) {
                        var Qn = ze.target.result;
                        S.forEach(function(Ue, ei) {
                            return Ue.error != null && (V[ei] = Ue.error)
                        }), x({
                            numFailures: D,
                            failures: V,
                            results: _ === "delete" ? E : S.map(function(Ue) {
                                return Ue.result
                            }),
                            lastResult: Qn
                        })
                    };
                    U.onerror = function(ze) {
                        X(ze), Ct(ze)
                    }, U.onsuccess = Ct
                })
            }

            function h(m) {
                var y = m.trans,
                    _ = m.values,
                    E = m.query,
                    b = m.reverse,
                    w = m.unique;
                return new Promise(function(x, C) {
                    x = J(x);
                    var I = E.index,
                        k = E.range,
                        L = y.objectStore(d),
                        T = I.isPrimaryKey ? L : L.index(I.name),
                        U = b ? w ? "prevunique" : "prev" : w ? "nextunique" : "next",
                        S = _ || !("openKeyCursor" in T) ? T.openCursor(i(k), U) : T.openKeyCursor(i(k), U);
                    S.onerror = Fe(C), S.onsuccess = J(function(V) {
                        var D = S.result;
                        if (!D) {
                            x(null);
                            return
                        }
                        D.___id = ++Ip, D.done = !1;
                        var X = D.continue.bind(D),
                            z = D.continuePrimaryKey;
                        z && (z = z.bind(D));
                        var ve = D.advance.bind(D),
                            qe = function() {
                                throw new Error("Cursor not started")
                            },
                            ke = function() {
                                throw new Error("Cursor not stopped")
                            };
                        D.trans = y, D.stop = D.continue = D.continuePrimaryKey = D.advance = qe, D.fail = J(C), D.next = function() {
                            var Ct = this,
                                ze = 1;
                            return this.start(function() {
                                return ze-- ? Ct.continue() : Ct.stop()
                            }).then(function() {
                                return Ct
                            })
                        }, D.start = function(Ct) {
                            var ze = new Promise(function(Ue, ei) {
                                    Ue = J(Ue), S.onerror = Fe(ei), D.fail = ei, D.stop = function(fg) {
                                        D.stop = D.continue = D.continuePrimaryKey = D.advance = ke, Ue(fg)
                                    }
                                }),
                                Qn = function() {
                                    if (S.result) try {
                                        Ct()
                                    } catch (Ue) {
                                        D.fail(Ue)
                                    } else D.done = !0, D.start = function() {
                                        throw new Error("Cursor behind last entry")
                                    }, D.stop()
                                };
                            return S.onsuccess = J(function(Ue) {
                                S.onsuccess = Qn, Qn()
                            }), D.continue = X, D.continuePrimaryKey = z, D.advance = ve, Qn(), ze
                        }, x(D)
                    }, C)
                })
            }

            function v(m) {
                return function(y) {
                    return new Promise(function(_, E) {
                        _ = J(_);
                        var b = y.trans,
                            w = y.values,
                            x = y.limit,
                            C = y.query,
                            I = x === 1 / 0 ? void 0 : x,
                            k = C.index,
                            L = C.range,
                            T = b.objectStore(d),
                            U = k.isPrimaryKey ? T : T.index(k.name),
                            S = i(L);
                        if (x === 0) return _({
                            result: []
                        });
                        if (m) {
                            var V = w ? U.getAll(S, I) : U.getAllKeys(S, I);
                            V.onsuccess = function(ve) {
                                return _({
                                    result: ve.target.result
                                })
                            }, V.onerror = Fe(E)
                        } else {
                            var D = 0,
                                X = w || !("openKeyCursor" in U) ? U.openCursor(S) : U.openKeyCursor(S),
                                z = [];
                            X.onsuccess = function(ve) {
                                var qe = X.result;
                                if (!qe) return _({
                                    result: z
                                });
                                if (z.push(w ? qe.value : qe.primaryKey), ++D === x) return _({
                                    result: z
                                });
                                qe.continue()
                            }, X.onerror = Fe(E)
                        }
                    })
                }
            }
            return {
                name: d,
                schema: f,
                mutate: p,
                getMany: function(m) {
                    var y = m.trans,
                        _ = m.keys;
                    return new Promise(function(E, b) {
                        E = J(E);
                        for (var w = y.objectStore(d), x = _.length, C = new Array(x), I = 0, k = 0, L, T = function(D) {
                                var X = D.target;
                                (C[X._pos] = X.result) != null, ++k === I && E(C)
                            }, U = Fe(b), S = 0; S < x; ++S) {
                            var V = _[S];
                            V != null && (L = w.get(_[S]), L._pos = S, L.onsuccess = T, L.onerror = U, ++I)
                        }
                        I === 0 && E(C)
                    })
                },
                get: function(m) {
                    var y = m.trans,
                        _ = m.key;
                    return new Promise(function(E, b) {
                        E = J(E);
                        var w = y.objectStore(d),
                            x = w.get(_);
                        x.onsuccess = function(C) {
                            return E(C.target.result)
                        }, x.onerror = Fe(b)
                    })
                },
                query: v(l),
                openCursor: h,
                count: function(m) {
                    var y = m.query,
                        _ = m.trans,
                        E = y.index,
                        b = y.range;
                    return new Promise(function(w, x) {
                        var C = _.objectStore(d),
                            I = E.isPrimaryKey ? C : C.index(E.name),
                            k = i(b),
                            L = k ? I.count(k) : I.count();
                        L.onsuccess = J(function(T) {
                            return w(T.target.result)
                        }), L.onerror = Fe(x)
                    })
                }
            }
        }
        var a = r(e, n),
            s = a.schema,
            l = a.hasGetAll,
            u = s.tables.map(function(f) {
                return o(f)
            }),
            c = {};
        return u.forEach(function(f) {
            return c[f.name] = f
        }), {
            stack: "dbcore",
            transaction: e.transaction.bind(e),
            table: function(f) {
                var d = c[f];
                if (!d) throw new Error("Table '" + f + "' not found");
                return c[f]
            },
            MIN_KEY: -1 / 0,
            MAX_KEY: jn(t),
            schema: s
        }
    }

    function Tp(e, t) {
        return t.reduce(function(n, r) {
            var i = r.create;
            return $($({}, n), i(n))
        }, e)
    }

    function Lp(e, t, n, r) {
        var i = n.IDBKeyRange;
        n.indexedDB;
        var o = Tp(kp(t, i, r), e.dbcore);
        return {
            dbcore: o
        }
    }

    function oo(e, t) {
        var n = e._novip,
            r = t.db,
            i = Lp(n._middlewares, r, n._deps, t);
        n.core = i.dbcore, n.tables.forEach(function(o) {
            var a = o.name;
            n.core.schema.tables.some(function(s) {
                return s.name === a
            }) && (o.core = n.core.table(a), n[a] instanceof n.Table && (n[a].core = o.core))
        })
    }

    function Or(e, t, n, r) {
        var i = e._novip;
        n.forEach(function(o) {
            var a = r[o];
            t.forEach(function(s) {
                var l = Ti(s, o);
                (!l || "value" in l && l.value === void 0) && (s === i.Transaction.prototype || s instanceof i.Transaction ? Qe(s, o, {
                    get: function() {
                        return this.table(o)
                    },
                    set: function(u) {
                        Ja(this, o, {
                            value: u,
                            writable: !0,
                            configurable: !0,
                            enumerable: !0
                        })
                    }
                }) : s[o] = new i.Table(o, a))
            })
        })
    }

    function ao(e, t) {
        var n = e._novip;
        t.forEach(function(r) {
            for (var i in r) r[i] instanceof n.Table && delete r[i]
        })
    }

    function Rp(e, t) {
        return e._cfg.version - t._cfg.version
    }

    function Ap(e, t, n, r) {
        var i = e._dbSchema,
            o = e._createTransaction("readwrite", e._storeNames, i);
        o.create(n), o._completion.catch(r);
        var a = o._reject.bind(o),
            s = N.transless || N;
        ft(function() {
            N.trans = o, N.transless = s, t === 0 ? (re(i).forEach(function(l) {
                so(n, l, i[l].primKey, i[l].indexes)
            }), oo(e, n), O.follow(function() {
                return e.on.populate.fire(o)
            }).catch(a)) : Op(e, t, o, n).catch(a)
        })
    }

    function Op(e, t, n, r) {
        var i = e._novip,
            o = [],
            a = i._versions,
            s = i._dbSchema = uo(i, i.idbdb, r),
            l = !1,
            u = a.filter(function(f) {
                return f._cfg.version >= t
            });
        u.forEach(function(f) {
            o.push(function() {
                var d = s,
                    p = f._cfg.dbschema;
                co(i, d, r), co(i, p, r), s = i._dbSchema = p;
                var h = Ns(d, p);
                h.add.forEach(function(b) {
                    so(r, b[0], b[1].primKey, b[1].indexes)
                }), h.change.forEach(function(b) {
                    if (b.recreate) throw new j.Upgrade("Not yet support for changing primary key");
                    var w = r.objectStore(b.name);
                    b.add.forEach(function(x) {
                        return lo(w, x)
                    }), b.change.forEach(function(x) {
                        w.deleteIndex(x.name), lo(w, x)
                    }), b.del.forEach(function(x) {
                        return w.deleteIndex(x)
                    })
                });
                var v = f._cfg.contentUpgrade;
                if (v && f._cfg.version > t) {
                    oo(i, r), n._memoizedTables = {}, l = !0;
                    var m = rs(p);
                    h.del.forEach(function(b) {
                        m[b] = d[b]
                    }), ao(i, [i.Transaction.prototype]), Or(i, [i.Transaction.prototype], re(m), m), n.schema = m;
                    var y = Oi(v);
                    y && nn();
                    var _, E = O.follow(function() {
                        if (_ = v(n), _ && y) {
                            var b = Je.bind(null, null);
                            _.then(b, b)
                        }
                    });
                    return _ && typeof _.then == "function" ? O.resolve(_) : E.then(function() {
                        return _
                    })
                }
            }), o.push(function(d) {
                if (!l || !sp) {
                    var p = f._cfg.dbschema;
                    Up(p, d)
                }
                ao(i, [i.Transaction.prototype]), Or(i, [i.Transaction.prototype], i._storeNames, i._dbSchema), n.schema = i._dbSchema
            })
        });

        function c() {
            return o.length ? O.resolve(o.shift()(n.idbtrans)).then(c) : O.resolve()
        }
        return c().then(function() {
            Dp(s, r)
        })
    }

    function Ns(e, t) {
        var n = {
                del: [],
                add: [],
                change: []
            },
            r;
        for (r in e) t[r] || n.del.push(r);
        for (r in t) {
            var i = e[r],
                o = t[r];
            if (!i) n.add.push([r, o]);
            else {
                var a = {
                    name: r,
                    def: o,
                    recreate: !1,
                    del: [],
                    add: [],
                    change: []
                };
                if ("" + (i.primKey.keyPath || "") != "" + (o.primKey.keyPath || "") || i.primKey.auto !== o.primKey.auto && !Ir) a.recreate = !0, n.change.push(a);
                else {
                    var s = i.idxByName,
                        l = o.idxByName,
                        u = void 0;
                    for (u in s) l[u] || a.del.push(u);
                    for (u in l) {
                        var c = s[u],
                            f = l[u];
                        c ? c.src !== f.src && a.change.push(f) : a.add.push(f)
                    }(a.del.length > 0 || a.add.length > 0 || a.change.length > 0) && n.change.push(a)
                }
            }
        }
        return n
    }

    function so(e, t, n, r) {
        var i = e.db.createObjectStore(t, n.keyPath ? {
            keyPath: n.keyPath,
            autoIncrement: n.auto
        } : {
            autoIncrement: n.auto
        });
        return r.forEach(function(o) {
            return lo(i, o)
        }), i
    }

    function Dp(e, t) {
        re(e).forEach(function(n) {
            t.db.objectStoreNames.contains(n) || so(t, n, e[n].primKey, e[n].indexes)
        })
    }

    function Up(e, t) {
        [].slice.call(t.db.objectStoreNames).forEach(function(n) {
            return e[n] == null && t.db.deleteObjectStore(n)
        })
    }

    function lo(e, t) {
        e.createIndex(t.name, t.keyPath, {
            unique: t.unique,
            multiEntry: t.multi
        })
    }

    function uo(e, t, n) {
        var r = {},
            i = fr(t.objectStoreNames, 0);
        return i.forEach(function(o) {
            for (var a = n.objectStore(o), s = a.keyPath, l = ro(Ds(s), s || "", !1, !1, !!a.autoIncrement, s && typeof s != "string", !0), u = [], c = 0; c < a.indexNames.length; ++c) {
                var f = a.index(a.indexNames[c]);
                s = f.keyPath;
                var d = ro(f.name, s, !!f.unique, !!f.multiEntry, !1, s && typeof s != "string", !1);
                u.push(d)
            }
            r[o] = Us(o, l, u)
        }), r
    }

    function Pp(e, t, n) {
        var r = e._novip;
        r.verno = t.version / 10;
        var i = r._dbSchema = uo(r, t, n);
        r._storeNames = fr(t.objectStoreNames, 0), Or(r, [r._allTables], re(i), i)
    }

    function Np(e, t) {
        var n = uo(e, e.idbdb, t),
            r = Ns(n, e._dbSchema);
        return !(r.add.length || r.change.some(function(i) {
            return i.add.length || i.change.length
        }))
    }

    function co(e, t, n) {
        for (var r = e._novip, i = n.db.objectStoreNames, o = 0; o < i.length; ++o) {
            var a = i[o],
                s = n.objectStore(a);
            r._hasGetAll = "getAll" in s;
            for (var l = 0; l < s.indexNames.length; ++l) {
                var u = s.indexNames[l],
                    c = s.index(u).keyPath,
                    f = typeof c == "string" ? c : "[" + fr(c).join("+") + "]";
                if (t[a]) {
                    var d = t[a].idxByName[f];
                    d && (d.name = u, delete t[a].idxByName[f], t[a].idxByName[u] = d)
                }
            }
        }
        typeof navigator < "u" && /Safari/.test(navigator.userAgent) && !/(Chrome\/|Edge\/)/.test(navigator.userAgent) && Q.WorkerGlobalScope && Q instanceof Q.WorkerGlobalScope && [].concat(navigator.userAgent.match(/Safari\/(\d*)/))[1] < 604 && (r._hasGetAll = !1)
    }

    function Mp(e) {
        return e.split(",").map(function(t, n) {
            t = t.trim();
            var r = t.replace(/([&*]|\+\+)/g, ""),
                i = /^\[/.test(r) ? r.match(/^\[(.*)\]$/)[1].split("+") : r;
            return ro(r, i || null, /\&/.test(t), /\*/.test(t), /\+\+/.test(t), ce(i), n === 0)
        })
    }
    var jp = function() {
        function e() {}
        return e.prototype._parseStoresSpec = function(t, n) {
            re(t).forEach(function(r) {
                if (t[r] !== null) {
                    var i = Mp(t[r]),
                        o = i.shift();
                    if (o.multi) throw new j.Schema("Primary key cannot be multi-valued");
                    i.forEach(function(a) {
                        if (a.auto) throw new j.Schema("Only primary key can be marked as autoIncrement (++)");
                        if (!a.keyPath) throw new j.Schema("Index must have a name and cannot be an empty string")
                    }), n[r] = Us(r, o, i)
                }
            })
        }, e.prototype.stores = function(t) {
            var n = this.db;
            this._cfg.storesSource = this._cfg.storesSource ? pe(this._cfg.storesSource, t) : t;
            var r = n._versions,
                i = {},
                o = {};
            return r.forEach(function(a) {
                pe(i, a._cfg.storesSource), o = a._cfg.dbschema = {}, a._parseStoresSpec(i, o)
            }), n._dbSchema = o, ao(n, [n._allTables, n, n.Transaction.prototype]), Or(n, [n._allTables, n, n.Transaction.prototype, this._cfg.tables], re(o), o), n._storeNames = re(o), this
        }, e.prototype.upgrade = function(t) {
            return this._cfg.contentUpgrade = Ni(this._cfg.contentUpgrade || W, t), this
        }, e
    }();

    function Vp(e) {
        return Pn(jp.prototype, function(n) {
            this.db = e, this._cfg = {
                version: n,
                storesSource: null,
                dbschema: {},
                tables: {},
                contentUpgrade: null
            }
        })
    }

    function fo(e, t) {
        var n = e._dbNamesDB;
        return n || (n = e._dbNamesDB = new wo(kr, {
            addons: [],
            indexedDB: e,
            IDBKeyRange: t
        }), n.version(1).stores({
            dbnames: "name"
        })), n.table("dbnames")
    }

    function po(e) {
        return e && typeof e.databases == "function"
    }

    function Fp(e) {
        var t = e.indexedDB,
            n = e.IDBKeyRange;
        return po(t) ? Promise.resolve(t.databases()).then(function(r) {
            return r.map(function(i) {
                return i.name
            }).filter(function(i) {
                return i !== kr
            })
        }) : fo(t, n).toCollection().primaryKeys()
    }

    function Bp(e, t) {
        var n = e.indexedDB,
            r = e.IDBKeyRange;
        !po(n) && t !== kr && fo(n, r).put({
            name: t
        }).catch(W)
    }

    function Hp(e, t) {
        var n = e.indexedDB,
            r = e.IDBKeyRange;
        !po(n) && t !== kr && fo(n, r).delete(t).catch(W)
    }

    function ho(e) {
        return ft(function() {
            return N.letThrough = !0, e()
        })
    }

    function Kp() {
        var e = !navigator.userAgentData && /Safari\//.test(navigator.userAgent) && !/Chrom(e|ium)\//.test(navigator.userAgent);
        if (!e || !indexedDB.databases) return Promise.resolve();
        var t;
        return new Promise(function(n) {
            var r = function() {
                return indexedDB.databases().finally(n)
            };
            t = setInterval(r, 100), r()
        }).finally(function() {
            return clearInterval(t)
        })
    }

    function $p(e) {
        var t = e._state,
            n = e._deps.indexedDB;
        if (t.isBeingOpened || e.idbdb) return t.dbReadyPromise.then(function() {
            return t.dbOpenError ? oe(t.dbOpenError) : e
        });
        Ve && (t.openCanceller._stackHolder = Rt()), t.isBeingOpened = !0, t.dbOpenError = null, t.openComplete = !1;
        var r = t.openCanceller;

        function i() {
            if (t.openCanceller !== r) throw new j.DatabaseClosed("db.open() was cancelled")
        }
        var o = t.dbReadyResolve,
            a = null,
            s = !1;
        return O.race([r, (typeof navigator > "u" ? O.resolve() : Kp()).then(function() {
            return new O(function(l, u) {
                if (i(), !n) throw new j.MissingAPI;
                var c = e.name,
                    f = t.autoSchema ? n.open(c) : n.open(c, Math.round(e.verno * 10));
                if (!f) throw new j.MissingAPI;
                f.onerror = Fe(u), f.onblocked = J(e._fireOnBlocked), f.onupgradeneeded = J(function(d) {
                    if (a = f.transaction, t.autoSchema && !e._options.allowEmptyDB) {
                        f.onerror = Nn, a.abort(), f.result.close();
                        var p = n.deleteDatabase(c);
                        p.onsuccess = p.onerror = J(function() {
                            u(new j.NoSuchDatabase("Database " + c + " doesnt exist"))
                        })
                    } else {
                        a.onerror = Fe(u);
                        var h = d.oldVersion > Math.pow(2, 62) ? 0 : d.oldVersion;
                        s = h < 1, e._novip.idbdb = f.result, Ap(e, h / 10, a, u)
                    }
                }, u), f.onsuccess = J(function() {
                    a = null;
                    var d = e._novip.idbdb = f.result,
                        p = fr(d.objectStoreNames);
                    if (p.length > 0) try {
                        var h = d.transaction(Cp(p), "readonly");
                        t.autoSchema ? Pp(e, d, h) : (co(e, e._dbSchema, h), Np(e, h) || console.warn("Dexie SchemaDiff: Schema was extended without increasing the number passed to db.version(). Some queries may fail.")), oo(e, h)
                    } catch {}
                    Dn.push(e), d.onversionchange = J(function(v) {
                        t.vcFired = !0, e.on("versionchange").fire(v)
                    }), d.onclose = J(function(v) {
                        e.on("close").fire(v)
                    }), s && Bp(e._deps, c), l()
                }, u)
            })
        })]).then(function() {
            return i(), t.onReadyBeingFired = [], O.resolve(ho(function() {
                return e.on.ready.fire(e.vip)
            })).then(function l() {
                if (t.onReadyBeingFired.length > 0) {
                    var u = t.onReadyBeingFired.reduce(Ni, W);
                    return t.onReadyBeingFired = [], O.resolve(ho(function() {
                        return u(e.vip)
                    })).then(l)
                }
            })
        }).finally(function() {
            t.onReadyBeingFired = null, t.isBeingOpened = !1
        }).then(function() {
            return e
        }).catch(function(l) {
            t.dbOpenError = l;
            try {
                a && a.abort()
            } catch {}
            return r === t.openCanceller && e._close(), oe(l)
        }).finally(function() {
            t.openComplete = !0, o()
        })
    }

    function vo(e) {
        var t = function(a) {
                return e.next(a)
            },
            n = function(a) {
                return e.throw(a)
            },
            r = o(t),
            i = o(n);

        function o(a) {
            return function(s) {
                var l = a(s),
                    u = l.value;
                return l.done ? u : !u || typeof u.then != "function" ? ce(u) ? Promise.all(u).then(r, i) : r(u) : u.then(r, i)
            }
        }
        return o(t)()
    }

    function Gp(e, t, n) {
        var r = arguments.length;
        if (r < 2) throw new j.InvalidArgument("Too few arguments");
        for (var i = new Array(r - 1); --r;) i[r - 1] = arguments[r];
        n = i.pop();
        var o = is(i);
        return [e, o, n]
    }

    function Ms(e, t, n, r, i) {
        return O.resolve().then(function() {
            var o = N.transless || N,
                a = e._createTransaction(t, n, e._dbSchema, r),
                s = {
                    trans: a,
                    transless: o
                };
            if (r) a.idbtrans = r.idbtrans;
            else try {
                a.create(), e._state.PR1398_maxLoop = 3
            } catch (f) {
                return f.name === Pi.InvalidState && e.isOpen() && --e._state.PR1398_maxLoop > 0 ? (console.warn("Dexie: Need to reopen db"), e._close(), e.open().then(function() {
                    return Ms(e, t, n, null, i)
                })) : oe(f)
            }
            var l = Oi(i);
            l && nn();
            var u, c = O.follow(function() {
                if (u = i.call(a, a), u)
                    if (l) {
                        var f = Je.bind(null, null);
                        u.then(f, f)
                    } else typeof u.next == "function" && typeof u.throw == "function" && (u = vo(u))
            }, s);
            return (u && typeof u.then == "function" ? O.resolve(u).then(function(f) {
                return a.active ? f : oe(new j.PrematureCommit("Transaction committed too early. See http://bit.ly/2kdckMn"))
            }) : c.then(function() {
                return u
            })).then(function(f) {
                return r && a._resolve(), a._completion.then(function() {
                    return f
                })
            }).catch(function(f) {
                return a._reject(f), oe(f)
            })
        })
    }

    function Dr(e, t, n) {
        for (var r = ce(e) ? e.slice() : [e], i = 0; i < n; ++i) r.push(t);
        return r
    }

    function qp(e) {
        return $($({}, e), {
            table: function(t) {
                var n = e.table(t),
                    r = n.schema,
                    i = {},
                    o = [];

                function a(v, m, y) {
                    var _ = Vn(v),
                        E = i[_] = i[_] || [],
                        b = v == null ? 0 : typeof v == "string" ? 1 : v.length,
                        w = m > 0,
                        x = $($({}, y), {
                            isVirtual: w,
                            keyTail: m,
                            keyLength: b,
                            extractKey: io(v),
                            unique: !w && y.unique
                        });
                    if (E.push(x), x.isPrimaryKey || o.push(x), b > 1) {
                        var C = b === 2 ? v[0] : v.slice(0, b - 1);
                        a(C, m + 1, y)
                    }
                    return E.sort(function(I, k) {
                        return I.keyTail - k.keyTail
                    }), x
                }
                var s = a(r.primaryKey.keyPath, 0, r.primaryKey);
                i[":id"] = [s];
                for (var l = 0, u = r.indexes; l < u.length; l++) {
                    var c = u[l];
                    a(c.keyPath, 0, c)
                }

                function f(v) {
                    var m = i[Vn(v)];
                    return m && m[0]
                }

                function d(v, m) {
                    return {
                        type: v.type === 1 ? 2 : v.type,
                        lower: Dr(v.lower, v.lowerOpen ? e.MAX_KEY : e.MIN_KEY, m),
                        lowerOpen: !0,
                        upper: Dr(v.upper, v.upperOpen ? e.MIN_KEY : e.MAX_KEY, m),
                        upperOpen: !0
                    }
                }

                function p(v) {
                    var m = v.query.index;
                    return m.isVirtual ? $($({}, v), {
                        query: {
                            index: m,
                            range: d(v.query.range, m.keyTail)
                        }
                    }) : v
                }
                var h = $($({}, n), {
                    schema: $($({}, r), {
                        primaryKey: s,
                        indexes: o,
                        getIndexByKeyPath: f
                    }),
                    count: function(v) {
                        return n.count(p(v))
                    },
                    query: function(v) {
                        return n.query(p(v))
                    },
                    openCursor: function(v) {
                        var m = v.query.index,
                            y = m.keyTail,
                            _ = m.isVirtual,
                            E = m.keyLength;
                        if (!_) return n.openCursor(v);

                        function b(w) {
                            function x(I) {
                                I != null ? w.continue(Dr(I, v.reverse ? e.MAX_KEY : e.MIN_KEY, y)) : v.unique ? w.continue(w.key.slice(0, E).concat(v.reverse ? e.MIN_KEY : e.MAX_KEY, y)) : w.continue()
                            }
                            var C = Object.create(w, {
                                continue: {
                                    value: x
                                },
                                continuePrimaryKey: {
                                    value: function(I, k) {
                                        w.continuePrimaryKey(Dr(I, e.MAX_KEY, y), k)
                                    }
                                },
                                primaryKey: {
                                    get: function() {
                                        return w.primaryKey
                                    }
                                },
                                key: {
                                    get: function() {
                                        var I = w.key;
                                        return E === 1 ? I[0] : I.slice(0, E)
                                    }
                                },
                                value: {
                                    get: function() {
                                        return w.value
                                    }
                                }
                            });
                            return C
                        }
                        return n.openCursor(p(v)).then(function(w) {
                            return w && b(w)
                        })
                    }
                });
                return h
            }
        })
    }
    var zp = {
        stack: "dbcore",
        name: "VirtualIndexMiddleware",
        level: 1,
        create: qp
    };

    function mo(e, t, n, r) {
        return n = n || {}, r = r || "", re(e).forEach(function(i) {
            if (!_e(t, i)) n[r + i] = void 0;
            else {
                var o = e[i],
                    a = t[i];
                if (typeof o == "object" && typeof a == "object" && o && a) {
                    var s = Ri(o),
                        l = Ri(a);
                    s !== l ? n[r + i] = t[i] : s === "Object" ? mo(o, a, n, r + i + ".") : o !== a && (n[r + i] = t[i])
                } else o !== a && (n[r + i] = t[i])
            }
        }), re(t).forEach(function(i) {
            _e(e, i) || (n[r + i] = t[i])
        }), n
    }

    function Wp(e, t) {
        return t.type === "delete" ? t.keys : t.keys || t.values.map(e.extractKey)
    }
    var Yp = {
        stack: "dbcore",
        name: "HooksMiddleware",
        level: 2,
        create: function(e) {
            return $($({}, e), {
                table: function(t) {
                    var n = e.table(t),
                        r = n.schema.primaryKey,
                        i = $($({}, n), {
                            mutate: function(o) {
                                var a = N.trans,
                                    s = a.table(t).hook,
                                    l = s.deleting,
                                    u = s.creating,
                                    c = s.updating;
                                switch (o.type) {
                                    case "add":
                                        if (u.fire === W) break;
                                        return a._promise("readwrite", function() {
                                            return f(o)
                                        }, !0);
                                    case "put":
                                        if (u.fire === W && c.fire === W) break;
                                        return a._promise("readwrite", function() {
                                            return f(o)
                                        }, !0);
                                    case "delete":
                                        if (l.fire === W) break;
                                        return a._promise("readwrite", function() {
                                            return f(o)
                                        }, !0);
                                    case "deleteRange":
                                        if (l.fire === W) break;
                                        return a._promise("readwrite", function() {
                                            return d(o)
                                        }, !0)
                                }
                                return n.mutate(o);

                                function f(h) {
                                    var v = N.trans,
                                        m = h.keys || Wp(r, h);
                                    if (!m) throw new Error("Keys missing");
                                    return h = h.type === "add" || h.type === "put" ? $($({}, h), {
                                        keys: m
                                    }) : $({}, h), h.type !== "delete" && (h.values = ki([], h.values, !0)), h.keys && (h.keys = ki([], h.keys, !0)), Qp(n, h, m).then(function(y) {
                                        var _ = m.map(function(E, b) {
                                            var w = y[b],
                                                x = {
                                                    onerror: null,
                                                    onsuccess: null
                                                };
                                            if (h.type === "delete") l.fire.call(x, E, w, v);
                                            else if (h.type === "add" || w === void 0) {
                                                var C = u.fire.call(x, E, h.values[b], v);
                                                E == null && C != null && (E = C, h.keys[b] = E, r.outbound || Le(h.values[b], r.keyPath, E))
                                            } else {
                                                var I = mo(w, h.values[b]),
                                                    k = c.fire.call(x, I, E, w, v);
                                                if (k) {
                                                    var L = h.values[b];
                                                    Object.keys(k).forEach(function(T) {
                                                        _e(L, T) ? L[T] = k[T] : Le(L, T, k[T])
                                                    })
                                                }
                                            }
                                            return x
                                        });
                                        return n.mutate(h).then(function(E) {
                                            for (var b = E.failures, w = E.results, x = E.numFailures, C = E.lastResult, I = 0; I < m.length; ++I) {
                                                var k = w ? w[I] : m[I],
                                                    L = _[I];
                                                k == null ? L.onerror && L.onerror(b[I]) : L.onsuccess && L.onsuccess(h.type === "put" && y[I] ? h.values[I] : k)
                                            }
                                            return {
                                                failures: b,
                                                results: w,
                                                numFailures: x,
                                                lastResult: C
                                            }
                                        }).catch(function(E) {
                                            return _.forEach(function(b) {
                                                return b.onerror && b.onerror(E)
                                            }), Promise.reject(E)
                                        })
                                    })
                                }

                                function d(h) {
                                    return p(h.trans, h.range, 1e4)
                                }

                                function p(h, v, m) {
                                    return n.query({
                                        trans: h,
                                        values: !1,
                                        query: {
                                            index: r,
                                            range: v
                                        },
                                        limit: m
                                    }).then(function(y) {
                                        var _ = y.result;
                                        return f({
                                            type: "delete",
                                            keys: _,
                                            trans: h
                                        }).then(function(E) {
                                            return E.numFailures > 0 ? Promise.reject(E.failures[0]) : _.length < m ? {
                                                failures: [],
                                                numFailures: 0,
                                                lastResult: void 0
                                            } : p(h, $($({}, v), {
                                                lower: _[_.length - 1],
                                                lowerOpen: !0
                                            }), m)
                                        })
                                    })
                                }
                            }
                        });
                    return i
                }
            })
        }
    };

    function Qp(e, t, n) {
        return t.type === "add" ? Promise.resolve([]) : e.getMany({
            trans: t.trans,
            keys: n,
            cache: "immutable"
        })
    }

    function js(e, t, n) {
        try {
            if (!t || t.keys.length < e.length) return null;
            for (var r = [], i = 0, o = 0; i < t.keys.length && o < e.length; ++i) he(t.keys[i], e[o]) === 0 && (r.push(n ? Sn(t.values[i]) : t.values[i]), ++o);
            return r.length === e.length ? r : null
        } catch {
            return null
        }
    }
    var Zp = {
            stack: "dbcore",
            level: -1,
            create: function(e) {
                return {
                    table: function(t) {
                        var n = e.table(t);
                        return $($({}, n), {
                            getMany: function(r) {
                                if (!r.cache) return n.getMany(r);
                                var i = js(r.keys, r.trans._cache, r.cache === "clone");
                                return i ? O.resolve(i) : n.getMany(r).then(function(o) {
                                    return r.trans._cache = {
                                        keys: r.keys,
                                        values: r.cache === "clone" ? Sn(o) : o
                                    }, o
                                })
                            },
                            mutate: function(r) {
                                return r.type !== "add" && (r.trans._cache = null), n.mutate(r)
                            }
                        })
                    }
                }
            }
        },
        go;

    function _o(e) {
        return !("from" in e)
    }
    var tt = function(e, t) {
        if (this) pe(this, arguments.length ? {
            d: 1,
            from: e,
            to: arguments.length > 1 ? t : e
        } : {
            d: 0
        });
        else {
            var n = new tt;
            return e && "d" in e && pe(n, e), n
        }
    };
    Zt(tt.prototype, (go = {
        add: function(e) {
            return Ur(this, e), this
        },
        addKey: function(e) {
            return Fn(this, e, e), this
        },
        addKeys: function(e) {
            var t = this;
            return e.forEach(function(n) {
                return Fn(t, n, n)
            }), this
        }
    }, go[Ai] = function() {
        return yo(this)
    }, go));

    function Fn(e, t, n) {
        var r = he(t, n);
        if (!isNaN(r)) {
            if (r > 0) throw RangeError();
            if (_o(e)) return pe(e, {
                from: t,
                to: n,
                d: 1
            });
            var i = e.l,
                o = e.r;
            if (he(n, e.from) < 0) return i ? Fn(i, t, n) : e.l = {
                from: t,
                to: n,
                d: 1,
                l: null,
                r: null
            }, Vs(e);
            if (he(t, e.to) > 0) return o ? Fn(o, t, n) : e.r = {
                from: t,
                to: n,
                d: 1,
                l: null,
                r: null
            }, Vs(e);
            he(t, e.from) < 0 && (e.from = t, e.l = null, e.d = o ? o.d + 1 : 1), he(n, e.to) > 0 && (e.to = n, e.r = null, e.d = e.l ? e.l.d + 1 : 1);
            var a = !e.r;
            i && !e.l && Ur(e, i), o && a && Ur(e, o)
        }
    }

    function Ur(e, t) {
        function n(r, i) {
            var o = i.from,
                a = i.to,
                s = i.l,
                l = i.r;
            Fn(r, o, a), s && n(r, s), l && n(r, l)
        }
        _o(t) || n(e, t)
    }

    function Xp(e, t) {
        var n = yo(t),
            r = n.next();
        if (r.done) return !1;
        for (var i = r.value, o = yo(e), a = o.next(i.from), s = a.value; !r.done && !a.done;) {
            if (he(s.from, i.to) <= 0 && he(s.to, i.from) >= 0) return !0;
            he(i.from, s.from) < 0 ? i = (r = n.next(s.from)).value : s = (a = o.next(i.from)).value
        }
        return !1
    }

    function yo(e) {
        var t = _o(e) ? null : {
            s: 0,
            n: e
        };
        return {
            next: function(n) {
                for (var r = arguments.length > 0; t;) switch (t.s) {
                    case 0:
                        if (t.s = 1, r)
                            for (; t.n.l && he(n, t.n.from) < 0;) t = {
                                up: t,
                                n: t.n.l,
                                s: 1
                            };
                        else
                            for (; t.n.l;) t = {
                                up: t,
                                n: t.n.l,
                                s: 1
                            };
                    case 1:
                        if (t.s = 2, !r || he(n, t.n.to) <= 0) return {
                            value: t.n,
                            done: !1
                        };
                    case 2:
                        if (t.n.r) {
                            t.s = 3, t = {
                                up: t,
                                n: t.n.r,
                                s: 0
                            };
                            continue
                        }
                    case 3:
                        t = t.up
                }
                return {
                    done: !0
                }
            }
        }
    }

    function Vs(e) {
        var t, n, r = (((t = e.r) === null || t === void 0 ? void 0 : t.d) || 0) - (((n = e.l) === null || n === void 0 ? void 0 : n.d) || 0),
            i = r > 1 ? "r" : r < -1 ? "l" : "";
        if (i) {
            var o = i === "r" ? "l" : "r",
                a = $({}, e),
                s = e[i];
            e.from = s.from, e.to = s.to, e[i] = s[i], a[i] = s[o], e[o] = a, a.d = Fs(a)
        }
        e.d = Fs(e)
    }

    function Fs(e) {
        var t = e.r,
            n = e.l;
        return (t ? n ? Math.max(t.d, n.d) : t.d : n ? n.d : 0) + 1
    }
    var Jp = {
        stack: "dbcore",
        level: 0,
        create: function(e) {
            var t = e.schema.name,
                n = new tt(e.MIN_KEY, e.MAX_KEY);
            return $($({}, e), {
                table: function(r) {
                    var i = e.table(r),
                        o = i.schema,
                        a = o.primaryKey,
                        s = a.extractKey,
                        l = a.outbound,
                        u = $($({}, i), {
                            mutate: function(d) {
                                var p = d.trans,
                                    h = p.mutatedParts || (p.mutatedParts = {}),
                                    v = function(C) {
                                        var I = "idb://" + t + "/" + r + "/" + C;
                                        return h[I] || (h[I] = new tt)
                                    },
                                    m = v(""),
                                    y = v(":dels"),
                                    _ = d.type,
                                    E = d.type === "deleteRange" ? [d.range] : d.type === "delete" ? [d.keys] : d.values.length < 50 ? [
                                        [], d.values
                                    ] : [],
                                    b = E[0],
                                    w = E[1],
                                    x = d.trans._cache;
                                return i.mutate(d).then(function(C) {
                                    if (ce(b)) {
                                        _ !== "delete" && (b = C.results), m.addKeys(b);
                                        var I = js(b, x);
                                        !I && _ !== "add" && y.addKeys(b), (I || w) && eh(v, o, I, w)
                                    } else if (b) {
                                        var k = {
                                            from: b.lower,
                                            to: b.upper
                                        };
                                        y.add(k), m.add(k)
                                    } else m.add(n), y.add(n), o.indexes.forEach(function(L) {
                                        return v(L.name).add(n)
                                    });
                                    return C
                                })
                            }
                        }),
                        c = function(d) {
                            var p, h, v = d.query,
                                m = v.index,
                                y = v.range;
                            return [m, new tt((p = y.lower) !== null && p !== void 0 ? p : e.MIN_KEY, (h = y.upper) !== null && h !== void 0 ? h : e.MAX_KEY)]
                        },
                        f = {
                            get: function(d) {
                                return [a, new tt(d.key)]
                            },
                            getMany: function(d) {
                                return [a, new tt().addKeys(d.keys)]
                            },
                            count: c,
                            query: c,
                            openCursor: c
                        };
                    return re(f).forEach(function(d) {
                        u[d] = function(p) {
                            var h = N.subscr;
                            if (h) {
                                var v = function(x) {
                                        var C = "idb://" + t + "/" + r + "/" + x;
                                        return h[C] || (h[C] = new tt)
                                    },
                                    m = v(""),
                                    y = v(":dels"),
                                    _ = f[d](p),
                                    E = _[0],
                                    b = _[1];
                                if (v(E.name || "").add(b), !E.isPrimaryKey)
                                    if (d === "count") y.add(n);
                                    else {
                                        var w = d === "query" && l && p.values && i.query($($({}, p), {
                                            values: !1
                                        }));
                                        return i[d].apply(this, arguments).then(function(x) {
                                            if (d === "query") {
                                                if (l && p.values) return w.then(function(L) {
                                                    var T = L.result;
                                                    return m.addKeys(T), x
                                                });
                                                var C = p.values ? x.result.map(s) : x.result;
                                                p.values ? m.addKeys(C) : y.addKeys(C)
                                            } else if (d === "openCursor") {
                                                var I = x,
                                                    k = p.values;
                                                return I && Object.create(I, {
                                                    key: {
                                                        get: function() {
                                                            return y.addKey(I.primaryKey), I.key
                                                        }
                                                    },
                                                    primaryKey: {
                                                        get: function() {
                                                            var L = I.primaryKey;
                                                            return y.addKey(L), L
                                                        }
                                                    },
                                                    value: {
                                                        get: function() {
                                                            return k && m.addKey(I.primaryKey), I.value
                                                        }
                                                    }
                                                })
                                            }
                                            return x
                                        })
                                    }
                            }
                            return i[d].apply(this, arguments)
                        }
                    }), u
                }
            })
        }
    };

    function eh(e, t, n, r) {
        function i(o) {
            var a = e(o.name || "");

            function s(u) {
                return u != null ? o.extractKey(u) : null
            }
            var l = function(u) {
                return o.multiEntry && ce(u) ? u.forEach(function(c) {
                    return a.addKey(c)
                }) : a.addKey(u)
            };
            (n || r).forEach(function(u, c) {
                var f = n && s(n[c]),
                    d = r && s(r[c]);
                he(f, d) !== 0 && (f != null && l(f), d != null && l(d))
            })
        }
        t.indexes.forEach(i)
    }
    var wo = function() {
            function e(t, n) {
                var r = this;
                this._middlewares = {}, this.verno = 0;
                var i = e.dependencies;
                this._options = n = $({
                    addons: e.addons,
                    autoOpen: !0,
                    indexedDB: i.indexedDB,
                    IDBKeyRange: i.IDBKeyRange
                }, n), this._deps = {
                    indexedDB: n.indexedDB,
                    IDBKeyRange: n.IDBKeyRange
                };
                var o = n.addons;
                this._dbSchema = {}, this._versions = [], this._storeNames = [], this._allTables = {}, this.idbdb = null, this._novip = this;
                var a = {
                    dbOpenError: null,
                    isBeingOpened: !1,
                    onReadyBeingFired: null,
                    openComplete: !1,
                    dbReadyResolve: W,
                    dbReadyPromise: null,
                    cancelOpen: W,
                    openCanceller: null,
                    autoSchema: !0,
                    PR1398_maxLoop: 3
                };
                a.dbReadyPromise = new O(function(s) {
                    a.dbReadyResolve = s
                }), a.openCanceller = new O(function(s, l) {
                    a.cancelOpen = l
                }), this._state = a, this.name = t, this.on = Un(this, "populate", "blocked", "versionchange", "close", {
                    ready: [Ni, W]
                }), this.on.ready.subscribe = es(this.on.ready.subscribe, function(s) {
                    return function(l, u) {
                        e.vip(function() {
                            var c = r._state;
                            if (c.openComplete) c.dbOpenError || O.resolve().then(l), u && s(l);
                            else if (c.onReadyBeingFired) c.onReadyBeingFired.push(l), u && s(l);
                            else {
                                s(l);
                                var f = r;
                                u || s(function d() {
                                    f.on.ready.unsubscribe(l), f.on.ready.unsubscribe(d)
                                })
                            }
                        })
                    }
                }), this.Collection = vp(this), this.Table = cp(this), this.Transaction = xp(this), this.Version = Vp(this), this.WhereClause = bp(this), this.on("versionchange", function(s) {
                    s.newVersion > 0 ? console.warn("Another connection wants to upgrade database '" + r.name + "'. Closing db now to resume the upgrade.") : console.warn("Another connection wants to delete database '" + r.name + "'. Closing db now to resume the delete request."), r.close()
                }), this.on("blocked", function(s) {
                    !s.newVersion || s.newVersion < s.oldVersion ? console.warn("Dexie.delete('" + r.name + "') was blocked") : console.warn("Upgrade '" + r.name + "' blocked by other connection holding version " + s.oldVersion / 10)
                }), this._maxKey = jn(n.IDBKeyRange), this._createTransaction = function(s, l, u, c) {
                    return new r.Transaction(s, l, u, r._options.chromeTransactionDurability, c)
                }, this._fireOnBlocked = function(s) {
                    r.on("blocked").fire(s), Dn.filter(function(l) {
                        return l.name === r.name && l !== r && !l._state.vcFired
                    }).map(function(l) {
                        return l.on("versionchange").fire(s)
                    })
                }, this.use(zp), this.use(Yp), this.use(Jp), this.use(Zp), this.vip = Object.create(this, {
                    _vip: {
                        value: !0
                    }
                }), o.forEach(function(s) {
                    return s(r)
                })
            }
            return e.prototype.version = function(t) {
                if (isNaN(t) || t < .1) throw new j.Type("Given version is not a positive number");
                if (t = Math.round(t * 10) / 10, this.idbdb || this._state.isBeingOpened) throw new j.Schema("Cannot add version when database is open");
                this.verno = Math.max(this.verno, t);
                var n = this._versions,
                    r = n.filter(function(i) {
                        return i._cfg.version === t
                    })[0];
                return r || (r = new this.Version(t), n.push(r), n.sort(Rp), r.stores({}), this._state.autoSchema = !1, r)
            }, e.prototype._whenReady = function(t) {
                var n = this;
                return this.idbdb && (this._state.openComplete || N.letThrough || this._vip) ? t() : new O(function(r, i) {
                    if (n._state.openComplete) return i(new j.DatabaseClosed(n._state.dbOpenError));
                    if (!n._state.isBeingOpened) {
                        if (!n._options.autoOpen) {
                            i(new j.DatabaseClosed);
                            return
                        }
                        n.open().catch(W)
                    }
                    n._state.dbReadyPromise.then(r, i)
                }).then(t)
            }, e.prototype.use = function(t) {
                var n = t.stack,
                    r = t.create,
                    i = t.level,
                    o = t.name;
                o && this.unuse({
                    stack: n,
                    name: o
                });
                var a = this._middlewares[n] || (this._middlewares[n] = []);
                return a.push({
                    stack: n,
                    create: r,
                    level: i == null ? 10 : i,
                    name: o
                }), a.sort(function(s, l) {
                    return s.level - l.level
                }), this
            }, e.prototype.unuse = function(t) {
                var n = t.stack,
                    r = t.name,
                    i = t.create;
                return n && this._middlewares[n] && (this._middlewares[n] = this._middlewares[n].filter(function(o) {
                    return i ? o.create !== i : r ? o.name !== r : !1
                })), this
            }, e.prototype.open = function() {
                return $p(this)
            }, e.prototype._close = function() {
                var t = this._state,
                    n = Dn.indexOf(this);
                if (n >= 0 && Dn.splice(n, 1), this.idbdb) {
                    try {
                        this.idbdb.close()
                    } catch {}
                    this._novip.idbdb = null
                }
                t.dbReadyPromise = new O(function(r) {
                    t.dbReadyResolve = r
                }), t.openCanceller = new O(function(r, i) {
                    t.cancelOpen = i
                })
            }, e.prototype.close = function() {
                this._close();
                var t = this._state;
                this._options.autoOpen = !1, t.dbOpenError = new j.DatabaseClosed, t.isBeingOpened && t.cancelOpen(t.dbOpenError)
            }, e.prototype.delete = function() {
                var t = this,
                    n = arguments.length > 0,
                    r = this._state;
                return new O(function(i, o) {
                    var a = function() {
                        t.close();
                        var s = t._deps.indexedDB.deleteDatabase(t.name);
                        s.onsuccess = J(function() {
                            Hp(t._deps, t.name), i()
                        }), s.onerror = Fe(o), s.onblocked = t._fireOnBlocked
                    };
                    if (n) throw new j.InvalidArgument("Arguments not allowed in db.delete()");
                    r.isBeingOpened ? r.dbReadyPromise.then(a) : a()
                })
            }, e.prototype.backendDB = function() {
                return this.idbdb
            }, e.prototype.isOpen = function() {
                return this.idbdb !== null
            }, e.prototype.hasBeenClosed = function() {
                var t = this._state.dbOpenError;
                return t && t.name === "DatabaseClosed"
            }, e.prototype.hasFailed = function() {
                return this._state.dbOpenError !== null
            }, e.prototype.dynamicallyOpened = function() {
                return this._state.autoSchema
            }, Object.defineProperty(e.prototype, "tables", {
                get: function() {
                    var t = this;
                    return re(this._allTables).map(function(n) {
                        return t._allTables[n]
                    })
                },
                enumerable: !1,
                configurable: !0
            }), e.prototype.transaction = function() {
                var t = Gp.apply(this, arguments);
                return this._transaction.apply(this, t)
            }, e.prototype._transaction = function(t, n, r) {
                var i = this,
                    o = N.trans;
                (!o || o.db !== this || t.indexOf("!") !== -1) && (o = null);
                var a = t.indexOf("?") !== -1;
                t = t.replace("!", "").replace("?", "");
                var s, l;
                try {
                    if (l = n.map(function(c) {
                            var f = c instanceof i.Table ? c.name : c;
                            if (typeof f != "string") throw new TypeError("Invalid table argument to Dexie.transaction(). Only Table or String are allowed");
                            return f
                        }), t == "r" || t === Xi) s = Xi;
                    else if (t == "rw" || t == Ji) s = Ji;
                    else throw new j.InvalidArgument("Invalid transaction mode: " + t);
                    if (o) {
                        if (o.mode === Xi && s === Ji)
                            if (a) o = null;
                            else throw new j.SubTransaction("Cannot enter a sub-transaction with READWRITE mode when parent transaction is READONLY");
                        o && l.forEach(function(c) {
                            if (o && o.storeNames.indexOf(c) === -1)
                                if (a) o = null;
                                else throw new j.SubTransaction("Table " + c + " not included in parent transaction.")
                        }), a && o && !o.active && (o = null)
                    }
                } catch (c) {
                    return o ? o._promise(null, function(f, d) {
                        d(c)
                    }) : oe(c)
                }
                var u = Ms.bind(null, this, s, l, o, r);
                return o ? o._promise(s, u, "lock") : N.trans ? rn(N.transless, function() {
                    return i._whenReady(u)
                }) : this._whenReady(u)
            }, e.prototype.table = function(t) {
                if (!_e(this._allTables, t)) throw new j.InvalidTable("Table " + t + " does not exist");
                return this._allTables[t]
            }, e
        }(),
        th = typeof Symbol < "u" && "observable" in Symbol ? Symbol.observable : "@@observable",
        nh = function() {
            function e(t) {
                this._subscribe = t
            }
            return e.prototype.subscribe = function(t, n, r) {
                return this._subscribe(!t || typeof t == "function" ? {
                    next: t,
                    error: n,
                    complete: r
                } : t)
            }, e.prototype[th] = function() {
                return this
            }, e
        }();

    function Bs(e, t) {
        return re(t).forEach(function(n) {
            var r = e[n] || (e[n] = new tt);
            Ur(r, t[n])
        }), e
    }

    function rh(e) {
        return new nh(function(t) {
            var n = Oi(e);

            function r(p) {
                n && nn();
                var h = function() {
                        return ft(e, {
                            subscr: p,
                            trans: null
                        })
                    },
                    v = N.trans ? rn(N.transless, h) : h();
                return n && v.then(Je, Je), v
            }
            var i = !1,
                o = {},
                a = {},
                s = {
                    get closed() {
                        return i
                    },
                    unsubscribe: function() {
                        i = !0, mt.storagemutated.unsubscribe(f)
                    }
                };
            t.start && t.start(s);
            var l = !1,
                u = !1;

            function c() {
                return re(a).some(function(p) {
                    return o[p] && Xp(o[p], a[p])
                })
            }
            var f = function(p) {
                    Bs(o, p), c() && d()
                },
                d = function() {
                    if (!(l || i)) {
                        o = {};
                        var p = {},
                            h = r(p);
                        u || (mt(Mn, f), u = !0), l = !0, Promise.resolve(h).then(function(v) {
                            l = !1, !i && (c() ? d() : (o = {}, a = p, t.next && t.next(v)))
                        }, function(v) {
                            l = !1, t.error && t.error(v), s.unsubscribe()
                        })
                    }
                };
            return d(), s
        })
    }
    var bo;
    try {
        bo = {
            indexedDB: Q.indexedDB || Q.mozIndexedDB || Q.webkitIndexedDB || Q.msIndexedDB,
            IDBKeyRange: Q.IDBKeyRange || Q.webkitIDBKeyRange
        }
    } catch {
        bo = {
            indexedDB: null,
            IDBKeyRange: null
        }
    }
    var Nt = wo;
    Zt(Nt, $($({}, hr), {
        delete: function(e) {
            var t = new Nt(e, {
                addons: []
            });
            return t.delete()
        },
        exists: function(e) {
            return new Nt(e, {
                addons: []
            }).open().then(function(t) {
                return t.close(), !0
            }).catch("NoSuchDatabaseError", function() {
                return !1
            })
        },
        getDatabaseNames: function(e) {
            try {
                return Fp(Nt.dependencies).then(e)
            } catch {
                return oe(new j.MissingAPI)
            }
        },
        defineClass: function() {
            function e(t) {
                pe(this, t)
            }
            return e
        },
        ignoreTransaction: function(e) {
            return N.trans ? rn(N.transless, e) : e()
        },
        vip: ho,
        async: function(e) {
            return function() {
                try {
                    var t = vo(e.apply(this, arguments));
                    return !t || typeof t.then != "function" ? O.resolve(t) : t
                } catch (n) {
                    return oe(n)
                }
            }
        },
        spawn: function(e, t, n) {
            try {
                var r = vo(e.apply(n, t || []));
                return !r || typeof r.then != "function" ? O.resolve(r) : r
            } catch (i) {
                return oe(i)
            }
        },
        currentTransaction: {
            get: function() {
                return N.trans || null
            }
        },
        waitFor: function(e, t) {
            var n = O.resolve(typeof e == "function" ? Nt.ignoreTransaction(e) : e).timeout(t || 6e4);
            return N.trans ? N.trans.waitFor(n) : n
        },
        Promise: O,
        debug: {
            get: function() {
                return Ve
            },
            set: function(e) {
                as(e, e === "dexie" ? function() {
                    return !0
                } : Ss)
            }
        },
        derive: Xt,
        extend: pe,
        props: Zt,
        override: es,
        Events: Un,
        on: mt,
        liveQuery: rh,
        extendObservabilitySet: Bs,
        getByKeyPath: Ze,
        setByKeyPath: Le,
        delByKeyPath: Pf,
        shallowClone: rs,
        deepClone: Sn,
        getObjectDiff: mo,
        cmp: he,
        asap: ts,
        minKey: Zi,
        addons: [],
        connections: Dn,
        errnames: Pi,
        dependencies: bo,
        semVer: xs,
        version: xs.split(".").map(function(e) {
            return parseInt(e)
        }).reduce(function(e, t, n) {
            return e + t / Math.pow(10, n * 2)
        })
    })), Nt.maxKey = jn(Nt.dependencies.IDBKeyRange), typeof dispatchEvent < "u" && typeof addEventListener < "u" && (mt(Mn, function(e) {
        if (!nt) {
            var t;
            Ir ? (t = document.createEvent("CustomEvent"), t.initCustomEvent(vt, !0, !0, e)) : t = new CustomEvent(vt, {
                detail: e
            }), nt = !0, dispatchEvent(t), nt = !1
        }
    }), addEventListener(vt, function(e) {
        var t = e.detail;
        nt || Pr(t)
    }));

    function Pr(e) {
        var t = nt;
        try {
            nt = !0, mt.storagemutated.fire(e)
        } finally {
            nt = t
        }
    }
    var nt = !1;
    if (typeof BroadcastChannel < "u") {
        var Nr = new BroadcastChannel(vt);
        typeof Nr.unref == "function" && Nr.unref(), mt(Mn, function(e) {
            nt || Nr.postMessage(e)
        }), Nr.onmessage = function(e) {
            e.data && Pr(e.data)
        }
    } else if (typeof self < "u" && typeof navigator < "u") {
        mt(Mn, function(e) {
            try {
                nt || (typeof localStorage < "u" && localStorage.setItem(vt, JSON.stringify({
                    trig: Math.random(),
                    changedParts: e
                })), typeof self.clients == "object" && ki([], self.clients.matchAll({
                    includeUncontrolled: !0
                }), !0).forEach(function(t) {
                    return t.postMessage({
                        type: vt,
                        changedParts: e
                    })
                }))
            } catch {}
        }), typeof addEventListener < "u" && addEventListener("storage", function(e) {
            if (e.key === vt) {
                var t = JSON.parse(e.newValue);
                t && Pr(t.changedParts)
            }
        });
        var Hs = self.document && navigator.serviceWorker;
        Hs && Hs.addEventListener("message", ih)
    }

    function ih(e) {
        var t = e.data;
        t && t.type === vt && Pr(t.changedParts)
    }
    O.rejectionMapper = $f, as(Ve, Ss);
    var sn = (e => (e.ReadyForUpload = "ReadyForUpload", e.UploadComplete = "UploadComplete", e))(sn || {}),
        Bn = (e => (e.After = "after", e.Before = "before", e.BeforeAndAfter = "beforeAndAfter", e))(Bn || {});
    const Ks = "sprig.sessionId",
        $s = "sprig.disableReplayRecording",
        Gs = () => {
            sessionStorage.setItem($s, "disabled")
        },
        Mt = () => !!sessionStorage.getItem($s),
        oh = ["did not allow mutations", "called in an invalid security context"],
        ah = e => {
            if (!e) return !0;
            for (const t of oh)
                if (e.toLowerCase().includes(t)) return !1;
            return !0
        },
        qs = (e, t, n) => {
            Mt() || t instanceof Error && (Gs(), ah(t == null ? void 0 : t.message) && (sh(), window.UserLeap.reportError(e, t, n)))
        },
        Be = (e, t) => {
            var n, r;
            (r = (n = window.navigator) == null ? void 0 : n.storage) != null && r.estimate ? window.navigator.storage.estimate().then(i => {
                qs(e, t, i)
            }).catch(i => {
                window.UserLeap.reportError("Error getting storage estimate", i)
            }) : qs(e, t)
        },
        rt = (() => {
            const e = sessionStorage.getItem(Ks);
            if (e) return e;
            const t = ct();
            return sessionStorage.setItem(Ks, t), t
        })(),
        sh = () => {
            Promise.all([Y.events.clear(), Y.chunkUploads.clear(), Y.pendingCaptures.clear()]).catch(e => {
                window.UserLeap.reportError("Error wiping database", e)
            })
        },
        Eo = (e, t) => Y.table(t).where("timestamp").below(e).delete(),
        lh = () => {
            Y.events.where("sessionId").equals(rt).delete(), Y.pendingCaptures.where("sessionId").equals(rt).delete()
        },
        uh = e => {
            const t = e.map(n => {
                var r;
                return { ...n,
                    sessionId: (r = n.sessionId) != null ? r : rt
                }
            });
            return Y.events.bulkAdd(t)
        },
        ch = (e, t) => Y.events.where("[sessionId+timestamp]").between([rt, e], [rt, t]).toArray(),
        dh = e => {
            var t;
            return Y.chunkUploads.add({ ...e,
                sessionId: (t = e.sessionId) != null ? t : rt
            })
        },
        fh = (e, t) => Y.chunkUploads.update(e, {
            data: null,
            etag: t,
            status: sn.UploadComplete
        }),
        ph = ({
            status: e,
            uploadId: t
        }) => t ? Y.chunkUploads.where({
            uploadId: t,
            status: e
        }).toArray() : Y.chunkUploads.where({
            sessionId: rt,
            status: e
        }).toArray(),
        hh = e => Y.chunkUploads.where({
            uploadId: e,
            status: sn.UploadComplete
        }).toArray(),
        vh = e => Y.chunkUploads.where({
            uploadId: e,
            status: sn.UploadComplete
        }).delete(),
        mh = e => {
            var t;
            return Y.pendingCaptures.add({ ...e,
                sessionId: (t = e.sessionId) != null ? t : rt
            })
        },
        gh = () => Y.pendingCaptures.where("sessionId").equals(rt).and(e => e.targetTimestamp < Date.now()).toArray();
    class _h extends wo {
        constructor() {
            super("replayStorage", {
                autoOpen: !1
            });
            me(this, "events");
            me(this, "chunkUploads");
            me(this, "pendingCaptures")
        }
    }
    const Y = new _h;
    Y.version(1).stores({
        events: "uuid, timestamp, [sessionId+timestamp]",
        chunkUploads: "uuid, timestamp, [sessionId+status], [uploadId+status], [sessionId+status+uploadId]",
        pendingCaptures: "uuid, timestamp, [sessionId+targetTimestamp]"
    }), Y.open().catch(() => {
        Gs()
    });
    const yh = async (e, t, n) => new Promise((r, i) => {
        const o = e.createElement("script");
        o.src = t, o.onload = r, o.onerror = i, n && (o.nonce = n), e.head.appendChild(o)
    });
    let zs = 5e3,
        Mr = 6e4;
    const wh = 5,
        Ws = 30,
        xo = Ws + wh,
        Co = "sprig.pendingCount",
        Ys = sessionStorage.getItem("sprig.sessionId"),
        bh = async (e, t, n, r = 2, i) => {
            try {
                if (Mt() || !t) return;
                i != null && i.minDuration && (zs = i.minDuration), i != null && i.batchDuration && (Mr = i.batchDuration), kf(r), Th(), Ch(t + xo, 30 * 60, t + xo), Sh();
                const o = window;
                o.rrwebRecord || await yh(e, "https://cdn.sprig.com/dependencies/record-2.0.0-alpha.6.min.js", n);
                const a = o.rrwebRecord;
                if (!a) return;
                let s = !0;
                a({
                    checkoutEveryNms: Ws * 1e3,
                    sampling: {
                        input: "last",
                        scroll: 250,
                        media: 800
                    },
                    emit: (l, u) => {
                        if (Mt()) return;
                        const c = s || !!u;
                        s = !1, Eh({
                            uuid: ct(),
                            event: JSON.stringify(l),
                            isValidStart: c,
                            timestamp: Date.now()
                        })
                    },
                    ...i
                })
            } catch (o) {
                Be("Error initializing replay", o)
            }
        };
    let So = !1,
        Io = [];
    const Eh = e => {
            Io.push(e), So || xh()
        },
        xh = () => {
            So = !0, setTimeout(async () => {
                if (Mt()) return;
                const e = Io;
                Io = [], So = !1;
                try {
                    await uh(e)
                } catch (t) {
                    Be("Error storing replay events", t)
                }
            }, 500)
        },
        Ch = (e = 6 * 60, t = 30 * 60, n = 4 * 60) => {
            const r = setInterval(async () => {
                const i = Date.now();
                Mt() || await Y.transaction("rw", Y.events, Y.chunkUploads, Y.pendingCaptures, () => {
                    Eo(i - e * 1e3, "events"), Eo(i - t * 1e3, "chunkUploads"), Eo(i - n * 1e3, "pendingCaptures")
                }).catch(o => {
                    clearInterval(r), Be("Error deleting table rows", o)
                })
            }, 3e4)
        },
        Sh = (e = 5) => {
            setInterval(Dh, e * 1e3)
        },
        Ih = async (e, t, n, r, i) => {
            try {
                const o = Math.min(e + i, n),
                    a = await ch(e, o);
                if (!(a != null && a.length)) return [r, []];
                if (!r) {
                    let s = -1;
                    return a == null || a.forEach((l, u) => {
                        if (!l.isValidStart) return;
                        const c = l.timestamp <= t;
                        (s < 0 || c) && (s = u)
                    }), s < 0 ? [] : [!0, a == null ? void 0 : a.slice(s)]
                }
                return [r, a]
            } catch (o) {
                Be("Error getting events batch", o)
            }
        },
        kh = (e, t, n) => {
            const r = e.length,
                i = t * 1024 * 1024,
                o = Math.ceil(r / n),
                a = Math.max(i, o),
                s = [];
            let l = 0;
            for (; l < r;) s.push(e.slice(l, l + a)), l += a;
            return s
        },
        Qs = e => Promise.all(e.map(async t => {
            const n = await Lf(t);
            return await fh(t.uuid, n), t.uploadId
        })),
        Zs = async e => {
            const t = await hh(e);
            if (!(t != null && t.length)) return;
            t.sort((i, o) => i.chunkIndex - o.chunkIndex);
            const n = t.map(i => ({
                    ETag: i.etag,
                    PartNumber: i.chunkIndex
                })).filter(i => i.ETag !== null),
                r = t[0];
            await Rf({
                apiUrl: r.apiUrl,
                surveyId: r.surveyId,
                uploadId: e,
                responseGroupUuid: r.responseGroupId,
                etags: n,
                headers: r.completeUploadHeaders,
                replayDuration: r.replayDuration
            }), await vh(e)
        },
        Th = async () => {
            try {
                let e = [];
                if (await Y.transaction("rw", Y.chunkUploads, async () => {
                        e = await ph({
                            status: sn.ReadyForUpload
                        }).catch(n => {
                            Be("chunkUploads transaction error", n)
                        })
                    }), !(e != null && e.length)) return;
                const t = await Qs(e);
                t != null && t.length && await Promise.all(t.map(async n => {
                    n && await Zs(n)
                }))
            } catch (e) {
                Be("Error getting chunk upload uuids", e)
            }
        },
        Lh = async (e, t) => {
            await Qs(t), await Promise.all(e.map(n => Zs(n)))
        },
        Rh = e => {
            let t = 0;
            e.forEach(i => {
                t += i.length
            });
            const n = new Uint8Array(t);
            let r = 0;
            return e.forEach(i => {
                n.set(i, r), r += i.length
            }), n
        },
        Xs = async (e, t, n, r) => {
            const i = new TextEncoder;
            let o = null,
                a = null,
                s = null,
                l = !1,
                u = !1,
                [c, f] = [0, 0];
            const d = e - xo * 1e3,
                p = [];
            let h = [];
            for (let m = 0; m < n; m++) {
                if ([u, h] = await Ih(d + m * Mr, e, t, u, Mr), !(h != null && h.length)) continue;
                c === 0 && (c = h[0].timestamp), f = h[h.length - 1].timestamp;
                const y = `${l?",":"["}${h.map(E=>E.event).join(",")}`,
                    _ = i.encode(y);
                r ? (a === null && (s = new CompressionStream("gzip"), a = s.writable.getWriter()), a.write(_)) : p.push(_), l = !0
            }
            if (f - c < zs) return null;
            const v = i.encode("]");
            return a ? (a.write(v), a.close(), o = new Uint8Array(await new Response(s.readable).arrayBuffer())) : (p.push(v), o = Rh(p)), o
        },
        Ah = async e => {
            const t = Math.ceil(e / Mr),
                n = window.CompressionStream !== void 0;
            let r = null;
            const i = Date.now(),
                o = i - e;
            try {
                r = await Xs(o, i, t, n)
            } catch (a) {
                if (a instanceof Error && window.UserLeap.reportError("Error compressing replay", a), n) try {
                    r = await Xs(o, i, t, !1)
                } catch (s) {
                    Be("fileData fallback failed", s)
                }
            }
            return r
        },
        Js = async e => {
            if (!Mt()) try {
                const {
                    surveyId: t,
                    responseGroupId: n,
                    visitorId: r,
                    apiUrl: i,
                    completeUploadHeaders: o,
                    replayParams: a
                } = e;
                if (a.replayDurationType === Bn.After || a.replayDurationType === Bn.BeforeAndAfter) {
                    await Oh(e);
                    return
                }
                const s = await Ah(a.replayDurationSeconds * 1e3);
                if (!(s != null && s.length)) return;
                const l = kh(s, a.minimumChunkSizeMb, a.signedUrls.length),
                    u = Date.now(),
                    c = await Promise.all(l.map(async (f, d) => {
                        const p = ct(),
                            h = {
                                apiUrl: i,
                                chunkIndex: d + 1,
                                completeUploadHeaders: o,
                                etag: null,
                                responseGroupId: n,
                                sessionId: Ys,
                                status: sn.ReadyForUpload,
                                surveyId: t,
                                timestamp: u,
                                totalChunks: l.length,
                                data: f,
                                uploadId: a.uploadId,
                                uploadUrl: a.signedUrls[d].url,
                                uuid: p,
                                visitorId: r
                            };
                        return await dh(h), h
                    }));
                await Lh([a.uploadId], c)
            } catch (t) {
                Be("Error scheduling or capturing replay", t)
            }
        },
        el = () => {
            if (!Mt()) try {
                lh()
            } catch (e) {
                Be("Error clearing session event data", e)
            }
        };
    let it = sessionStorage.getItem(Co);
    const Oh = async e => {
            const {
                surveyId: t
            } = e, n = await Y.pendingCaptures.where({
                sessionId: Ys
            }).toArray(), r = n == null ? void 0 : n.filter(a => a.captureParams.surveyId === t);
            if (r != null && r.length) return;
            const i = { ...e,
                replayParams: { ...e.replayParams
                }
            };
            e.replayParams.replayDurationType === Bn.BeforeAndAfter && (i.replayParams.replayDurationSeconds *= 2), i.replayParams.replayDurationType = Bn.Before;
            const o = Date.now() + e.replayParams.replayDurationSeconds * 1e3;
            return it = it ? (parseInt(it) + 1).toString() : "1", sessionStorage.setItem(Co, it), mh({
                uuid: ct(),
                targetTimestamp: o,
                timestamp: Date.now(),
                captureParams: i
            })
        },
        Dh = async () => {
            try {
                if (it && parseInt(it) > 0) {
                    const e = await gh();
                    e.length && await Promise.all(e.map(async t => {
                        await Y.pendingCaptures.delete(t.uuid), await Js(t.captureParams)
                    })), it = (parseInt(it) - e.length).toString(), sessionStorage.setItem(Co, it)
                }
            } catch (e) {
                Be("Error initiating pending captures", e)
            }
        };
    var Hn, P, tl, ln, jt, nl, rl, il, jr = {},
        ol = [],
        Uh = /acit|ex(?:s|g|n|p|$)|rph|grid|ows|mnc|ntw|ine[ch]|zoo|^ord|itera/i;

    function ot(e, t) {
        for (var n in t) e[n] = t[n];
        return e
    }

    function al(e) {
        var t = e.parentNode;
        t && t.removeChild(e)
    }

    function te(e, t, n) {
        var r, i, o, a = {};
        for (o in t) o == "key" ? r = t[o] : o == "ref" ? i = t[o] : a[o] = t[o];
        if (arguments.length > 2 && (a.children = arguments.length > 3 ? Hn.call(arguments, 2) : n), typeof e == "function" && e.defaultProps != null)
            for (o in e.defaultProps) a[o] === void 0 && (a[o] = e.defaultProps[o]);
        return Kn(e, a, r, i, null)
    }

    function Kn(e, t, n, r, i) {
        var o = {
            type: e,
            props: t,
            key: n,
            ref: r,
            __k: null,
            __: null,
            __b: 0,
            __e: null,
            __d: void 0,
            __c: null,
            __h: null,
            constructor: void 0,
            __v: i == null ? ++tl : i
        };
        return i == null && P.vnode != null && P.vnode(o), o
    }

    function sl() {
        return {
            current: null
        }
    }

    function Re(e) {
        return e.children
    }

    function Ph(e, t, n, r, i) {
        var o;
        for (o in n) o === "children" || o === "key" || o in t || Vr(e, o, null, n[o], r);
        for (o in t) i && typeof t[o] != "function" || o === "children" || o === "key" || o === "value" || o === "checked" || n[o] === t[o] || Vr(e, o, t[o], n[o], r)
    }

    function ll(e, t, n) {
        t[0] === "-" ? e.setProperty(t, n == null ? "" : n) : e[t] = n == null ? "" : typeof n != "number" || Uh.test(t) ? n : n + "px"
    }

    function Vr(e, t, n, r, i) {
        var o;
        e: if (t === "style")
            if (typeof n == "string") e.style.cssText = n;
            else {
                if (typeof r == "string" && (e.style.cssText = r = ""), r)
                    for (t in r) n && t in n || ll(e.style, t, "");
                if (n)
                    for (t in n) r && n[t] === r[t] || ll(e.style, t, n[t])
            }
        else if (t[0] === "o" && t[1] === "n") o = t !== (t = t.replace(/Capture$/, "")), t = t.toLowerCase() in e ? t.toLowerCase().slice(2) : t.slice(2), e.l || (e.l = {}), e.l[t + o] = n, n ? r || e.addEventListener(t, o ? cl : ul, o) : e.removeEventListener(t, o ? cl : ul, o);
        else if (t !== "dangerouslySetInnerHTML") {
            if (i) t = t.replace(/xlink(H|:h)/, "h").replace(/sName$/, "s");
            else if (t !== "width" && t !== "height" && t !== "href" && t !== "list" && t !== "form" && t !== "tabIndex" && t !== "download" && t in e) try {
                e[t] = n == null ? "" : n;
                break e
            } catch {}
            typeof n == "function" || (n == null || n === !1 && t.indexOf("-") == -1 ? e.removeAttribute(t) : e.setAttribute(t, n))
        }
    }

    function ul(e) {
        ln = !0;
        try {
            return this.l[e.type + !1](P.event ? P.event(e) : e)
        } finally {
            ln = !1
        }
    }

    function cl(e) {
        ln = !0;
        try {
            return this.l[e.type + !0](P.event ? P.event(e) : e)
        } finally {
            ln = !1
        }
    }

    function Ae(e, t) {
        this.props = e, this.context = t
    }

    function $n(e, t) {
        if (t == null) return e.__ ? $n(e.__, e.__.__k.indexOf(e) + 1) : null;
        for (var n; t < e.__k.length; t++)
            if ((n = e.__k[t]) != null && n.__e != null) return n.__e;
        return typeof e.type == "function" ? $n(e) : null
    }

    function dl(e) {
        var t, n;
        if ((e = e.__) != null && e.__c != null) {
            for (e.__e = e.__c.base = null, t = 0; t < e.__k.length; t++)
                if ((n = e.__k[t]) != null && n.__e != null) {
                    e.__e = e.__c.base = n.__e;
                    break
                }
            return dl(e)
        }
    }

    function Nh(e) {
        ln ? setTimeout(e) : rl(e)
    }

    function ko(e) {
        (!e.__d && (e.__d = !0) && jt.push(e) && !Fr.__r++ || nl !== P.debounceRendering) && ((nl = P.debounceRendering) || Nh)(Fr)
    }

    function Fr() {
        var e, t, n, r, i, o, a, s;
        for (jt.sort(function(l, u) {
                return l.__v.__b - u.__v.__b
            }); e = jt.shift();) e.__d && (t = jt.length, r = void 0, i = void 0, a = (o = (n = e).__v).__e, (s = n.__P) && (r = [], (i = ot({}, o)).__v = o.__v + 1, To(s, o, i, n.__n, s.ownerSVGElement !== void 0, o.__h != null ? [a] : null, r, a == null ? $n(o) : a, o.__h), ml(r, o), o.__e != a && dl(o)), jt.length > t && jt.sort(function(l, u) {
            return l.__v.__b - u.__v.__b
        }));
        Fr.__r = 0
    }

    function fl(e, t, n, r, i, o, a, s, l, u) {
        var c, f, d, p, h, v, m, y = r && r.__k || ol,
            _ = y.length;
        for (n.__k = [], c = 0; c < t.length; c++)
            if ((p = n.__k[c] = (p = t[c]) == null || typeof p == "boolean" ? null : typeof p == "string" || typeof p == "number" || typeof p == "bigint" ? Kn(null, p, null, null, p) : Array.isArray(p) ? Kn(Re, {
                    children: p
                }, null, null, null) : p.__b > 0 ? Kn(p.type, p.props, p.key, p.ref ? p.ref : null, p.__v) : p) != null) {
                if (p.__ = n, p.__b = n.__b + 1, (d = y[c]) === null || d && p.key == d.key && p.type === d.type) y[c] = void 0;
                else
                    for (f = 0; f < _; f++) {
                        if ((d = y[f]) && p.key == d.key && p.type === d.type) {
                            y[f] = void 0;
                            break
                        }
                        d = null
                    }
                To(e, p, d = d || jr, i, o, a, s, l, u), h = p.__e, (f = p.ref) && d.ref != f && (m || (m = []), d.ref && m.push(d.ref, null, p), m.push(f, p.__c || h, p)), h != null ? (v == null && (v = h), typeof p.type == "function" && p.__k === d.__k ? p.__d = l = pl(p, l, e) : l = hl(e, p, d, y, h, l), typeof n.type == "function" && (n.__d = l)) : l && d.__e == l && l.parentNode != e && (l = $n(d))
            }
        for (n.__e = v, c = _; c--;) y[c] != null && (typeof n.type == "function" && y[c].__e != null && y[c].__e == n.__d && (n.__d = vl(r).nextSibling), _l(y[c], y[c]));
        if (m)
            for (c = 0; c < m.length; c++) gl(m[c], m[++c], m[++c])
    }

    function pl(e, t, n) {
        for (var r, i = e.__k, o = 0; i && o < i.length; o++)(r = i[o]) && (r.__ = e, t = typeof r.type == "function" ? pl(r, t, n) : hl(n, r, r, i, r.__e, t));
        return t
    }

    function at(e, t) {
        return t = t || [], e == null || typeof e == "boolean" || (Array.isArray(e) ? e.some(function(n) {
            at(n, t)
        }) : t.push(e)), t
    }

    function hl(e, t, n, r, i, o) {
        var a, s, l;
        if (t.__d !== void 0) a = t.__d, t.__d = void 0;
        else if (n == null || i != o || i.parentNode == null) e: if (o == null || o.parentNode !== e) e.appendChild(i), a = null;
            else {
                for (s = o, l = 0;
                    (s = s.nextSibling) && l < r.length; l += 1)
                    if (s == i) break e;
                e.insertBefore(i, o), a = o
            }
        return a !== void 0 ? a : i.nextSibling
    }

    function vl(e) {
        var t, n, r;
        if (e.type == null || typeof e.type == "string") return e.__e;
        if (e.__k) {
            for (t = e.__k.length - 1; t >= 0; t--)
                if ((n = e.__k[t]) && (r = vl(n))) return r
        }
        return null
    }

    function To(e, t, n, r, i, o, a, s, l) {
        var u, c, f, d, p, h, v, m, y, _, E, b, w, x, C, I = t.type;
        if (t.constructor !== void 0) return null;
        n.__h != null && (l = n.__h, s = t.__e = n.__e, t.__h = null, o = [s]), (u = P.__b) && u(t);
        try {
            e: if (typeof I == "function") {
                if (m = t.props, y = (u = I.contextType) && r[u.__c], _ = u ? y ? y.props.value : u.__ : r, n.__c ? v = (c = t.__c = n.__c).__ = c.__E : ("prototype" in I && I.prototype.render ? t.__c = c = new I(m, _) : (t.__c = c = new Ae(m, _), c.constructor = I, c.render = jh), y && y.sub(c), c.props = m, c.state || (c.state = {}), c.context = _, c.__n = r, f = c.__d = !0, c.__h = [], c._sb = []), c.__s == null && (c.__s = c.state), I.getDerivedStateFromProps != null && (c.__s == c.state && (c.__s = ot({}, c.__s)), ot(c.__s, I.getDerivedStateFromProps(m, c.__s))), d = c.props, p = c.state, c.__v = t, f) I.getDerivedStateFromProps == null && c.componentWillMount != null && c.componentWillMount(), c.componentDidMount != null && c.__h.push(c.componentDidMount);
                else {
                    if (I.getDerivedStateFromProps == null && m !== d && c.componentWillReceiveProps != null && c.componentWillReceiveProps(m, _), !c.__e && c.shouldComponentUpdate != null && c.shouldComponentUpdate(m, c.__s, _) === !1 || t.__v === n.__v) {
                        for (t.__v !== n.__v && (c.props = m, c.state = c.__s, c.__d = !1), t.__e = n.__e, t.__k = n.__k, t.__k.forEach(function(k) {
                                k && (k.__ = t)
                            }), E = 0; E < c._sb.length; E++) c.__h.push(c._sb[E]);
                        c._sb = [], c.__h.length && a.push(c);
                        break e
                    }
                    c.componentWillUpdate != null && c.componentWillUpdate(m, c.__s, _), c.componentDidUpdate != null && c.__h.push(function() {
                        c.componentDidUpdate(d, p, h)
                    })
                }
                if (c.context = _, c.props = m, c.__P = e, b = P.__r, w = 0, "prototype" in I && I.prototype.render) {
                    for (c.state = c.__s, c.__d = !1, b && b(t), u = c.render(c.props, c.state, c.context), x = 0; x < c._sb.length; x++) c.__h.push(c._sb[x]);
                    c._sb = []
                } else
                    do c.__d = !1, b && b(t), u = c.render(c.props, c.state, c.context), c.state = c.__s; while (c.__d && ++w < 25);
                c.state = c.__s, c.getChildContext != null && (r = ot(ot({}, r), c.getChildContext())), f || c.getSnapshotBeforeUpdate == null || (h = c.getSnapshotBeforeUpdate(d, p)), C = u != null && u.type === Re && u.key == null ? u.props.children : u, fl(e, Array.isArray(C) ? C : [C], t, n, r, i, o, a, s, l), c.base = t.__e, t.__h = null, c.__h.length && a.push(c), v && (c.__E = c.__ = null), c.__e = !1
            } else o == null && t.__v === n.__v ? (t.__k = n.__k, t.__e = n.__e) : t.__e = Mh(n.__e, t, n, r, i, o, a, l);
            (u = P.diffed) && u(t)
        }
        catch (k) {
            t.__v = null, (l || o != null) && (t.__e = s, t.__h = !!l, o[o.indexOf(s)] = null), P.__e(k, t, n)
        }
    }

    function ml(e, t) {
        P.__c && P.__c(t, e), e.some(function(n) {
            try {
                e = n.__h, n.__h = [], e.some(function(r) {
                    r.call(n)
                })
            } catch (r) {
                P.__e(r, n.__v)
            }
        })
    }

    function Mh(e, t, n, r, i, o, a, s) {
        var l, u, c, f = n.props,
            d = t.props,
            p = t.type,
            h = 0;
        if (p === "svg" && (i = !0), o != null) {
            for (; h < o.length; h++)
                if ((l = o[h]) && "setAttribute" in l == !!p && (p ? l.localName === p : l.nodeType === 3)) {
                    e = l, o[h] = null;
                    break
                }
        }
        if (e == null) {
            if (p === null) return document.createTextNode(d);
            e = i ? document.createElementNS("http://www.w3.org/2000/svg", p) : document.createElement(p, d.is && d), o = null, s = !1
        }
        if (p === null) f === d || s && e.data === d || (e.data = d);
        else {
            if (o = o && Hn.call(e.childNodes), u = (f = n.props || jr).dangerouslySetInnerHTML, c = d.dangerouslySetInnerHTML, !s) {
                if (o != null)
                    for (f = {}, h = 0; h < e.attributes.length; h++) f[e.attributes[h].name] = e.attributes[h].value;
                (c || u) && (c && (u && c.__html == u.__html || c.__html === e.innerHTML) || (e.innerHTML = c && c.__html || ""))
            }
            if (Ph(e, d, f, i, s), c) t.__k = [];
            else if (h = t.props.children, fl(e, Array.isArray(h) ? h : [h], t, n, r, i && p !== "foreignObject", o, a, o ? o[0] : n.__k && $n(n, 0), s), o != null)
                for (h = o.length; h--;) o[h] != null && al(o[h]);
            s || ("value" in d && (h = d.value) !== void 0 && (h !== e.value || p === "progress" && !h || p === "option" && h !== f.value) && Vr(e, "value", h, f.value, !1), "checked" in d && (h = d.checked) !== void 0 && h !== e.checked && Vr(e, "checked", h, f.checked, !1))
        }
        return e
    }

    function gl(e, t, n) {
        try {
            typeof e == "function" ? e(t) : e.current = t
        } catch (r) {
            P.__e(r, n)
        }
    }

    function _l(e, t, n) {
        var r, i;
        if (P.unmount && P.unmount(e), (r = e.ref) && (r.current && r.current !== e.__e || gl(r, null, t)), (r = e.__c) != null) {
            if (r.componentWillUnmount) try {
                r.componentWillUnmount()
            } catch (o) {
                P.__e(o, t)
            }
            r.base = r.__P = null, e.__c = void 0
        }
        if (r = e.__k)
            for (i = 0; i < r.length; i++) r[i] && _l(r[i], t, n || typeof e.type != "function");
        n || e.__e == null || al(e.__e), e.__ = e.__e = e.__d = void 0
    }

    function jh(e, t, n) {
        return this.constructor(e, n)
    }

    function un(e, t, n) {
        var r, i, o;
        P.__ && P.__(e, t), i = (r = typeof n == "function") ? null : n && n.__k || t.__k, o = [], To(t, e = (!r && n || t).__k = te(Re, null, [e]), i || jr, jr, t.ownerSVGElement !== void 0, !r && n ? [n] : i ? null : t.firstChild ? Hn.call(t.childNodes) : null, o, !r && n ? n : i ? i.__e : t.firstChild, r), ml(o, e)
    }

    function yl(e, t) {
        un(e, t, yl)
    }

    function Vh(e, t, n) {
        var r, i, o, a = ot({}, e.props);
        for (o in t) o == "key" ? r = t[o] : o == "ref" ? i = t[o] : a[o] = t[o];
        return arguments.length > 2 && (a.children = arguments.length > 3 ? Hn.call(arguments, 2) : n), Kn(e.type, a, r || e.key, i || e.ref, null)
    }

    function wl(e, t) {
        var n = {
            __c: t = "__cC" + il++,
            __: e,
            Consumer: function(r, i) {
                return r.children(i)
            },
            Provider: function(r) {
                var i, o;
                return this.getChildContext || (i = [], (o = {})[t] = this, this.getChildContext = function() {
                    return o
                }, this.shouldComponentUpdate = function(a) {
                    this.props.value !== a.value && i.some(function(s) {
                        s.__e = !0, ko(s)
                    })
                }, this.sub = function(a) {
                    i.push(a);
                    var s = a.componentWillUnmount;
                    a.componentWillUnmount = function() {
                        i.splice(i.indexOf(a), 1), s && s.call(a)
                    }
                }), r.children
            }
        };
        return n.Provider.__ = n.Consumer.contextType = n
    }
    Hn = ol.slice, P = {
        __e: function(e, t, n, r) {
            for (var i, o, a; t = t.__;)
                if ((i = t.__c) && !i.__) try {
                    if ((o = i.constructor) && o.getDerivedStateFromError != null && (i.setState(o.getDerivedStateFromError(e)), a = i.__d), i.componentDidCatch != null && (i.componentDidCatch(e, r || {}), a = i.__d), a) return i.__E = i
                } catch (s) {
                    e = s
                }
            throw e
        }
    }, tl = 0, ln = !1, Ae.prototype.setState = function(e, t) {
        var n;
        n = this.__s != null && this.__s !== this.state ? this.__s : this.__s = ot({}, this.state), typeof e == "function" && (e = e(ot({}, n), this.props)), e && ot(n, e), e != null && this.__v && (t && this._sb.push(t), ko(this))
    }, Ae.prototype.forceUpdate = function(e) {
        this.__v && (this.__e = !0, e && this.__h.push(e), ko(this))
    }, Ae.prototype.render = Re, jt = [], rl = typeof Promise == "function" ? Promise.prototype.then.bind(Promise.resolve()) : setTimeout, Fr.__r = 0, il = 0;
    var R = (e => (e.ConsentLegal = "consentlegal", e.Likert = "likert", e.MultipleChoice = "multiplechoice", e.MultipleSelect = "multipleselect", e.NPS = "nps", e.Open = "open", e.RecordedTask = "recordedtask", e.TextUrlPrompt = "texturlprompt", e.Thanks = "thanks", e.Uploading = "uploading", e.VideoVoice = "videovoice", e))(R || {}),
        st = (e => (e.Answered = "answered", e.Equal = "eq", e.NotEqual = "neq", e.Skipped = "skipped", e.LessThan = "lt", e.LessThanOrEqual = "lte", e.GivenUp = "given_up", e.GreaterThan = "gt", e.GreaterThanOrEqual = "gte", e.ListAll = "list_all", e.ListAtLeastOne = "list_alo", e.ListExact = "list_exact", e.DoesNotInclude = "list_dni", e.Contains = "contains", e.DoesNotContain = "notcontains", e))(st || {}),
        cn = (e => (e.Camera = "camera", e.Microphone = "microphone", e.Screen = "screen", e))(cn || {}),
        Ce = (e => (e.AvPermission = "av_permission", e.ScreenPermission = "screen_permission", e.StartTask = "start_task", e.CompleteTask = "complete_task", e))(Ce || {}),
        Vt = (e => (e.Number = "number", e.Smiley = "smiley", e.Star = "star", e))(Vt || {}),
        Oe = (e => (e.Video = "video", e.Audio = "audio", e.Screen = "screen", e))(Oe || {}),
        fe = (e => (e.PermissionStatus = "permission.status", e.AvPermission = "av.permission", e.ScreenPermission = "screen.permission", e.BeginRecording = "begin.recording", e.StartTask = "start.task", e.FinishTask = "finish.task", e))(fe || {}),
        Se = (e => (e.Abandoned = "abandoned", e.GivenUp = "given.up", e.Completed = "completed", e))(Se || {}),
        G = (e => (e.ScreenPermissionRequested = "screen.permission.requested", e.PermissionDescriptors = "permission.descriptors", e.PermissionStatusCallback = "permission.status.callback", e.StreamReadyCallback = "stream.ready.callback", e.StreamCanceledCallback = "stream.canceled.callback", e.TaskCompleteCallback = "task.complete.callback", e.TaskResponse = "task.response", e.TaskStatus = "task.status", e.RecordingMediaTypes = "recording.media.types", e.StartRecordingCallback = "start.recording.callback", e.PassthroughData = "passthrough.data", e.CurrentIndex = "current.index", e.UploadCallback = "upload.callback", e.ProgressCallback = "progress.callback", e.BeginCallback = "begin.callback", e))(G || {});
    const bl = e => {
            let t;
            const n = new Set,
                r = (l, u) => {
                    const c = typeof l == "function" ? l(t) : l;
                    if (!Object.is(c, t)) {
                        const f = t;
                        t = (u != null ? u : typeof c != "object") ? c : Object.assign({}, t, c), n.forEach(d => d(t, f))
                    }
                },
                i = () => t,
                s = {
                    setState: r,
                    getState: i,
                    subscribe: l => (n.add(l), () => n.delete(l)),
                    destroy: () => n.clear()
                };
            return t = e(r, i, s), s
        },
        Fh = e => e ? bl(e) : bl;
    var gt, Z, Lo, El, dn = 0,
        xl = [],
        Br = [],
        Cl = P.__b,
        Sl = P.__r,
        Il = P.diffed,
        kl = P.__c,
        Tl = P.unmount;

    function Ft(e, t) {
        P.__h && P.__h(Z, e, dn || t), dn = 0;
        var n = Z.__H || (Z.__H = {
            __: [],
            __h: []
        });
        return e >= n.__.length && n.__.push({
            __V: Br
        }), n.__[e]
    }

    function ue(e) {
        return dn = 1, Ro(Ul, e)
    }

    function Ro(e, t, n) {
        var r = Ft(gt++, 2);
        if (r.t = e, !r.__c && (r.__ = [n ? n(t) : Ul(void 0, t), function(o) {
                var a = r.__N ? r.__N[0] : r.__[0],
                    s = r.t(a, o);
                a !== s && (r.__N = [s, r.__[1]], r.__c.setState({}))
            }], r.__c = Z, !Z.u)) {
            Z.u = !0;
            var i = Z.shouldComponentUpdate;
            Z.shouldComponentUpdate = function(o, a, s) {
                if (!r.__c.__H) return !0;
                var l = r.__c.__H.__.filter(function(c) {
                    return c.__c
                });
                if (l.every(function(c) {
                        return !c.__N
                    })) return !i || i.call(this, o, a, s);
                var u = !1;
                return l.forEach(function(c) {
                    if (c.__N) {
                        var f = c.__[0];
                        c.__ = c.__N, c.__N = void 0, f !== c.__[0] && (u = !0)
                    }
                }), !(!u && r.__c.props === o) && (!i || i.call(this, o, a, s))
            }
        }
        return r.__N || r.__
    }

    function Ie(e, t) {
        var n = Ft(gt++, 3);
        !P.__s && Do(n.__H, t) && (n.__ = e, n.i = t, Z.__H.__h.push(n))
    }

    function Gn(e, t) {
        var n = Ft(gt++, 4);
        !P.__s && Do(n.__H, t) && (n.__ = e, n.i = t, Z.__h.push(n))
    }

    function _t(e) {
        return dn = 5, Hr(function() {
            return {
                current: e
            }
        }, [])
    }

    function Ll(e, t, n) {
        dn = 6, Gn(function() {
            return typeof e == "function" ? (e(t()), function() {
                return e(null)
            }) : e ? (e.current = t(), function() {
                return e.current = null
            }) : void 0
        }, n == null ? n : n.concat(e))
    }

    function Hr(e, t) {
        var n = Ft(gt++, 7);
        return Do(n.__H, t) ? (n.__V = e(), n.i = t, n.__h = e, n.__V) : n.__
    }

    function Rl(e, t) {
        return dn = 8, Hr(function() {
            return e
        }, t)
    }

    function Al(e) {
        var t = Z.context[e.__c],
            n = Ft(gt++, 9);
        return n.c = e, t ? (n.__ == null && (n.__ = !0, t.sub(Z)), t.props.value) : e.__
    }

    function Ao(e, t) {
        P.useDebugValue && P.useDebugValue(t ? t(e) : e)
    }

    function Bh(e) {
        var t = Ft(gt++, 10),
            n = ue();
        return t.__ = e, Z.componentDidCatch || (Z.componentDidCatch = function(r, i) {
            t.__ && t.__(r, i), n[1](r)
        }), [n[0], function() {
            n[1](void 0)
        }]
    }

    function Ol() {
        var e = Ft(gt++, 11);
        if (!e.__) {
            for (var t = Z.__v; t !== null && !t.__m && t.__ !== null;) t = t.__;
            var n = t.__m || (t.__m = [0, 0]);
            e.__ = "P" + n[0] + "-" + n[1]++
        }
        return e.__
    }

    function Hh() {
        for (var e; e = xl.shift();)
            if (e.__P && e.__H) try {
                e.__H.__h.forEach(Kr), e.__H.__h.forEach(Oo), e.__H.__h = []
            } catch (t) {
                e.__H.__h = [], P.__e(t, e.__v)
            }
    }
    P.__b = function(e) {
        Z = null, Cl && Cl(e)
    }, P.__r = function(e) {
        Sl && Sl(e), gt = 0;
        var t = (Z = e.__c).__H;
        t && (Lo === Z ? (t.__h = [], Z.__h = [], t.__.forEach(function(n) {
            n.__N && (n.__ = n.__N), n.__V = Br, n.__N = n.i = void 0
        })) : (t.__h.forEach(Kr), t.__h.forEach(Oo), t.__h = [])), Lo = Z
    }, P.diffed = function(e) {
        Il && Il(e);
        var t = e.__c;
        t && t.__H && (t.__H.__h.length && (xl.push(t) !== 1 && El === P.requestAnimationFrame || ((El = P.requestAnimationFrame) || Kh)(Hh)), t.__H.__.forEach(function(n) {
            n.i && (n.__H = n.i), n.__V !== Br && (n.__ = n.__V), n.i = void 0, n.__V = Br
        })), Lo = Z = null
    }, P.__c = function(e, t) {
        t.some(function(n) {
            try {
                n.__h.forEach(Kr), n.__h = n.__h.filter(function(r) {
                    return !r.__ || Oo(r)
                })
            } catch (r) {
                t.some(function(i) {
                    i.__h && (i.__h = [])
                }), t = [], P.__e(r, n.__v)
            }
        }), kl && kl(e, t)
    }, P.unmount = function(e) {
        Tl && Tl(e);
        var t, n = e.__c;
        n && n.__H && (n.__H.__.forEach(function(r) {
            try {
                Kr(r)
            } catch (i) {
                t = i
            }
        }), n.__H = void 0, t && P.__e(t, n.__v))
    };
    var Dl = typeof requestAnimationFrame == "function";

    function Kh(e) {
        var t, n = function() {
                clearTimeout(r), Dl && cancelAnimationFrame(t), setTimeout(e)
            },
            r = setTimeout(n, 100);
        Dl && (t = requestAnimationFrame(n))
    }

    function Kr(e) {
        var t = Z,
            n = e.__c;
        typeof n == "function" && (e.__c = void 0, n()), Z = t
    }

    function Oo(e) {
        var t = Z;
        e.__c = e.__(), Z = t
    }

    function Do(e, t) {
        return !e || e.length !== t.length || t.some(function(n, r) {
            return n !== e[r]
        })
    }

    function Ul(e, t) {
        return typeof t == "function" ? t(e) : t
    }

    function Pl(e, t) {
        for (var n in t) e[n] = t[n];
        return e
    }

    function Uo(e, t) {
        for (var n in e)
            if (n !== "__source" && !(n in t)) return !0;
        for (var r in t)
            if (r !== "__source" && e[r] !== t[r]) return !0;
        return !1
    }

    function Po(e, t) {
        return e === t && (e !== 0 || 1 / e == 1 / t) || e != e && t != t
    }

    function $r(e) {
        this.props = e
    }

    function Nl(e, t) {
        function n(i) {
            var o = this.props.ref,
                a = o == i.ref;
            return !a && o && (o.call ? o(null) : o.current = null), t ? !t(this.props, i) || !a : Uo(this.props, i)
        }

        function r(i) {
            return this.shouldComponentUpdate = n, te(e, i)
        }
        return r.displayName = "Memo(" + (e.displayName || e.name) + ")", r.prototype.isReactComponent = !0, r.__f = !0, r
    }($r.prototype = new Ae).isPureReactComponent = !0, $r.prototype.shouldComponentUpdate = function(e, t) {
        return Uo(this.props, e) || Uo(this.state, t)
    };
    var Ml = P.__b;
    P.__b = function(e) {
        e.type && e.type.__f && e.ref && (e.props.ref = e.ref, e.ref = null), Ml && Ml(e)
    };
    var $h = typeof Symbol < "u" && Symbol.for && Symbol.for("react.forward_ref") || 3911;

    function jl(e) {
        function t(n) {
            var r = Pl({}, n);
            return delete r.ref, e(r, n.ref || null)
        }
        return t.$$typeof = $h, t.render = t, t.prototype.isReactComponent = t.__f = !0, t.displayName = "ForwardRef(" + (e.displayName || e.name) + ")", t
    }
    var Vl = function(e, t) {
            return e == null ? null : at(at(e).map(t))
        },
        Fl = {
            map: Vl,
            forEach: Vl,
            count: function(e) {
                return e ? at(e).length : 0
            },
            only: function(e) {
                var t = at(e);
                if (t.length !== 1) throw "Children.only";
                return t[0]
            },
            toArray: at
        },
        Gh = P.__e;
    P.__e = function(e, t, n, r) {
        if (e.then) {
            for (var i, o = t; o = o.__;)
                if ((i = o.__c) && i.__c) return t.__e == null && (t.__e = n.__e, t.__k = n.__k), i.__c(e, t)
        }
        Gh(e, t, n, r)
    };
    var Bl = P.unmount;

    function Hl(e, t, n) {
        return e && (e.__c && e.__c.__H && (e.__c.__H.__.forEach(function(r) {
            typeof r.__c == "function" && r.__c()
        }), e.__c.__H = null), (e = Pl({}, e)).__c != null && (e.__c.__P === n && (e.__c.__P = t), e.__c = null), e.__k = e.__k && e.__k.map(function(r) {
            return Hl(r, t, n)
        })), e
    }

    function Kl(e, t, n) {
        return e && (e.__v = null, e.__k = e.__k && e.__k.map(function(r) {
            return Kl(r, t, n)
        }), e.__c && e.__c.__P === t && (e.__e && n.insertBefore(e.__e, e.__d), e.__c.__e = !0, e.__c.__P = n)), e
    }

    function qn() {
        this.__u = 0, this.t = null, this.__b = null
    }

    function $l(e) {
        var t = e.__.__c;
        return t && t.__a && t.__a(e)
    }

    function Gl(e) {
        var t, n, r;

        function i(o) {
            if (t || (t = e()).then(function(a) {
                    n = a.default || a
                }, function(a) {
                    r = a
                }), r) throw r;
            if (!n) throw t;
            return te(n, o)
        }
        return i.displayName = "Lazy", i.__f = !0, i
    }

    function fn() {
        this.u = null, this.o = null
    }
    P.unmount = function(e) {
        var t = e.__c;
        t && t.__R && t.__R(), t && e.__h === !0 && (e.type = null), Bl && Bl(e)
    }, (qn.prototype = new Ae).__c = function(e, t) {
        var n = t.__c,
            r = this;
        r.t == null && (r.t = []), r.t.push(n);
        var i = $l(r.__v),
            o = !1,
            a = function() {
                o || (o = !0, n.__R = null, i ? i(s) : s())
            };
        n.__R = a;
        var s = function() {
                if (!--r.__u) {
                    if (r.state.__a) {
                        var u = r.state.__a;
                        r.__v.__k[0] = Kl(u, u.__c.__P, u.__c.__O)
                    }
                    var c;
                    for (r.setState({
                            __a: r.__b = null
                        }); c = r.t.pop();) c.forceUpdate()
                }
            },
            l = t.__h === !0;
        r.__u++ || l || r.setState({
            __a: r.__b = r.__v.__k[0]
        }), e.then(a, a)
    }, qn.prototype.componentWillUnmount = function() {
        this.t = []
    }, qn.prototype.render = function(e, t) {
        if (this.__b) {
            if (this.__v.__k) {
                var n = document.createElement("div"),
                    r = this.__v.__k[0].__c;
                this.__v.__k[0] = Hl(this.__b, n, r.__O = r.__P)
            }
            this.__b = null
        }
        var i = t.__a && te(Re, null, e.fallback);
        return i && (i.__h = null), [te(Re, null, t.__a ? null : e.children), i]
    };
    var ql = function(e, t, n) {
        if (++n[1] === n[0] && e.o.delete(t), e.props.revealOrder && (e.props.revealOrder[0] !== "t" || !e.o.size))
            for (n = e.u; n;) {
                for (; n.length > 3;) n.pop()();
                if (n[1] < n[0]) break;
                e.u = n = n[2]
            }
    };

    function qh(e) {
        return this.getChildContext = function() {
            return e.context
        }, e.children
    }

    function zh(e) {
        var t = this,
            n = e.i;
        t.componentWillUnmount = function() {
            un(null, t.l), t.l = null, t.i = null
        }, t.i && t.i !== n && t.componentWillUnmount(), e.__v ? (t.l || (t.i = n, t.l = {
            nodeType: 1,
            parentNode: n,
            childNodes: [],
            appendChild: function(r) {
                this.childNodes.push(r), t.i.appendChild(r)
            },
            insertBefore: function(r, i) {
                this.childNodes.push(r), t.i.appendChild(r)
            },
            removeChild: function(r) {
                this.childNodes.splice(this.childNodes.indexOf(r) >>> 1, 1), t.i.removeChild(r)
            }
        }), un(te(qh, {
            context: t.context
        }, e.__v), t.l)) : t.l && t.componentWillUnmount()
    }

    function zl(e, t) {
        var n = te(zh, {
            __v: e,
            i: t
        });
        return n.containerInfo = t, n
    }(fn.prototype = new Ae).__a = function(e) {
        var t = this,
            n = $l(t.__v),
            r = t.o.get(e);
        return r[0]++,
            function(i) {
                var o = function() {
                    t.props.revealOrder ? (r.push(i), ql(t, e, r)) : i()
                };
                n ? n(o) : o()
            }
    }, fn.prototype.render = function(e) {
        this.u = null, this.o = new Map;
        var t = at(e.children);
        e.revealOrder && e.revealOrder[0] === "b" && t.reverse();
        for (var n = t.length; n--;) this.o.set(t[n], this.u = [1, 0, this.u]);
        return e.children
    }, fn.prototype.componentDidUpdate = fn.prototype.componentDidMount = function() {
        var e = this;
        this.o.forEach(function(t, n) {
            ql(e, n, t)
        })
    };
    var Wl = typeof Symbol < "u" && Symbol.for && Symbol.for("react.element") || 60103,
        Wh = /^(?:accent|alignment|arabic|baseline|cap|clip(?!PathU)|color|dominant|fill|flood|font|glyph(?!R)|horiz|image|letter|lighting|marker(?!H|W|U)|overline|paint|pointer|shape|stop|strikethrough|stroke|text(?!L)|transform|underline|unicode|units|v|vector|vert|word|writing|x(?!C))[A-Z]/,
        Yh = typeof document < "u",
        Qh = function(e) {
            return (typeof Symbol < "u" && typeof Symbol() == "symbol" ? /fil|che|rad/i : /fil|che|ra/i).test(e)
        };

    function Yl(e, t, n) {
        return t.__k == null && (t.textContent = ""), un(e, t), typeof n == "function" && n(), e ? e.__c : null
    }

    function Ql(e, t, n) {
        return yl(e, t), typeof n == "function" && n(), e ? e.__c : null
    }
    Ae.prototype.isReactComponent = {}, ["componentWillMount", "componentWillReceiveProps", "componentWillUpdate"].forEach(function(e) {
        Object.defineProperty(Ae.prototype, e, {
            configurable: !0,
            get: function() {
                return this["UNSAFE_" + e]
            },
            set: function(t) {
                Object.defineProperty(this, e, {
                    configurable: !0,
                    writable: !0,
                    value: t
                })
            }
        })
    });
    var Zl = P.event;

    function Zh() {}

    function Xh() {
        return this.cancelBubble
    }

    function Jh() {
        return this.defaultPrevented
    }
    P.event = function(e) {
        return Zl && (e = Zl(e)), e.persist = Zh, e.isPropagationStopped = Xh, e.isDefaultPrevented = Jh, e.nativeEvent = e
    };
    var Xl, Jl = {
            configurable: !0,
            get: function() {
                return this.class
            }
        },
        eu = P.vnode;
    P.vnode = function(e) {
        var t = e.type,
            n = e.props,
            r = n;
        if (typeof t == "string") {
            var i = t.indexOf("-") === -1;
            for (var o in r = {}, n) {
                var a = n[o];
                Yh && o === "children" && t === "noscript" || o === "value" && "defaultValue" in n && a == null || (o === "defaultValue" && "value" in n && n.value == null ? o = "value" : o === "download" && a === !0 ? a = "" : /ondoubleclick/i.test(o) ? o = "ondblclick" : /^onchange(textarea|input)/i.test(o + t) && !Qh(n.type) ? o = "oninput" : /^onfocus$/i.test(o) ? o = "onfocusin" : /^onblur$/i.test(o) ? o = "onfocusout" : /^on(Ani|Tra|Tou|BeforeInp|Compo)/.test(o) ? o = o.toLowerCase() : i && Wh.test(o) ? o = o.replace(/[A-Z0-9]/g, "-$&").toLowerCase() : a === null && (a = void 0), /^oninput$/i.test(o) && (o = o.toLowerCase(), r[o] && (o = "oninputCapture")), r[o] = a)
            }
            t == "select" && r.multiple && Array.isArray(r.value) && (r.value = at(n.children).forEach(function(s) {
                s.props.selected = r.value.indexOf(s.props.value) != -1
            })), t == "select" && r.defaultValue != null && (r.value = at(n.children).forEach(function(s) {
                s.props.selected = r.multiple ? r.defaultValue.indexOf(s.props.value) != -1 : r.defaultValue == s.props.value
            })), e.props = r, n.class != n.className && (Jl.enumerable = "className" in n, n.className != null && (r.class = n.className), Object.defineProperty(r, "className", Jl))
        }
        e.$$typeof = Wl, eu && eu(e)
    };
    var tu = P.__r;
    P.__r = function(e) {
        tu && tu(e), Xl = e.__c
    };
    var nu = {
            ReactCurrentDispatcher: {
                current: {
                    readContext: function(e) {
                        return Xl.__n[e.__c].props.value
                    }
                }
            }
        },
        ev = "17.0.2";

    function ru(e) {
        return te.bind(null, e)
    }

    function No(e) {
        return !!e && e.$$typeof === Wl
    }

    function iu(e) {
        return No(e) ? Vh.apply(null, arguments) : e
    }

    function ou(e) {
        return !!e.__k && (un(null, e), !0)
    }

    function au(e) {
        return e && (e.base || e.nodeType === 1 && e) || null
    }
    var su = function(e, t) {
            return e(t)
        },
        lu = function(e, t) {
            return e(t)
        },
        uu = Re;

    function Mo(e) {
        e()
    }

    function cu(e) {
        return e
    }

    function du() {
        return [!1, Mo]
    }
    var fu = Gn;

    function pu(e, t) {
        var n = t(),
            r = ue({
                h: {
                    __: n,
                    v: t
                }
            }),
            i = r[0].h,
            o = r[1];
        return Gn(function() {
            i.__ = n, i.v = t, Po(i.__, t()) || o({
                h: i
            })
        }, [e, n, t]), Ie(function() {
            return Po(i.__, i.v()) || o({
                h: i
            }), e(function() {
                Po(i.__, i.v()) || o({
                    h: i
                })
            })
        }, [e]), n
    }
    var tv = {
        useState: ue,
        useId: Ol,
        useReducer: Ro,
        useEffect: Ie,
        useLayoutEffect: Gn,
        useInsertionEffect: fu,
        useTransition: du,
        useDeferredValue: cu,
        useSyncExternalStore: pu,
        startTransition: Mo,
        useRef: _t,
        useImperativeHandle: Ll,
        useMemo: Hr,
        useCallback: Rl,
        useContext: Al,
        useDebugValue: Ao,
        version: "17.0.2",
        Children: Fl,
        render: Yl,
        hydrate: Ql,
        unmountComponentAtNode: ou,
        createPortal: zl,
        createElement: te,
        createContext: wl,
        createFactory: ru,
        cloneElement: iu,
        createRef: sl,
        Fragment: Re,
        isValidElement: No,
        findDOMNode: au,
        Component: Ae,
        PureComponent: $r,
        memo: Nl,
        forwardRef: jl,
        flushSync: lu,
        unstable_batchedUpdates: su,
        StrictMode: uu,
        Suspense: qn,
        SuspenseList: fn,
        lazy: Gl,
        __SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED: nu
    };
    const nv = Object.freeze(Object.defineProperty({
        __proto__: null,
        Children: Fl,
        PureComponent: $r,
        StrictMode: uu,
        Suspense: qn,
        SuspenseList: fn,
        __SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED: nu,
        cloneElement: iu,
        createFactory: ru,
        createPortal: zl,
        default: tv,
        findDOMNode: au,
        flushSync: lu,
        forwardRef: jl,
        hydrate: Ql,
        isValidElement: No,
        lazy: Gl,
        memo: Nl,
        render: Yl,
        startTransition: Mo,
        unmountComponentAtNode: ou,
        unstable_batchedUpdates: su,
        useDeferredValue: cu,
        useInsertionEffect: fu,
        useSyncExternalStore: pu,
        useTransition: du,
        version: ev,
        Component: Ae,
        Fragment: Re,
        createContext: wl,
        createElement: te,
        createRef: sl,
        useCallback: Rl,
        useContext: Al,
        useDebugValue: Ao,
        useEffect: Ie,
        useErrorBoundary: Bh,
        useId: Ol,
        useImperativeHandle: Ll,
        useLayoutEffect: Gn,
        useMemo: Hr,
        useReducer: Ro,
        useRef: _t,
        useState: ue
    }, Symbol.toStringTag, {
        value: "Module"
    }));
    var hu = {
            exports: {}
        },
        vu = {};
    const mu = St(nv);
    var gu = {
            exports: {}
        },
        _u = {};
    /**
     * @license React
     * use-sync-external-store-shim.production.min.js
     *
     * Copyright (c) Facebook, Inc. and its affiliates.
     *
     * This source code is licensed under the MIT license found in the
     * LICENSE file in the root directory of this source tree.
     */
    var pn = mu;

    function rv(e, t) {
        return e === t && (e !== 0 || 1 / e === 1 / t) || e !== e && t !== t
    }
    var iv = typeof Object.is == "function" ? Object.is : rv,
        ov = pn.useState,
        av = pn.useEffect,
        sv = pn.useLayoutEffect,
        lv = pn.useDebugValue;

    function uv(e, t) {
        var n = t(),
            r = ov({
                inst: {
                    value: n,
                    getSnapshot: t
                }
            }),
            i = r[0].inst,
            o = r[1];
        return sv(function() {
            i.value = n, i.getSnapshot = t, jo(i) && o({
                inst: i
            })
        }, [e, n, t]), av(function() {
            return jo(i) && o({
                inst: i
            }), e(function() {
                jo(i) && o({
                    inst: i
                })
            })
        }, [e]), lv(n), n
    }

    function jo(e) {
        var t = e.getSnapshot;
        e = e.value;
        try {
            var n = t();
            return !iv(e, n)
        } catch {
            return !0
        }
    }

    function cv(e, t) {
        return t()
    }
    var dv = typeof window > "u" || typeof window.document > "u" || typeof window.document.createElement > "u" ? cv : uv;
    _u.useSyncExternalStore = pn.useSyncExternalStore !== void 0 ? pn.useSyncExternalStore : dv,
        function(e) {
            e.exports = _u
        }(gu);
    /**
     * @license React
     * use-sync-external-store-shim/with-selector.production.min.js
     *
     * Copyright (c) Facebook, Inc. and its affiliates.
     *
     * This source code is licensed under the MIT license found in the
     * LICENSE file in the root directory of this source tree.
     */
    var Gr = mu,
        fv = gu.exports;

    function pv(e, t) {
        return e === t && (e !== 0 || 1 / e === 1 / t) || e !== e && t !== t
    }
    var hv = typeof Object.is == "function" ? Object.is : pv,
        vv = fv.useSyncExternalStore,
        mv = Gr.useRef,
        gv = Gr.useEffect,
        _v = Gr.useMemo,
        yv = Gr.useDebugValue;
    vu.useSyncExternalStoreWithSelector = function(e, t, n, r, i) {
            var o = mv(null);
            if (o.current === null) {
                var a = {
                    hasValue: !1,
                    value: null
                };
                o.current = a
            } else a = o.current;
            o = _v(function() {
                function l(p) {
                    if (!u) {
                        if (u = !0, c = p, p = r(p), i !== void 0 && a.hasValue) {
                            var h = a.value;
                            if (i(h, p)) return f = h
                        }
                        return f = p
                    }
                    if (h = f, hv(c, p)) return h;
                    var v = r(p);
                    return i !== void 0 && i(h, v) ? h : (c = p, f = v)
                }
                var u = !1,
                    c, f, d = n === void 0 ? null : n;
                return [function() {
                    return l(t())
                }, d === null ? void 0 : function() {
                    return l(d())
                }]
            }, [t, n, r, i]);
            var s = vv(e, o[0], o[1]);
            return gv(function() {
                a.hasValue = !0, a.value = s
            }, [s]), yv(s), s
        },
        function(e) {
            e.exports = vu
        }(hu);
    const wv = We(hu.exports),
        {
            useSyncExternalStoreWithSelector: bv
        } = wv;

    function Ev(e, t = e.getState, n) {
        const r = bv(e.subscribe, e.getState, e.getServerState || e.getState, t, n);
        return Ao(r), r
    }
    const yu = e => {
            const t = typeof e == "function" ? Fh(e) : e,
                n = (r, i) => Ev(t, r, i);
            return Object.assign(n, t), n
        },
        wu = e => e ? yu(e) : yu;
    var Vo = (e => (e[e.And = 1] = "And", e[e.Or = 2] = "Or", e))(Vo || {});
    const bu = 1,
        Fo = {
            eq(e, t) {
                return e == t
            },
            neq(e, t) {
                return !this.eq(e, t)
            },
            gt(e, t) {
                return e > t
            },
            gte(e, t) {
                return e >= t
            },
            lt(e, t) {
                return e < t
            },
            lte(e, t) {
                return e <= t
            },
            list_exact(e, t) {
                return !Array.isArray(e) || !Array.isArray(t) ? !1 : e.slice().sort().join(",") === t.slice().sort().join(",")
            },
            list_all(e, t) {
                return !Array.isArray(e) || !Array.isArray(t) ? !1 : !t.some(n => e.indexOf(n) === -1)
            },
            list_alo(e, t) {
                if (!Array.isArray(t)) return !1;
                const n = Array.isArray(e) ? e : [e],
                    r = new Set(n);
                return t.some(i => r.has(i))
            },
            list_dni(e, t) {
                if (!Array.isArray(t)) return !1;
                const n = Array.isArray(e) ? e : [e],
                    r = new Set(n);
                return t.every(i => !r.has(i))
            },
            contains(e, t) {
                const n = e.toLowerCase(),
                    r = t.toLowerCase();
                return n.includes(r)
            },
            notcontains(e, t) {
                return !this.contains(e, t)
            }
        },
        xv = (e, t, n) => {
            switch (t) {
                case R.VideoVoice:
                    return Boolean(e && e.value);
                case R.Open:
                    return !!n;
                case R.MultipleSelect:
                    return Boolean(n && !!Object.keys(n).length);
                case R.RecordedTask:
                    return (n == null ? void 0 : n.taskStatus) === Se.Completed;
                case R.TextUrlPrompt:
                    return !e.value;
                case R.ConsentLegal:
                    return n !== null;
                case R.MultipleChoice:
                    return n !== void 0;
                case R.NPS:
                    return n !== null;
                case R.Likert:
                    return n !== null;
                default:
                    return !0
            }
        },
        Eu = ({
            cards: e,
            index: t,
            hasEndCard: n,
            allResponses: r,
            uploadProgress: i = {}
        }) => {
            if (t >= e.length || t < 0) return null;
            const o = e[t];
            let a = t + 1;
            const s = o.props.routingOptions || [];
            for (let c = 0; c < s.length; c++) {
                const {
                    group: f,
                    target: d
                } = s[c];
                if (!(f != null && f.length)) continue;
                const p = f[0];
                if (p.questionIndex === void 0 || p.questionIndex > r.length) continue;
                let h = xu({
                    comparator: p.comparator,
                    response: r[p.questionIndex],
                    type: o.type,
                    value: p.value
                });
                for (let v = 1; v < f.length; v += 2) {
                    const m = f[v],
                        y = f[v + 1],
                        _ = xu({
                            comparator: y.comparator,
                            response: r[y.questionIndex],
                            type: e[y.questionIndex].type,
                            value: y.value
                        });
                    m === Vo.And ? h && (h = _) : m === Vo.Or && (h || (h = _))
                }
                if (h) {
                    a = d === -1 && n ? e.length - 1 : d;
                    break
                }
            }
            const l = e.findIndex(c => c.type === R.Uploading);
            let u;
            return l > 0 ? u = n ? e.length - 3 : e.length - 2 : u = e.length - 1, t >= u || a === -1 || a !== null && a > u ? l > 0 && Object.values(i).some(f => f.isSubmitted && !f.isComplete) ? l : n ? e.length - 1 : null : a === -1 ? null : a
        },
        xu = ({
            comparator: e,
            response: t,
            type: n,
            value: r
        }) => {
            if (e === st.Answered) switch (n) {
                case R.TextUrlPrompt:
                    return t === void 0;
                case R.ConsentLegal:
                    return t && t.submitted === !0;
                case R.RecordedTask:
                    return "taskStatus" in t && t.taskStatus === Se.Completed;
                case R.Likert:
                    return Number.isInteger(t);
                case R.Open:
                    return t && t.length > 0;
                case R.MultipleChoice:
                case R.MultipleSelect:
                    return Object.keys(t).length > 0;
                case R.NPS:
                    return Number.isInteger(t);
                case R.VideoVoice:
                    return !!(t != null && t.mediaRecordingUid);
                default:
                    return !1
            }
            if (e === st.Skipped) switch (n) {
                case R.TextUrlPrompt:
                    return t == null ? void 0 : t.skipped;
                case R.ConsentLegal:
                    return t === null;
                case R.RecordedTask:
                    return "taskStatus" in t && t.taskStatus === Se.Abandoned;
                case R.Likert:
                    return t === null;
                case R.Open:
                    return (t == null ? void 0 : t.length) === 0;
                case R.MultipleChoice:
                    return t === void 0;
                case R.MultipleSelect:
                    return (t == null ? void 0 : t.length) === 0;
                case R.NPS:
                    return t === null;
                case R.VideoVoice:
                    return t === null;
                default:
                    return !1
            }
            return e === st.GivenUp ? n === R.RecordedTask ? "taskStatus" in t && t.taskStatus === Se.GivenUp : !0 : Fo[e](t, r)
        },
        Cv = 13,
        Sv = (e, t) => e.reduce((n, r) => n.concat(n.map(i => [...i, r])), [
            []
        ]).filter(n => t || n.length > 0),
        Iv = e => {
            var t, n;
            switch (e.type) {
                case R.MultipleSelect:
                    return !e || !e.props || !e.props.options ? null : e.props.options.length > Cv ? e.props.options.map(r => [r.value]) : Sv(e.props.options.map(r => r.value), !e.props.properties.required);
                case R.MultipleChoice:
                    {
                        if (!e || !e.props || !e.props.options) return null;
                        const r = e.props.options.map(i => i.value);
                        return e.props.properties.required || r.push(void 0),
                        r
                    }
                case R.Likert:
                    {
                        const r = Number((n = (t = e.props) == null ? void 0 : t.properties) == null ? void 0 : n.range) || 5;
                        return [...Array.from(Array(r).keys()).map(o => o + 1), ...e.props.properties.required ? [] : [null]]
                    }
                case R.NPS:
                    return [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, ...e.props.properties.required ? [] : [null]];
                case R.VideoVoice:
                case R.Open:
                    return ["1", ...e.props.properties.required ? [] : [""]];
                case R.RecordedTask:
                    return [{
                        taskStatus: Se.Completed
                    }, {
                        taskStatus: Se.GivenUp
                    }, ...e.props.properties.required ? [] : [{
                        taskStatus: Se.Abandoned
                    }]];
                case R.TextUrlPrompt:
                    return [void 0, ...e.props.properties.required ? [] : [{
                        skipped: !0
                    }]];
                case R.ConsentLegal:
                    return [bu, ...e.props.properties.required ? [] : [null]];
                default:
                    return [bu]
            }
        },
        kv = e => e in Fo,
        Tv = e => typeof e == "object" && e !== null && "taskStatus" in e,
        Lv = (e, t = []) => t.reduce((n, r) => {
            const {
                group: i,
                target: o
            } = r;
            if (!(i != null && i.length)) return [...n];
            const a = i.filter(s => Number(s) ? !0 : typeof s == "object" ? s.questionIndex === e : !1).map(s => {
                const {
                    comparator: l,
                    value: u
                } = s;
                return {
                    comparator: l,
                    target: o,
                    value: u
                }
            });
            return [...n, ...a]
        }, []),
        Rv = (e, t) => {
            const n = new Set([R.Thanks, R.Uploading]);
            if (t >= e.length || t < 0 || n.has(e[t].type)) return 0;
            const r = e.filter(o => !n.has(o.type));
            if (t === r.length - 1) return 1;
            const i = {
                [r.length - 1]: 1,
                [-1]: 0
            };
            for (let o = r.length - 2; o >= t; o--) {
                const a = r[o],
                    s = Lv(o, a.props.routingOptions);
                if (s.length === 0) {
                    i[o] = i[o + 1] + 1;
                    continue
                }
                let l = 0,
                    u = Iv(a);
                if (u === null) return r.length - 1 - t;
                for (let c = 0; c < s.length && u.length !== 0; c++) {
                    const {
                        comparator: f,
                        target: d,
                        value: p
                    } = s[c], h = u.filter(v => {
                        const m = xv({
                            value: v
                        }, a.type, v);
                        return !(m && f === st.Answered || !m && f === st.Skipped || f === st.GivenUp && Tv(v) && v.taskStatus === Se.GivenUp || m && a.type === R.Open && (f === st.Contains || f === st.DoesNotContain) || m && kv(f) && Fo[f](v, p))
                    });
                    if (h.length < u.length) {
                        const v = parseInt(String(d), 10);
                        if (v !== -1 && v <= o || v >= r.length) return r.length - 1 - t;
                        l = Math.max(i[v] + 1, l)
                    }
                    u = h
                }
                u.length > 0 && (l = Math.max(i[o + 1] + 1, l)), i[o] = l
            }
            return i[t]
        },
        Av = e => !(e.type === R.Thanks || e.type === R.Uploading),
        ee = wu()((e, t) => ({
            allResponses: [],
            answers: void 0,
            apiURL: "",
            border: "#000000",
            cards: [],
            close: async (n = Wt) => {
                const r = t(),
                    {
                        fadeout: i,
                        remove: o,
                        trackHistory: a
                    } = r;
                await i(n), Bo(r) || a({
                    event: "closed"
                }), Si.enable(), o({
                    initiator: Ye.Closed
                })
            },
            configureExitOnOverlayClick: () => {},
            customMetadata: {},
            destroy: async n => {
                const {
                    eventEmitFn: r,
                    fadeout: i,
                    remove: o
                } = t();
                r(xe.SurveyComplete), await i(n), Si.enable(), o({
                    initiator: Ye.Complete
                })
            },
            endCard: {
                headline: ""
            },
            envId: "",
            eventEmitFn: q.emit.bind(q),
            fadeout: async n => {
                const {
                    eventEmitFn: r,
                    headers: i,
                    viewDocument: o
                } = t();
                return Qt(i) ? Promise.resolve() : (r(K.SurveyFadingOut), new Promise(a => {
                    const s = o.getElementById(n);
                    s ? (s.addEventListener("transitionend", () => {
                        a()
                    }), s.classList.remove("ul-app--visible")) : a()
                }))
            },
            frame: document.createElement("iframe"),
            handleClickEmbedButton: n => {
                const {
                    cards: r,
                    eventEmitFn: i,
                    index: o
                } = t();
                i(n, {
                    [kt.QuestionId]: r[o].name,
                    [kt.Props]: r[o].props
                }), e(() => ({
                    hasViewedEmbed: !0
                }))
            },
            handleUploadUpdate: ({
                mediaRecordingUid: n,
                isComplete: r,
                progressPct: i,
                isSubmitted: o
            }) => {
                var d, p, h;
                const {
                    cards: a,
                    destroy: s,
                    index: l,
                    uploadProgress: u
                } = t(), c = { ...u,
                    [n]: {
                        progressPct: i || i === 0 ? i : (d = u[n]) == null ? void 0 : d.progressPct,
                        isComplete: r || ((p = u[n]) == null ? void 0 : p.isComplete),
                        isSubmitted: o || ((h = u[n]) == null ? void 0 : h.isSubmitted)
                    }
                };
                if (a[l].type !== R.Uploading) {
                    e({
                        uploadProgress: c
                    });
                    return
                }
                const f = Object.entries(u).every(([v, m]) => !m.isSubmitted || m.isComplete || n == v && r);
                if (f && l >= a.length - 1) {
                    s(Wt);
                    return
                }
                e({
                    index: f ? l + 1 : l,
                    uploadingCardViewed: !0,
                    uploadProgress: c
                })
            },
            hasViewedEmbed: !1,
            headers: {
                Authorization: "",
                "Content-Type": "",
                "userleap-platform": Tt.Web,
                "x-ul-environment-id": "",
                "x-ul-installation-method": Lt.Snippet,
                "x-ul-sdk-version": "",
                "x-ul-visitor-id": ""
            },
            index: 0,
            isPreview: !1,
            marketingUrl: "https://sprig.com",
            meta: {
                ch: 0,
                cw: 0,
                l: "",
                mode: null,
                p: "",
                sh: 0,
                sw: 0
            },
            mode: void 0,
            next: n => {
                const {
                    allResponses: r,
                    cards: i,
                    eventEmitFn: o,
                    index: a,
                    responseGroupUid: s,
                    submit: l,
                    trackHistory: u,
                    uploadProgress: c,
                    viewedCardCount: f
                } = t(), d = Date.now(), p = [...i], h = p[a], {
                    type: v
                } = n.data, m = { ...n.data
                }, y = m.value;
                Av(h) && (h.value = y), m.answeredAt = d, delete m.type;
                const _ = {
                    response: m,
                    responseGroupUid: s
                };
                let E = v === R.MultipleChoice ? Object.values(y).find(I => I !== !1) : y;
                v === R.MultipleSelect && (E = p[a].props.options.reduce((I, k) => (y[k.id] && I.push(k.value), I), []));
                const b = r.slice(0);
                b[a] = E, e({
                    allResponses: b
                });
                const w = Eu({
                    cards: p,
                    index: a,
                    hasEndCard: !!n.endCard,
                    uploadProgress: c,
                    allResponses: b
                });
                if (w === null) {
                    _.completedAt = d, l(_), n.completeSurvey();
                    return
                } else [R.Thanks, R.Uploading].includes(p[w].type) && (_.completedAt = d);
                const x = l(_);
                [R.Thanks, R.Uploading].includes(p[w].type) || x.finally(() => {
                    u({
                        event: "seen",
                        index: w
                    })
                });
                const C = p[w];
                p[w] && o && o(xe.CurrentQuestion, {
                    [kt.QuestionId]: C.name,
                    [kt.Props]: C.props
                }), e({
                    cards: p,
                    hasViewedEmbed: !1,
                    index: w,
                    viewedCardCount: f + 1
                })
            },
            previewKey: null,
            recorder: () => {},
            recorderEventEmitter: q,
            responseGroupUid: "",
            remove: ({
                initiator: n
            }) => {
                const {
                    frame: r,
                    headers: i,
                    eventEmitFn: o
                } = t();
                ["ios", "android"].includes(i["userleap-platform"]) && o(K.SurveyWillClose, {
                    name: K.SurveyWillClose,
                    initiator: n
                }), !Qt(i) && (o(K.SurveyWillClose, {
                    name: K.SurveyWillClose,
                    initiator: n
                }), r.remove())
            },
            seen: async () => {
                const {
                    trackHistory: n
                } = t();
                return n({
                    event: "seen",
                    isNew: !0
                })
            },
            slugName: null,
            showStripes: !1,
            showSurveyBrand: !1,
            styleNonce: "",
            submit: async ({
                completedAt: n,
                response: r,
                responseGroupUid: i
            }) => {
                const o = t();
                if (!i || Bo(o)) return;
                const a = {
                        responseGroupUid: i,
                        meta: o.meta,
                        customMetadata: o.customMetadata,
                        responses: [r],
                        completedAt: n,
                        previewKey: o.previewKey
                    },
                    s = await je(`${o.apiURL}/sdk/1/environments/${o.envId}/visitors/${o.userId}/responses/submit`, {
                        body: JSON.stringify(a),
                        headers: o.headers,
                        method: "POST"
                    });
                if (!s.ok) {
                    s.reportError && (console.warn("[Sprig] (ERR-427) Failed to submit response", s.error), await Cu(o, "submitResponse", s.error));
                    return
                }
            },
            surveyId: 0,
            tabTitle: "",
            trackHistory: async ({
                event: n,
                index: r,
                isNew: i = !1
            }) => {
                const o = t();
                if (Bo(o)) return;
                const {
                    cards: a,
                    index: s
                } = o, l = r !== void 0 ? a[r] : a[s], u = {
                    sid: o.surveyId,
                    qid: l.name,
                    action: n,
                    vid: o.userId,
                    eid: o.envId,
                    isNew: i,
                    responseGroupUid: o.responseGroupUid,
                    previewKey: o.previewKey
                }, c = await je(`${o.apiURL}/sdk/1/visitors/${o.userId}/surveys/${o.surveyId}/history`, {
                    body: JSON.stringify(u),
                    headers: o.headers,
                    method: "POST"
                });
                !c.ok && c.reportError && (console.warn("[Sprig] (ERR-428) Failed to track survey event", c.error), await Cu(o, "trackHistory", c.error))
            },
            update: () => {
                const {
                    headers: n,
                    eventEmitFn: r,
                    frame: i,
                    viewDocument: o
                } = t();
                setTimeout(() => {
                    var s;
                    const a = qa(o);
                    Qt(n) ? r(K.SurveyHeight, {
                        name: K.SurveyHeight,
                        contentFrameHeight: a
                    }) : (s = i.setHeight) == null || s.call(i, a)
                }, 100)
            },
            uploadingCardViewed: !1,
            uploadProgress: {},
            useDesktopPrototype: void 0,
            useMobileStyling: !1,
            userId: "",
            viewDocument: window.document,
            viewedCardCount: 0
        })),
        Bo = e => !e.userId || e.meta && e.meta.mode === "test" || e.isPreview,
        Cu = async (e, t, n) => {
            const {
                mode: r,
                userId: i,
                envId: o,
                apiURL: a,
                headers: s,
                viewDocument: l
            } = e, u = l.documentElement, c = {
                mode: r,
                screenWidth: window.screen.width,
                screenHeight: window.screen.height,
                clientWidth: u.clientWidth,
                clientHeight: u.clientHeight,
                location: window.location.href,
                language: window.navigator.language
            }, f = {
                action: t,
                err: {
                    message: n == null ? void 0 : n.message,
                    stack: n == null ? void 0 : n.stack
                },
                meta: c,
                vid: i,
                envId: o
            };
            (await je(`${a}/sdk/1/errors`, {
                method: "POST",
                headers: Object.assign({
                    "x-ul-error": window.btoa(`userleap-${Date.now()}-error`)
                }, s),
                body: JSON.stringify(f)
            })).ok || console.warn("[Sprig] (ERR-444) Failed to report error to API", n)
        },
        Ov = async (e, t) => {
            var r;
            const n = await fetch(t, {
                method: "POST",
                cache: "no-cache",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify(e)
            });
            if (n.ok) {
                const i = await n.json();
                return (r = i == null ? void 0 : i.upload) == null ? void 0 : r.url
            } else return null
        },
        Su = () => MediaRecorder.isTypeSupported("video/webm") ? "video/webm" : "video/mp4",
        Iu = e => {
            const t = {
                audioBitsPerSecond: 128e3,
                videoBitsPerSecond: 25e5,
                mimeType: Su()
            };
            return new MediaRecorder(e, t)
        },
        ku = (e, t, n) => {
            n[t] = [], e.ondataavailable = function(r) {
                n[t].push(r.data)
            }, e.currentMediaRecordingUid = t, e.start()
        };

    function Tu(e, t, n, r, i, o) {
        if (e && e.state !== "inactive") {
            const {
                [G.BeginCallback]: a
            } = r, s = e.currentMediaRecordingUid;
            if (!s) return;
            a && a(s), e.onstop = () => Dv(t, e, n, r, s, i, o), e.stop()
        }
    }
    async function Dv(e, t, n, r, i, o, a) {
        const s = ee.getState().viewDocument,
            {
                [G.UploadCallback]: l,
                [G.ProgressCallback]: u
            } = r,
            c = {
                mediaType: n,
                updatedAt: new Date().toISOString(),
                mediaRecordingUid: i,
                ...r[G.PassthroughData]
            },
            f = await Ov(c, e);
        if (!f) {
            l && l(null, {
                message: "failed to get upload url"
            });
            return
        }
        const d = new Blob(a, {
            type: Su()
        });
        if (!s.defaultView) return;
        const p = new s.defaultView.File([d], `recording video ${Date.now()}`),
            h = o.createUpload({
                endpoint: f,
                file: p,
                chunkSize: 5120
            });
        h.startTime = Date.now(), h.on("error", v => {
            l && l(null, v)
        }), h.on("progress", v => {
            u && u(i, v)
        }), h.on("success", () => {
            l && l(i, !0)
        })
    }
    const Uv = {
            state: { ...{
                    chunks: {}
                }
            },
            stopRecording(e) {
                const {
                    uploadApiEndpoint: t,
                    avRecorder: n,
                    screenRecorder: r,
                    UpChunk: i
                } = this.state, o = this.state.avStream && this.state.avStream.getVideoTracks().length > 0 ? Oe.Video : Oe.Audio;
                this.state.chunks && t && i && (n != null && n.currentMediaRecordingUid && Tu(n, t, o, e, i, this.state.chunks[n == null ? void 0 : n.currentMediaRecordingUid]), r != null && r.currentMediaRecordingUid && Tu(r, t, Oe.Screen, e, i, this.state.chunks[r == null ? void 0 : r.currentMediaRecordingUid]))
            },
            handleCancelledStream(e) {
                const t = e.getVideoTracks(),
                    n = e.getAudioTracks();
                let r = t.length && t[0];
                r = r || n.length && n[0], r && r.addEventListener("ended", () => {
                    [this.state.avRecorder, this.state.screenRecorder].map(i => {
                        i && (i.state === "recording" && i.stop(), i.stream.getTracks().map(o => {
                            o.readyState === "live" && o.stop()
                        }))
                    }), Object.assign(this.state, {
                        avStream: null,
                        captureStream: null,
                        avRecorder: null,
                        screenRecorder: null
                    })
                })
            },
            taskDurationMillisecond() {
                return this.state.startTime ? new Date().getTime() - this.state.startTime.getTime() : 0
            },
            setUpChunk(e) {
                this.state.UpChunk = e
            },
            configure(e, t) {
                Object.assign(this.state, t), this.state.uploadApiEndpoint = `${t.apiURL}/2/environments/integrations/upload`, this.state.chunks = {}, e.on(fe.PermissionStatus, this.permissionStatusCallback.bind(this)), e.on(fe.AvPermission, async n => {
                    this.avPermissionCallback(n)
                }), e.on(fe.BeginRecording, this.beginRecordingCallback.bind(this)), e.on(fe.StartTask, this.startTaskCallback.bind(this)), e.on(fe.ScreenPermission, async n => {
                    this.screenPermissionCallback(n)
                }), e.on(fe.FinishTask, async n => {
                    this.finishTaskCallback(n)
                })
            },
            async avPermissionCallback(e) {
                var r, i, o;
                const {
                    [G.StreamReadyCallback]: t, [G.PermissionDescriptors]: n
                } = e;
                try {
                    (r = this.state.avStream) != null && r.active && (this.state.avStream.getTracks().map(a => a.readyState === "live" && a.stop()), ((i = this.state.captureStream) == null ? void 0 : i.getAudioTracks().length) === 1 && this.state.captureStream.removeTrack(this.state.captureStream.getAudioTracks()[0])), this.state.avStream = await navigator.mediaDevices.getUserMedia({
                        video: n.includes(cn.Camera),
                        audio: !0
                    }), ((o = this.state.captureStream) == null ? void 0 : o.getAudioTracks().length) === 0 && this.state.captureStream.addTrack(this.state.avStream.getAudioTracks()[0]), this.handleCancelledStream(this.state.avStream)
                } catch (a) {
                    console.warn("Error: failed to get permissions: " + a), t && t(null, null);
                    return
                }
                t && t(this.state.avStream, this.state.captureStream)
            },
            async screenPermissionCallback(e) {
                const {
                    [G.ScreenPermissionRequested]: t, [G.StreamReadyCallback]: n
                } = e;
                t == null || t(!0);
                try {
                    this.state.captureStream = await navigator.mediaDevices.getDisplayMedia({
                        video: !0,
                        cursor: "always",
                        displaySurface: "browser",
                        preferCurrentTab: !0
                    })
                } catch (r) {
                    t == null || t(!1), console.warn("Error: failed to get permissions: " + r), n && n(null, null);
                    return
                }
                t == null || t(!1), this.state.avStream && this.state.avStream.getAudioTracks().length > 0 && this.state.captureStream.addTrack(this.state.avStream.getAudioTracks()[0]), this.handleCancelledStream(this.state.captureStream), n && n(this.state.avStream || null, this.state.captureStream)
            },
            beginRecordingCallback(e) {
                const {
                    [G.RecordingMediaTypes]: t, [G.StartRecordingCallback]: n
                } = e;
                if (!t) return;
                const r = [];
                if (t.includes(Oe.Video) && this.state.avStream) {
                    this.state.avRecorder = Iu(this.state.avStream);
                    const i = ct();
                    ku(this.state.avRecorder, i, this.state.chunks), r.push(i)
                }
                if (t.includes(Oe.Screen) && this.state.captureStream) {
                    this.state.screenRecorder = Iu(this.state.captureStream);
                    const i = ct();
                    ku(this.state.screenRecorder, i, this.state.chunks), r.push(i)
                }
                r && n && n(r)
            },
            async finishTaskCallback(e) {
                const {
                    [G.CurrentIndex]: t, [G.TaskResponse]: n, [G.TaskCompleteCallback]: r
                } = e;
                await this.stopRecording(e), r && r(this.taskDurationMillisecond()), this.state.cards && this.state.hasEndCard !== void 0 && this.lookAheadAndStopStream(t, n, this.state.cards, this.state.hasEndCard)
            },
            startTaskCallback() {
                this.state.startTime = new Date
            },
            permissionStatusCallback(e) {
                var r;
                const {
                    [G.PermissionStatusCallback]: t
                } = e, n = this.state.avStream;
                t && t(n, n ? (n == null ? void 0 : n.getVideoTracks().length) > 0 : !1, !!((r = this.state.captureStream) != null && r.active), this.state.captureStream)
            },
            lookAheadAndStopStream(e, t, n, r) {
                const {
                    avRecorder: i,
                    screenRecorder: o
                } = this.state, {
                    allResponses: a
                } = ee.getState(), s = Eu({
                    cards: n,
                    index: e,
                    hasEndCard: r,
                    allResponses: a
                });
                s !== null && n[s].type === R.RecordedTask || [i, o].map(l => {
                    l && (l.state === "recording" && l.stop(), l.stream.getTracks().map(u => {
                        u.readyState === "live" && u.stop()
                    }))
                })
            }
        },
        qr = Object.create(Uv);
    Object.freeze(qr);

    function Lu(e) {
        var t, n, r = "";
        if (typeof e == "string" || typeof e == "number") r += e;
        else if (typeof e == "object")
            if (Array.isArray(e))
                for (t = 0; t < e.length; t++) e[t] && (n = Lu(e[t])) && (r && (r += " "), r += n);
            else
                for (t in e) e[t] && (r && (r += " "), r += t);
        return r
    }

    function F() {
        for (var e, t, n = 0, r = ""; n < arguments.length;)(e = arguments[n++]) && (t = Lu(e)) && (r && (r += " "), r += t);
        return r
    }
    var Pv = 0;

    function g(e, t, n, r, i, o) {
        var a, s, l = {};
        for (s in t) s == "ref" ? a = t[s] : l[s] = t[s];
        var u = {
            type: e,
            props: l,
            key: n,
            ref: a,
            __k: null,
            __: null,
            __b: 0,
            __e: null,
            __d: void 0,
            __c: null,
            __h: null,
            constructor: void 0,
            __v: --Pv,
            __source: i,
            __self: o
        };
        if (typeof e == "function" && (a = e.defaultProps))
            for (s in a) l[s] === void 0 && (l[s] = a[s]);
        return P.vnode && P.vnode(u), u
    }
    const we = e => g("button", { ...e,
            className: F("ul-card-text__button", e.className),
            id: "ul-card-text__button"
        }),
        He = ({
            message: e,
            properties: t
        }) => {
            const n = t == null ? void 0 : t.captionText;
            return g(Re, {
                children: [e && g("h1", {
                    className: A.QuestionHeader,
                    id: A.QuestionHeader,
                    ...n ? {} : {
                        style: {
                            marginBottom: "15px"
                        }
                    },
                    children: e
                }), n && g("p", {
                    className: A.Caption,
                    id: A.Caption,
                    children: n
                })]
            })
        },
        Ru = ({
            buttonText: e = "View Prototype",
            handleClick: t
        }) => g("button", {
            className: "prototype-button",
            onClick: t,
            children: e
        }, "prototype-btn"),
        yt = ({
            defaultBody: e,
            embeddedType: t = "prototype",
            properties: n
        }) => {
            var f;
            const {
                handleClickEmbedButton: r,
                hasViewedEmbed: i,
                headers: o,
                useDesktopPrototype: a
            } = ee(d => ({
                handleClickEmbedButton: d.handleClickEmbedButton,
                hasViewedEmbed: d.hasViewedEmbed,
                headers: d.headers,
                useDesktopPrototype: d.useDesktopPrototype
            })), s = (n == null ? void 0 : n.conceptUrl) || ((f = n == null ? void 0 : n.consentDocument) == null ? void 0 : f.url), l = window.innerWidth < mf, u = o["userleap-platform"], c = (d, p) => {
                d.preventDefault(), r(p)
            };
            if (!a && l && !i && s && ["email", "link"].includes(u)) {
                if (t === "prototype") return g(Ru, {
                    handleClick: d => {
                        c(d, xe.ViewPrototypeClick)
                    }
                });
                if (t === "pdf") return g(Ru, {
                    buttonText: (n == null ? void 0 : n.viewDocumentText) || "View Document",
                    handleClick: d => {
                        c(d, xe.ViewAgreementClick)
                    }
                })
            }
            return e()
        },
        Au = (e, t) => {
            const n = _t(0),
                r = () => {
                    if (e.current) {
                        const i = e.current;
                        i.style.height = "1px";
                        const o = i.scrollHeight,
                            a = i.offsetHeight - i.clientHeight,
                            s = o + a,
                            l = parseInt(window.getComputedStyle(i).getPropertyValue("max-height")),
                            u = s <= l ? s : l;
                        n.current !== u && t(), n.current = u, i.style.height = `${u}px`
                    }
                };
            return Ie(r, []), r
        },
        Ou = ({
            border: e,
            label: t,
            isSelected: n,
            value: r,
            text: i,
            id: o,
            isRadio: a,
            useMobileStyling: s,
            error: l,
            allowTextEntry: u,
            promptText: c,
            onUserInputChanged: f
        }) => {
            const {
                styleNonce: d,
                viewDocument: p
            } = ee(k => ({
                styleNonce: k.styleNonce,
                viewDocument: k.viewDocument
            })), [h, v] = ue(!1);
            jv(p, e, d);
            const m = ({
                    isSelected: k,
                    userText: L
                }) => {
                    f && f({
                        id: o || "",
                        selected: k,
                        value: r,
                        userText: L
                    })
                },
                y = k => {
                    k.stopPropagation(), m({
                        isSelected: a || !n,
                        userText: i
                    }), v(!1)
                },
                _ = () => {
                    h || v(!0)
                },
                E = () => {
                    h && v(!1)
                },
                b = k => {
                    yn(k.target) || (k.key === "Enter" || k.key === " ") && y(k)
                },
                w = {
                    onClick: k => y(k),
                    onKeyPress: k => b(k)
                };
            "ontouchstart" in p.documentElement ? (w.onTouchStart = E, w.onTouchCancel = E, w.onTouchEnd = E) : (w.onMouseDown = _, w.onMouseLeave = E);
            const x = a ? `radio-${o}` : `checkbox-${o}`,
                C = n || h ? [zr] : [],
                I = [...l ? [Uu] : [], ...C];
            return g("div", {
                className: F([...ie(A.Choice, s), ...I]),
                id: `choice-div-${o}`,
                style: l ? {
                    borderColor: _n
                } : {},
                ...w,
                children: [g("div", {
                    className: F([A.ChoiceLabelContainer]),
                    children: [a ? g("div", {
                        "aria-labelledby": `label-${o}`,
                        className: F([A.ChoiceRadio, ...C]),
                        id: x,
                        role: "radio",
                        tabIndex: 0
                    }) : g("div", {
                        "aria-checked": n,
                        "aria-labelledby": `label-${o}`,
                        className: A.ChoiceCheckbox,
                        id: x,
                        role: "checkbox",
                        style: n ? {
                            backgroundColor: e,
                            borderColor: e,
                            boxShadow: "none"
                        } : {},
                        tabIndex: 0,
                        children: n && g("svg", {
                            fill: "none",
                            height: "10",
                            viewBox: "0 0 10 10",
                            width: "10",
                            xmlns: "http://www.w3.org/2000/svg",
                            children: g("path", {
                                d: "M9.15377 1.30774L4.07685 8.23082L1.30762 5.00005",
                                stroke: "white",
                                strokeLinecap: "round",
                                strokeWidth: "2"
                            })
                        })
                    }), g("label", {
                        className: F(ie(A.ChoiceLabel, s)),
                        htmlFor: x,
                        id: `label-${o}`,
                        children: t
                    })]
                }), u && n && g("div", {
                    className: F([A.ChoiceTextEntryContainer, ...C]),
                    children: g(Nv, {
                        onTextChange: k => m({
                            isSelected: n,
                            userText: k
                        }),
                        promptText: c || "Please specify",
                        textValue: i,
                        useMobileStyling: s
                    })
                })]
            })
        },
        Nv = ({
            promptText: e,
            textValue: t,
            onTextChange: n,
            useMobileStyling: r
        }) => {
            const i = _t(null),
                {
                    update: o
                } = ee(s => ({
                    update: s.update
                })),
                a = Au(i, () => o());
            return Ie(() => {
                i.current && i.current.focus()
            }, []), g("textarea", {
                "aria-label": e,
                "aria-multiline": "true",
                "aria-placeholder": e,
                className: F(ie(A.ChoiceTextInput, r)),
                "data-gramm": "false",
                maxLength: 5e3,
                name: "text",
                onChange: s => {
                    a(), yn(s.target) && (s.stopPropagation(), n(s.target.value))
                },
                onClick: s => {
                    s.stopPropagation()
                },
                onKeyPress: s => {
                    s.stopPropagation()
                },
                placeholder: e,
                ref: i,
                role: "textbox",
                rows: 1,
                value: t
            })
        },
        Du = "ul-select-style-element",
        zr = "ul-select-active-dynamic-style",
        Uu = "ul-select-error-dynamic-style",
        Mv = e => e.tagName.toLowerCase() === "style",
        jv = (e, t, n) => {
            let r = e.getElementById(Du),
                i = !1;
            r || (r = e.createElement("style"), i = !0), Mv(r) && (r.id = Du, n && (r.nonce = n), r.textContent = Vv(t), i && e.head.appendChild(r))
        },
        Vv = e => `
    .${zr} {
      border-color: ${e};
    }
    .${zr} .${A.ChoiceRadio}, .${zr}.${A.ChoiceRadio} {
      border: 6px solid ${e};
      box-shadow: none;
    }
    .${Uu} {
      border-color: ${_n};
    }
  `,
        hn = e => (e == null ? void 0 : e.buttonText) || "Next",
        Ho = e => (e == null ? void 0 : e.skipButtonText) || "Skip",
        Fv = ({
            className: e,
            message: t,
            next: n,
            properties: r,
            questionId: i,
            type: o
        }) => {
            const {
                headers: a,
                useMobileStyling: s,
                border: l
            } = ee(T => ({
                headers: T.headers,
                useMobileStyling: T.useMobileStyling,
                border: T.border
            })), [u, c] = ue(!1), [f, d] = ue(""), [p, h] = ue(!1), v = a["userleap-platform"], m = r == null ? void 0 : r.collectName, y = (r == null ? void 0 : r.nameLabelText) || "Full Name", _ = (r == null ? void 0 : r.consentText) || "I agree to the stated conditions", E = (r == null ? void 0 : r.submitButtonText) || "Submit", b = !!f.trim(), w = u && (!m || b), x = (T, U = !1) => {
                T.preventDefault(), T.stopPropagation();
                let S = null;
                if (!U) {
                    if (!w) {
                        h(!0);
                        return
                    }
                    S = {
                        submitted: !0
                    }, m && (S.name = f)
                }
                n({
                    value: S,
                    questionId: i,
                    type: o
                })
            }, C = T => {
                _f(T.target) && (T.preventDefault(), T.stopPropagation(), d(T.target.value))
            }, I = T => {
                Yt(T.target) && (T.target.style.borderColor = p && !b ? _n : l)
            }, k = T => {
                Yt(T.target) && (T.target.style.borderColor = p && !b ? _n : Ci)
            }, L = () => g("div", {
                children: [g(Ou, {
                    allowTextEntry: !1,
                    border: l,
                    error: p && !u,
                    index: 0,
                    isRadio: !1,
                    isSelected: u,
                    label: _,
                    onUserInputChanged: ({
                        selected: T
                    }) => {
                        T !== u && c(!u)
                    },
                    useMobileStyling: s
                }), m && g("input", {
                    "aria-label": y,
                    "aria-placeholder": y,
                    className: F(ie(A.ConsentLegalNameInput, s)),
                    "data-gramm": "false",
                    maxLength: 250,
                    name: "name",
                    onBlur: k,
                    onFocus: I,
                    onInput: C,
                    placeholder: y,
                    style: p && !b ? {
                        borderColor: _n
                    } : {},
                    tabIndex: 0,
                    value: f
                }), g("div", {
                    className: "ul-card__button-wrapper ul-card-vertical__button-wrapper",
                    children: [g(we, {
                        className: w ? "" : A.ButtonDisabled,
                        onClick: x,
                        children: E
                    }), r.required === !1 && g("button", {
                        className: "ul-card-skip__button",
                        onClick: T => x(T, !0),
                        children: Ho(r)
                    })]
                })]
            });
            return g("div", {
                className: F(Me(A.CardMainContent, v)),
                children: g("div", {
                    className: F([e, "ul-card__consent-legal", A.FadeInTransition]),
                    children: [g(He, {
                        message: t
                    }), g("div", {
                        className: "ul-rich-text-body",
                        dangerouslySetInnerHTML: r && r.richTextBody ? {
                            __html: r && r.richTextBody
                        } : void 0,
                        id: "ul-card__consent-legal-body-container"
                    }), g(yt, {
                        properties: r,
                        defaultBody: L,
                        embeddedType: "pdf"
                    })]
                }, i)
            })
        },
        Bv = ({
            activeValue: e,
            border: t,
            icon: n,
            isPressed: r,
            onSubmit: i,
            range: o,
            scaleLabelType: a,
            setActiveValue: s,
            setIsPressed: l,
            useMobileStyling: u,
            value: c
        }) => {
            const f = `option-${c}`,
                d = a === Vt.Number,
                p = a === Vt.Star,
                h = d && c === e,
                [v, m] = (() => c <= e && p || c === e ? r ? [t, 1] : [t, .3] : ["", 1])(),
                y = () => {
                    switch (a) {
                        case Vt.Star:
                            return F([...ie(A.LikertStar, u), ...ie(`${A.LikertStar}-${c}`, u)]);
                        case Vt.Smiley:
                            return F([...ie(A.LikertSmiley, u), ...ie(`${A.LikertSmiley}-${c}`, u)]);
                        default:
                            return F(c === o ? [...ie(A.LikertNumber, u), ...ie(`${A.LikertNumber}-${c}`, u), ...ie("likert-last-option", u)] : [...ie(A.LikertNumber, u), ...ie(`${A.LikertNumber}-${c}`, u)])
                    }
                },
                _ = () => {
                    s(-1), l(!1)
                };
            return g("div", {
                "aria-label": d ? void 0 : String(c),
                className: y(),
                dangerouslySetInnerHTML: {
                    __html: n
                },
                id: f,
                onClick: () => i(),
                onPointerDown: () => l(!0),
                onPointerEnter: () => s(c),
                onPointerLeave: _,
                role: "radio",
                style: {
                    color: d ? "" : v,
                    borderColor: h ? v : "",
                    fillOpacity: h ? "" : m,
                    zIndex: h ? 3 : "auto"
                },
                tabIndex: 0
            })
        },
        Hv = ({
            className: e,
            labels: t,
            message: n,
            next: r,
            properties: i,
            questionId: o,
            type: a
        }) => {
            const {
                border: s,
                headers: l,
                useMobileStyling: u
            } = ee(L => ({
                border: L.border,
                headers: L.headers,
                useMobileStyling: L.useMobileStyling
            })), [c, f] = ue(-1), [d, p] = ue(!1), h = l["userleap-platform"], v = t && t.left, m = t && t.right;
            let y;
            const {
                range: _,
                scaleLabelType: E,
                ratingIcons: b
            } = i;
            _ && (y = Number(_));
            const w = y || 5,
                x = L => {
                    var T, U;
                    switch (E) {
                        case Vt.Star:
                            return (T = b[0]) == null ? void 0 : T.svg;
                        case Vt.Smiley:
                            return (U = b[L]) == null ? void 0 : U.svg;
                        default:
                            return String(L + 1)
                    }
                },
                C = [...Array(w)].map((L, T) => {
                    const U = T + 1;
                    return g(Bv, {
                        activeValue: c,
                        border: s,
                        icon: x(T),
                        isPressed: d,
                        onSubmit: () => r({
                            value: U,
                            questionId: o,
                            type: a
                        }),
                        range: w,
                        scaleLabelType: E,
                        setActiveValue: f,
                        setIsPressed: p,
                        useMobileStyling: u,
                        value: U
                    }, T)
                }),
                I = L => {
                    L.preventDefault(), L.stopPropagation(), r({
                        value: null,
                        questionId: o,
                        type: a
                    })
                },
                k = () => g(Re, {
                    children: [g("div", {
                        "aria-label": `Rating (1 - ${w})`,
                        className: "ul-card--likert__numbers",
                        role: "radiogroup",
                        children: C
                    }), g("div", {
                        className: "ul-card--likert__labels",
                        children: [g("span", {
                            children: v
                        }), g("span", {
                            children: m
                        })]
                    }), !i.required && g("div", {
                        className: "ul-vertical-centered-container",
                        children: g(we, {
                            onClick: I,
                            children: hn(i)
                        })
                    })]
                });
            return g("div", {
                className: F(Me(A.CardMainContent, h)),
                children: g("form", {
                    className: F([e, "ul-card--likert", A.FadeInTransition]),
                    children: [g(He, {
                        message: n,
                        properties: i
                    }), g(yt, {
                        properties: i,
                        defaultBody: k
                    })]
                }, o)
            })
        },
        Pu = ({
            className: e,
            message: t,
            onSubmit: n,
            options: r = [],
            properties: i,
            questionId: o,
            type: a
        }) => {
            const {
                border: s,
                headers: l,
                useMobileStyling: u
            } = ee(C => ({
                border: C.border,
                headers: C.headers,
                useMobileStyling: C.useMobileStyling
            })), c = r.reduce((C, I) => (C[I.id] = {
                isSelected: !1
            }, C), {}), [f, d] = ue(c), p = l["userleap-platform"], h = a === R.MultipleChoice, v = i.required, m = Object.entries(f).some(([C, I]) => {
                var T;
                const k = r.find(U => `${U.id}` === C),
                    L = I.userText === void 0 || I.userText.trim() === "";
                return ((T = k == null ? void 0 : k.optionProperties) == null ? void 0 : T.allowsTextEntry) && L && I.isSelected
            }), y = Object.values(f).some(C => C.isSelected), _ = m || v && !y, E = r.map(({
                id: C,
                label: I,
                value: k,
                optionProperties: L
            }, T) => {
                var V, D;
                const U = `${C}`,
                    {
                        allowsTextEntry: S
                    } = L || {
                        allowsTextEntry: !1
                    };
                return g(Ou, {
                    allowTextEntry: S,
                    border: s,
                    error: !1,
                    id: U,
                    index: T,
                    isRadio: h,
                    isSelected: !!((V = f[U]) != null && V.isSelected),
                    label: I,
                    onUserInputChanged: X => w(X.id, X.selected, X.userText),
                    promptText: "Please specify",
                    text: (D = f[C]) == null ? void 0 : D.userText,
                    useMobileStyling: u,
                    value: k
                }, U)
            }), b = C => {
                C.preventDefault(), C.stopPropagation(), n(f)
            }, w = (C, I, k) => {
                const L = Object.assign({}, f);
                if (h && I)
                    for (const T of Object.values(L)) T.isSelected = !1, delete T.userText;
                L[C] = {
                    isSelected: I,
                    userText: k
                }, d(L)
            }, x = () => g("div", {
                children: [g("div", {
                    className: F(ie(A.ChoiceGroup, u)),
                    role: h ? "radiogroup" : "group",
                    children: E
                }), g("div", {
                    className: "ul-card__button-wrapper",
                    children: g(we, {
                        disabled: _,
                        onClick: b,
                        children: hn(i)
                    })
                })]
            });
            return g("div", {
                className: F(Me(A.CardMainContent, p)),
                children: g("form", {
                    className: F([e, "ul-card--multiple", A.FadeInTransition]),
                    id: "text-form",
                    onSubmit: b,
                    children: [g(He, {
                        message: t,
                        properties: i
                    }), g(yt, {
                        properties: i,
                        defaultBody: x
                    })]
                }, o)
            })
        },
        Kv = e => {
            const {
                questionId: t,
                type: n,
                next: r,
                options: i
            } = e;
            return g(Pu, { ...e,
                onSubmit: a => {
                    const s = Object.entries(a).find(([, d]) => d.isSelected) || [void 0, void 0],
                        [l, u] = s,
                        c = i.find(d => `${d.id}` === l),
                        f = u != null && u.userText ? {
                            [l]: {
                                userText: u.userText
                            }
                        } : null;
                    r({
                        value: c && l ? {
                            [l]: c.value
                        } : {},
                        secondaryValue: f,
                        questionId: t,
                        type: n
                    })
                }
            })
        },
        $v = e => {
            const {
                questionId: t,
                type: n,
                next: r
            } = e;
            return g(Pu, { ...e,
                onSubmit: o => {
                    const a = {},
                        s = Object.entries(o).reduce((u, [c, f]) => (u[c] = f.isSelected, u), a),
                        l = Object.entries(o).reduce((u, [c, f]) => {
                            if (!f.userText) return u;
                            const d = u || {};
                            return d[c] = {
                                userText: f.userText
                            }, d
                        }, null);
                    r({
                        value: s,
                        secondaryValue: l,
                        questionId: t,
                        type: n
                    })
                }
            })
        },
        Gv = ({
            className: e,
            props: {
                labels: t,
                message: n,
                properties: r
            },
            next: i,
            questionId: o,
            type: a
        }) => {
            const {
                border: s,
                headers: l,
                useMobileStyling: u
            } = ee(m => ({
                border: m.border,
                headers: m.headers,
                useMobileStyling: m.useMobileStyling
            })), c = l["userleap-platform"], f = t && t.left, d = t && t.right, p = [...Array(11)].map((m, y) => g("div", {
                className: F([...ie(A.NPSNumber, u), ...ie(`${A.NPSNumber}-${y}`, u)]),
                id: `option-${y}`,
                onClick: () => i({
                    value: y,
                    questionId: o,
                    type: a
                }),
                onKeyPress: _ => {
                    _.preventDefault(), (_.key === "Enter" || _.key === " ") && i({
                        value: y,
                        questionId: o,
                        type: a
                    })
                },
                onPointerDown: _ => {
                    Yt(_.target) && (_.target.style.zIndex = "2", _.target.style.borderColor = s)
                },
                onPointerLeave: _ => {
                    Yt(_.target) && (_.target.style.zIndex = "auto", _.target.style.borderColor = Ci)
                },
                role: "radio",
                tabIndex: 0,
                children: y
            }, y)), h = m => {
                m.preventDefault(), m.stopPropagation(), i({
                    value: null,
                    questionId: o,
                    type: a
                })
            }, v = () => g("div", {
                children: [g("div", {
                    className: "ul-card--nps__numbers",
                    children: p
                }), g("div", {
                    className: "ul-card--nps__labels",
                    children: [g("span", {
                        children: f
                    }), g("span", {
                        children: d
                    })]
                }), !r.required && g("div", {
                    className: "ul-vertical-centered-container",
                    children: g(we, {
                        onClick: h,
                        children: hn(r)
                    })
                })]
            });
            return g("div", {
                className: F(Me(A.CardMainContent, c)),
                children: g("form", {
                    className: F([e, "ul-card--nps", A.FadeInTransition]),
                    children: [g(He, {
                        message: n,
                        properties: r
                    }), g(yt, {
                        properties: r,
                        defaultBody: v
                    })]
                }, o)
            })
        },
        qv = ({
            className: e,
            message: t,
            next: n,
            properties: r,
            questionId: i,
            type: o
        }) => {
            const {
                border: a,
                headers: s,
                useMobileStyling: l,
                update: u
            } = ee(C => ({
                border: C.border,
                headers: C.headers,
                useMobileStyling: C.useMobileStyling,
                update: C.update
            })), [c, f] = ue(""), d = _t(null), p = s["userleap-platform"], h = c.trim(), v = r.required === !0 && !h, m = Au(d, () => u()), y = C => {
                m(), C.preventDefault(), C.stopPropagation(), yn(C.target) && f(C.target.value)
            }, _ = C => {
                C.preventDefault(), C.stopPropagation(), n({
                    value: c,
                    questionId: i,
                    type: o
                })
            }, E = r && r.openTextPlaceholder ? r.openTextPlaceholder : "", b = C => {
                yn(C.target) && (C.target.style.borderColor = a)
            }, w = C => {
                yn(C.target) && (C.target.style.borderColor = Ci)
            }, x = () => g("div", {
                className: "ul-card-text",
                children: [g("div", {
                    className: "ul-card-text__container",
                    children: g("textarea", {
                        "aria-label": E,
                        "aria-labelledby": A.QuestionHeader,
                        "aria-multiline": "true",
                        "aria-placeholder": E,
                        className: F(ie(A.OpenTextInput, l)),
                        "data-gramm": "false",
                        maxLength: 5e3,
                        name: "text",
                        onBlur: w,
                        onChange: y,
                        onFocus: b,
                        placeholder: E,
                        ref: d,
                        role: "textbox",
                        tabIndex: 0
                    })
                }), g(we, {
                    disabled: v,
                    onClick: _,
                    style: {
                        backgroundColor: v ? "" : a
                    },
                    children: hn(r)
                })]
            });
            return g("div", {
                className: F(Me(A.CardMainContent, p)),
                children: g("form", {
                    className: F([e, "ul-card--text", A.FadeInTransition]),
                    id: "text-form",
                    children: [g(He, {
                        message: t,
                        properties: r
                    }), g(yt, {
                        defaultBody: x,
                        properties: r
                    })]
                }, i)
            })
        };
    var wt = (e => (e[e.RequestNeeded = 1] = "RequestNeeded", e[e.TryAgain = 2] = "TryAgain", e[e.Ready = 3] = "Ready", e))(wt || {});
    const Wr = e => e.type === Ce.AvPermission,
        Nu = e => e.type === Ce.ScreenPermission,
        zv = (e, t) => !(Wr(t) ? t.permissionDescriptors : []).includes(cn.Camera) || e.getVideoTracks().length > 0,
        Mu = (e, t) => {
            if (e === void 0) return wt.RequestNeeded;
            if (e) {
                if (!zv(e, t)) return wt.RequestNeeded
            } else return wt.TryAgain;
            return wt.Ready
        },
        ju = {
            avStream: null,
            currentPage: null,
            mediaRecordingUids: null,
            nextQuestion: () => {},
            passthroughData: void 0,
            recordingMediaTypes: void 0,
            screenPermissionRequested: !1,
            type: void 0
        },
        Ke = wu(e => ({ ...ju,
            reset: () => {
                e(ju)
            },
            updatePage: t => {
                e(t)
            }
        }));

    function Ko({
        currentPage: e,
        pages: t
    }) {
        const {
            avStream: n,
            recordingMediaTypes: r,
            updatePage: i
        } = Ke.getState(), {
            recorderEventEmitter: o
        } = ee.getState();
        o.emit(fe.AvPermission, {
            [G.PermissionDescriptors]: e.permissionDescriptors,
            [G.StreamReadyCallback]: (a, s) => {
                if (n === a) return;
                let l = e;
                if (a && !e.permissionDescriptors.includes(cn.Camera)) {
                    const u = t.indexOf(e),
                        c = s != null && s.active ? u + 2 : u + 1;
                    (s == null ? void 0 : s.active) && r && o.emit(fe.BeginRecording, {
                        [G.RecordingMediaTypes]: r,
                        [G.StartRecordingCallback]: f => i({
                            mediaRecordingUids: f
                        })
                    }), l = t[c]
                }
                i({
                    currentPage: l,
                    avStream: a
                })
            }
        })
    }

    function Wv({
        pages: e,
        userId: t,
        responseGroupUid: n,
        surveyId: r,
        questionId: i,
        next: o
    }) {
        const {
            updatePage: a
        } = Ke.getState(), {
            eventEmitFn: s,
            recorderEventEmitter: l
        } = ee.getState(), u = {
            questionId: i,
            surveyId: r,
            visitorId: t,
            responseGroupUid: n
        };
        let c = 0;
        l.emit(xe.RecordedTaskPermissionScreen), s(xe.RecordedTaskPermissionScreen), l.emit(fe.PermissionStatus, {
            [G.PermissionStatusCallback]: (d, p, h, v) => {
                const m = e[c],
                    {
                        type: y
                    } = m,
                    _ = [Oe.Screen];
                if (Wr(m)) {
                    const {
                        permissionDescriptors: E
                    } = m, b = E == null ? void 0 : E.includes(cn.Microphone), w = E == null ? void 0 : E.includes(cn.Camera);
                    b && _.push(Oe.Audio), w && _.push(Oe.Video);
                    const x = (d == null ? void 0 : d.active) && !w,
                        C = (d == null ? void 0 : d.active) && p;
                    (x || C) && c++
                }
                Nu(e[c]) && h && (c++, l.emit(fe.BeginRecording, {
                    [G.RecordingMediaTypes]: _,
                    [G.StartRecordingCallback]: E => a({
                        mediaRecordingUids: E
                    })
                })), a({
                    currentPage: e[c],
                    avStream: d,
                    screenPermissionRequested: h,
                    nextQuestion: o,
                    type: y,
                    passthroughData: u,
                    recordingMediaTypes: _,
                    captureStream: v
                })
            }
        });
        const f = e[c];
        return f.type === Ce.AvPermission && Ko({
            currentPage: f,
            pages: e
        }), f
    }

    function $o({
        status: e
    }) {
        const {
            nextQuestion: t,
            passthroughData: n,
            mediaRecordingUids: r,
            reset: i
        } = Ke.getState(), {
            recorderEventEmitter: o,
            handleUploadUpdate: a,
            index: s
        } = ee.getState(), l = {
            value: {
                taskStatus: e
            },
            type: R.RecordedTask,
            questionId: (n == null ? void 0 : n.questionId) || 1
        };
        !n || o.emit(fe.FinishTask, {
            [G.BeginCallback]: u => {
                a({
                    mediaRecordingUid: u,
                    isSubmitted: !0,
                    progressPct: 0,
                    isComplete: !1
                })
            },
            [G.ProgressCallback]: (u, c) => {
                a({
                    mediaRecordingUid: u,
                    progressPct: c.detail,
                    isSubmitted: !1,
                    isComplete: !1
                })
            },
            [G.UploadCallback]: u => {
                u && a({
                    mediaRecordingUid: u,
                    isComplete: !0,
                    isSubmitted: !0,
                    progressPct: 100
                })
            },
            [G.PassthroughData]: n,
            [G.CurrentIndex]: s,
            [G.TaskResponse]: l,
            [G.TaskCompleteCallback]: u => {
                l.value.taskDurationMillisecond = u, r && (l.value.mediaRecordingUids = r), i(), t(l)
            }
        })
    }

    function Go({
        pages: e,
        setIsRequestingPermission: t
    }) {
        const {
            recorderEventEmitter: n,
            eventEmitFn: r
        } = ee.getState(), {
            updatePage: i,
            currentPage: o,
            recordingMediaTypes: a,
            screenPermissionRequested: s
        } = Ke.getState();
        if (!o) return;
        const l = e.indexOf(o);
        switch (o.type) {
            case Ce.AvPermission:
                {
                    const u = s ? l + 2 : l + 1;s && a && n.emit(fe.BeginRecording, {
                        [G.RecordingMediaTypes]: a,
                        [G.StartRecordingCallback]: c => {
                            i({
                                mediaRecordingUids: c
                            })
                        }
                    }),
                    i({
                        currentPage: e[u]
                    });
                    return
                }
            case Ce.ScreenPermission:
                n.emit(fe.ScreenPermission, {
                    [G.ScreenPermissionRequested]: t,
                    [G.StreamReadyCallback]: (u, c) => {
                        const f = c ? e[l + 1] : o;
                        c && a && n.emit(fe.BeginRecording, {
                            [G.RecordingMediaTypes]: a,
                            [G.StartRecordingCallback]: d => {
                                i({
                                    captureStream: c,
                                    mediaRecordingUids: d
                                })
                            }
                        }), i({
                            currentPage: f,
                            screenPermissionRequested: !0,
                            captureStream: c
                        })
                    }
                });
                return;
            case Ce.StartTask:
                r(xe.RecordedTaskStart), n.emit(xe.RecordedTaskStart), n.emit(fe.StartTask), i({
                    currentPage: e[l + 1],
                    screenPermissionRequested: !0
                });
                return;
            case Ce.CompleteTask:
                return
        }
    }
    const Vu = "ul-permission-graphics-container",
        Fu = "ul-permission-body",
        Bu = F([Vu, "ul_recorded-task-inset-spacing"]),
        Yr = F(["ul-horizontal-button-container", "ul-horizontal-button-container-left"]),
        Hu = ({
            richTextBody: e
        }) => g("div", {
            className: "ul-rich-text-body",
            dangerouslySetInnerHTML: {
                __html: e
            },
            id: "ul-task-detail-container"
        }),
        Qr = ({
            required: e,
            skipButtonText: t,
            bottom: n = !1
        }) => e ? null : g(we, {
            className: F([n && "ul-skip-button-below", A.InactiveButton]),
            onClick: $o.bind(null, {
                status: Se.Abandoned
            }),
            children: t || "Skip"
        }),
        qo = e => {
            const {
                avStream: t,
                captureStream: n,
                recordingMediaTypes: r,
                updatePage: i
            } = Ke.getState(), o = (r == null ? void 0 : r.includes(Oe.Audio)) || (r == null ? void 0 : r.includes(Oe.Video));
            Ie(() => {
                const a = setInterval(() => {
                    o && t && !t.active ? i({
                        avStream: null,
                        currentPage: e[0]
                    }) : (!n || !n.active) && i({
                        captureStream: void 0,
                        currentPage: e[o ? 1 : 0]
                    })
                }, 1e3);
                return () => clearInterval(a)
            }, [t, n, o, e, r, i])
        },
        Yv = ({
            content: e,
            pages: t,
            required: n
        }) => {
            const {
                buttonText: r,
                skipButtonText: i,
                taskDetail: o
            } = e;
            return qo(t), g("div", {
                className: "ul-task-page",
                children: [g(Hu, {
                    richTextBody: o
                }), g("div", {
                    className: Yr,
                    children: [g(we, {
                        onClick: Go.bind(null, {
                            pages: t
                        }),
                        children: r
                    }), g(Qr, {
                        required: n,
                        skipButtonText: i
                    })]
                })]
            }, "start-task")
        },
        Qv = ({
            content: e,
            pages: t,
            properties: n
        }) => {
            const {
                buttonText: r,
                skipButtonText: i
            } = e;
            qo(t);
            const a = g(yt, {
                properties: n,
                defaultBody: () => g("div", {
                    className: Yr,
                    children: [g(we, {
                        className: "ul-complete-task-button",
                        onClick: $o.bind(null, {
                            status: Se.Completed
                        }),
                        children: r
                    }), g(we, {
                        className: F([A.InactiveButton]),
                        onClick: $o.bind(null, {
                            status: Se.GivenUp
                        }),
                        children: i
                    })]
                })
            });
            return g("div", {
                className: "ul-task-page",
                children: [g(Hu, {
                    richTextBody: e.taskDetail
                }), a]
            }, "complete-task")
        },
        Zv = ({
            content: e,
            pages: t,
            required: n
        }) => {
            const {
                buttonText: r,
                skipButtonText: i
            } = e, [o] = ee(l => [l.tabTitle]), [a, s] = ue(!1);
            return g("div", {
                children: [g("div", {
                    className: Bu,
                    children: [g("p", {
                        style: {
                            marginTop: "auto"
                        },
                        children: e.selectTabText
                    }), g("div", {
                        className: "ul-select-tab-container",
                        children: g("p", {
                            className: Fu,
                            children: o
                        })
                    })]
                }), g("div", {
                    className: n ? "" : Yr,
                    children: [g(we, {
                        disabled: a,
                        onClick: Go.bind(null, {
                            pages: t,
                            setIsRequestingPermission: s
                        }),
                        children: r
                    }), g(Qr, {
                        required: n,
                        skipButtonText: i
                    })]
                })]
            })
        },
        Xv = ({
            content: e
        }) => g("div", {
            className: F([Vu, "ul_permission_svg_container", "ul_recorded-task-inset-spacing", "ul-center-horizontally"]),
            dangerouslySetInnerHTML: {
                __html: e.svg
            }
        }, "ul-permission-request-graphic"),
        Jv = ({
            content: e,
            pages: t,
            required: n
        }) => {
            const {
                permissionDeniedHeadline: r,
                permissionDeniedBody: i,
                skipButtonText: o,
                tryAgainButtonText: a
            } = e, s = Wr(t[0]) ? t[0] : null;
            return Ie(() => {
                const l = setInterval(() => {
                    s !== null && Ko({
                        currentPage: s,
                        pages: t
                    })
                }, 1e3);
                return () => clearInterval(l)
            }, [s, t]), s ? g("div", {
                children: [g("div", {
                    className: Bu,
                    children: g("p", {
                        className: "ul-av-permission-denied-paragraph",
                        children: [g("span", {
                            className: "ul-av-permission-denied-headline",
                            children: r
                        }), g("span", {
                            className: Fu,
                            children: i
                        })]
                    })
                }), g("div", {
                    className: Yr,
                    children: [g(we, {
                        onClick: Ko.bind(null, {
                            currentPage: s,
                            pages: t
                        }),
                        children: a
                    }), g(Qr, {
                        required: n,
                        skipButtonText: o
                    })]
                })]
            }) : null
        },
        em = ({
            stream: e
        }) => g("video", {
            autoPlay: !0,
            className: F(["ul_recorded-task-inset-spacing"]),
            id: "ul-record-task-video-preview",
            muted: !0,
            ref: t => {
                t && (t.srcObject = e || null)
            }
        }),
        tm = ({
            content: e,
            pages: t,
            required: n
        }) => {
            const {
                skipButtonText: r
            } = e, {
                avStream: i
            } = Ke.getState();
            return qo(t), g("div", {
                children: [g(em, {
                    stream: i
                }), g("div", {
                    className: "ul-vertical-button-container-center",
                    children: [g(we, {
                        onClick: Go.bind(null, {
                            pages: t
                        }),
                        children: e.buttonText
                    }), g(Qr, {
                        bottom: !0,
                        required: n,
                        skipButtonText: r
                    })]
                })]
            })
        },
        nm = ({
            properties: e
        }) => {
            const {
                pages: t,
                required: n
            } = e, {
                avStream: r,
                currentPage: i
            } = Ke.getState();
            if (i === void 0) return null;
            switch (i == null ? void 0 : i.type) {
                case Ce.AvPermission:
                    {
                        const o = Mu(r, i);
                        return o === wt.RequestNeeded ? g(Xv, {
                            content: i
                        }) : o === wt.TryAgain ? g(Jv, {
                            content: i,
                            pages: t,
                            required: n
                        }) : g(tm, {
                            content: i,
                            pages: t,
                            required: n
                        })
                    }
                case Ce.ScreenPermission:
                    return g(Zv, {
                        content: i,
                        pages: t,
                        required: n
                    });
                case Ce.StartTask:
                    return g(Yv, {
                        content: i,
                        pages: t,
                        required: n
                    });
                case Ce.CompleteTask:
                    return g(Qv, {
                        content: i,
                        pages: t,
                        properties: e
                    });
                default:
                    return null
            }
        },
        rm = ({
            className: e,
            properties: t,
            next: n,
            questionId: r
        }) => {
            const i = ee(),
                {
                    headers: o,
                    surveyId: a,
                    responseGroupUid: s,
                    userId: l
                } = i,
                u = Ke(),
                {
                    screenPermissionRequested: c
                } = u,
                f = Ke(m => m.avStream);
            let d = Ke(m => m.currentPage);
            d || (d = Wv({
                questionId: r,
                surveyId: a,
                next: m => {
                    n(m)
                },
                pages: t.pages,
                responseGroupUid: s,
                userId: l
            }));
            let p = d.headline,
                h = d.captionText;
            const v = Mu(f, d);
            return Nu(d) && c && (p = d.permissionDeniedHeadline, h = d.permissionDeniedCaptionText), Wr(d) && v === wt.Ready && (p = d.permissionGrantedHeadline, h = d.permissionGrantedCaptionText), g("div", {
                className: F([...Me(A.CardMainContent, o["userleap-platform"])]),
                children: g("div", {
                    className: F([e, "ul-center-horizontally", A.FadeInTransition]),
                    children: [g(He, {
                        message: p,
                        properties: {
                            captionText: h
                        }
                    }), g(nm, {
                        properties: t
                    })]
                })
            })
        },
        im = {
            "{{user_id}}": "externalUserId",
            "{{email}}": "email"
        },
        om = (e = void 0, t = {}) => {
            if (!e) return e;
            let n = e;
            const r = [];
            for (const [l, u] of Object.entries(im))
                if (n.toLowerCase().includes(l))
                    if (t[u]) {
                        const c = new RegExp(l, "gi");
                        n = n.replace(c, t[u])
                    } else r.push(l);
            if (r.length === 0 || !n.includes("?")) return n;
            const i = n.slice(0, n.indexOf("?")),
                a = n.slice(n.indexOf("?") + 1).split("&").map(l => l.split("=")).filter(l => !r.includes(l[1]));
            if (a.length === 0) return i;
            const s = a.map(l => l.join("=")).join("&");
            return `${i}?${s}`
        },
        am = ({
            className: e,
            message: t,
            next: n,
            properties: r,
            questionId: i,
            type: o
        }) => {
            const {
                headers: a,
                visitorAttributes: s
            } = ee(p => ({
                headers: p.headers,
                visitorAttributes: p.visitorAttributes
            })), l = a["userleap-platform"], u = (p, h = !1) => {
                n({
                    value: h ? {
                        skipped: !0
                    } : void 0,
                    questionId: i,
                    type: o
                })
            }, c = p => {
                (p.key === "Enter" || p.key === " ") && n({
                    value: void 0,
                    questionId: i,
                    type: o
                })
            }, f = () => g("div", {
                className: "ul-card-button-group",
                children: [g("a", {
                    className: "ul-card-text__button ul-card__text-url-prompt-button",
                    href: om(r && r.buttonUrl, s),
                    id: "ul-card-text__button",
                    onClick: u,
                    onKeyPress: c,
                    rel: "noreferrer",
                    role: "button",
                    tabIndex: 0,
                    target: "_blank",
                    children: hn(r)
                }), r.required === !1 && g("button", {
                    className: "ul-card-skip__button",
                    onClick: p => u(p, !0),
                    children: Ho(r)
                })]
            }), d = (p, h) => p ? g("div", {
                className: "ul-rich-text-body",
                dangerouslySetInnerHTML: {
                    __html: p
                },
                id: "ul-card__text-url-body-container"
            }) : g("div", {
                className: "ul-rich-text-body",
                id: "ul-card__text-url-body-container",
                children: (h ? h.split(/\n\s*\n/g) : []).map((v, m) => g("p", {
                    children: v
                }, m))
            });
            return g("div", {
                className: F(Me(A.CardMainContent, l)),
                children: g("div", {
                    className: F([e, "ul-card__text-url-prompt", A.FadeInTransition]),
                    children: [g(He, {
                        message: t
                    }), d(r && r.richTextBody, r && r.body), g(yt, {
                        defaultBody: f,
                        properties: r
                    })]
                }, i)
            })
        },
        sm = ({
            className: e,
            questionId: t
        }) => {
            const {
                border: n,
                destroy: r,
                endCard: i,
                headers: o
            } = ee(l => ({
                border: l.border,
                endCard: l.endCard,
                destroy: l.destroy,
                headers: l.headers
            }));
            Ie(() => {
                setTimeout(() => {
                    r(Wt)
                }, 2e3)
            }, [r]);
            const a = i && i.subheader ? g("p", {
                    className: A.Caption,
                    children: i.subheader
                }) : null,
                s = i && i.headline ? i.headline : "";
            return g("div", {
                className: F(Me(A.CardMainContent, o["userleap-platform"])),
                children: g("div", {
                    className: F([e, "ul-card--thanks", A.FadeInTransition]),
                    children: g("div", {
                        children: g("div", {
                            className: "ul-card--thanks-content",
                            children: [g("div", {
                                className: "ul-thanks-check",
                                children: g("svg", {
                                    "aria-labelledby": "title",
                                    fill: "none",
                                    height: "99",
                                    viewBox: "0 0 81 99",
                                    width: "81",
                                    xmlns: "http://www.w3.org/2000/svg",
                                    children: [g("path", {
                                        clipRule: "evenodd",
                                        d: "M40.5 77C60.9345 77 77.5 60.4345 77.5 40C77.5 19.5655 60.9345 3 40.5 3C20.0655 3 3.5 19.5655 3.5 40C3.5 60.4345 20.0655 77 40.5 77ZM80.5 40C80.5 62.0914 62.5914 80 40.5 80C18.4086 80 0.5 62.0914 0.5 40C0.5 17.9086 18.4086 0 40.5 0C62.5914 0 80.5 17.9086 80.5 40Z",
                                        fill: n,
                                        fillRule: "evenodd"
                                    }), g("path", {
                                        clipRule: "evenodd",
                                        d: "M55.025 22.9046C55.6299 23.4705 55.6616 24.4198 55.0956 25.0247C54.8724 25.2634 54.6109 25.5285 54.3157 25.8277C52.2547 27.9168 48.5549 31.667 44.8135 39.6658C43.2818 42.9406 42.0864 45.8386 41.0823 48.2729C40.6539 49.3116 40.2603 50.2659 39.8902 51.129C39.287 52.5359 38.7248 53.7508 38.1744 54.625C37.8997 55.0613 37.5806 55.4905 37.2017 55.8245C36.8201 56.1607 36.2613 56.5 35.5457 56.5C34.6742 56.5 34.0892 55.9692 33.7774 55.6083C33.4502 55.2296 33.1752 54.7511 32.9396 54.301C32.7305 53.9013 32.5088 53.4367 32.2797 52.9565C32.2429 52.8794 32.2059 52.8019 32.1688 52.7243C31.8942 52.1499 31.5959 51.534 31.2537 50.8868C29.8886 48.305 27.8539 45.2878 24.2343 43.1382C23.522 42.7152 23.2875 41.7949 23.7105 41.0826C24.1335 40.3703 25.0539 40.1358 25.7662 40.5588C30.0556 43.1062 32.4149 46.6647 33.9058 49.4845C34.2776 50.1876 34.5973 50.8487 34.8753 51.4302C34.9147 51.5124 34.9529 51.5926 34.9902 51.6707C35.2222 52.1567 35.4164 52.5637 35.5978 52.9102C35.6151 52.9434 35.6321 52.9754 35.6485 53.0061C36.0565 52.3531 36.5341 51.3434 37.133 49.9468C37.4781 49.1418 37.8572 48.2229 38.2761 47.2074C39.2886 44.7532 40.5339 41.7347 42.0961 38.3948C46.0591 29.9221 50.0641 25.8648 52.1535 23.7482C52.4423 23.4556 52.6944 23.2002 52.9048 22.9753C53.4708 22.3703 54.42 22.3387 55.025 22.9046ZM35.1994 53.5892C35.1994 53.5892 35.2 53.5888 35.2012 53.5879C35.2 53.5889 35.1994 53.5893 35.1994 53.5892ZM36.0666 53.6682C36.0732 53.674 36.0765 53.6775 36.0765 53.6777C36.0765 53.678 36.0732 53.6751 36.0666 53.6682Z",
                                        fill: n,
                                        fillRule: "evenodd"
                                    }), g("path", {
                                        d: "M69.5 97C69.5 98.1046 56.2924 99 40 99C23.7076 99 10.5 98.1046 10.5 97C10.5 95.8954 23.7076 95 40 95C56.2924 95 69.5 95.8954 69.5 97Z",
                                        fill: "black",
                                        fillOpacity: "0.2"
                                    })]
                                })
                            }), g(He, {
                                message: s
                            }), a]
                        })
                    })
                }, t)
            })
        },
        Bt = "https://cdn.sprig.com",
        M = {
            document: void 0,
            videojs: void 0
        },
        lm = `/* progress control styles */
.video-js .vjs-control {
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", "Roboto", "Oxygen", "Ubuntu", "Cantarell", "Fira Sans", "Droid Sans", "Helvetica Neue", sans-serif;
}

.video-js .vjs-progress-control .vjs-progress-holder {
  margin: 0 0px;
}

.video-js .vjs-progress-control {
  position: absolute;
  height: 3px;
  width: 100%;
}
/* position and align the buttons and button texts */
.ul-control-panel {
  bottom: 0;
  width: 100%;
  flex-direction: column;
  background-color: white;
  height: fit-content;
  z-index: 2;
}

.ul-buttons-panel {
  color: black;
  display: flex;
  gap: 20px;
  height: 50px;
  justify-content: center;
  margin: 10px;
  padding: 2px 14px 0;
}

.video-js .vjs-volume-panel {
  height: 30px;
  width: 40px;
}

.ul-inactive {
  opacity: 0.3;
  cursor: default;
  pointer-events: none;
}

/* buttons */
.ul-buttons-panel > .vjs-button {
  background-color: rgba(0, 0, 0, 0.05);
  border-radius: 50%;
  display: flex;
  height: 3em;
  justify-content: center;
  width: 3em;
}

.vjs-button>.vjs-icon-placeholder:before {
  align-items: center;
  display: flex;
  font-size: unset;
  line-height: 0.5;
  justify-content: center;
}

span.ul-button-text {
  align-self: flex-end;
  position: relative;
  top: 14px;
}

#ul-camera-button {
  white-space: nowrap;
}

.video-js .vjs-volume-control.vjs-volume-horizontal {
  background-color: #fff;
  z-index: 1;
}

.vjs-volume-bar.vjs-slider-horizontal .vjs-volume-level {
  background-color: black;
}

.video-js .vjs-volume-panel.vjs-volume-panel-horizontal.vjs-hover,
.video-js .vjs-volume-panel.vjs-volume-panel-horizontal.vjs-slider-active,
.video-js .vjs-volume-panel.vjs-volume-panel-horizontal:active {
  width: 40px;
}

.video-js .vjs-volume-panel .vjs-volume-control.vjs-slider-active,
.video-js .vjs-volume-panel .vjs-volume-control:active,
.video-js .vjs-volume-panel.vjs-hover .vjs-mute-control ~ .vjs-volume-control,
.video-js .vjs-volume-panel.vjs-hover .vjs-volume-control,
.video-js .vjs-volume-panel:active .vjs-volume-control,
.video-js .vjs-volume-panel:focus .vjs-volume-control {
  visibility: visible;
  left: 40px;
  position: absolute;
  transition: visibility 0.1s, opacity 0.1s, height 0.1s, width 0.1s, left 0s, top 0s;
}

/* play button customization */
.video-js .vjs-play-control {
  color: black;
}

.video-js .vjs-play-control .vjs-icon-placeholder:before {
  content: url("data:image/svg+xml,%3Csvg width='12' height='12' viewBox='0 0 12 12' fill='none' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M10.5363 6.40226L1.93958 10.7006C1.64037 10.8502 1.28833 10.6326 1.28833 10.2981V1.7014C1.28833 1.36688 1.64037 1.14931 1.93958 1.29891L10.5363 5.59727C10.868 5.76311 10.868 6.23642 10.5363 6.40226Z' stroke='black' stroke-width='1.5' stroke-linecap='round'/%3E%3C/svg%3E");
}

/* position and style the current timer */
.ul-time-panel {
  position: absolute;
  bottom: 80px;
  left: 10px;
  height: 22px;
  color: black;
  border: 1px solid #e0e0eb;
  border-radius: 23px;
  background-color: white;
  width: fit-content;
}

.video-js .vjs-current-time,
.vjs-no-flex .vjs-current-time {
  display: flex;
  align-items: center;
  text-align: center;
}

/* remove the dot progress indicator */
.video-js .vjs-play-progress:before,
.video-js .vjs-volume-level:before,
.vjs-icon-circle:before,
.vjs-seek-to-live-control .vjs-icon-placeholder:before {
  content: none;
}

.video-js .vjs-mute-control .vjs-icon-placeholder:before {
  content: url("data:image/svg+xml,%3Csvg width='19' height='14' fill='none' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath fill-rule='evenodd' clip-rule='evenodd' d='M8.825.324A.75.75 0 019.25 1v11.667a.75.75 0 01-1.219.585l-3.96-3.169H1a.75.75 0 01-.75-.75v-5a.75.75 0 01.75-.75h3.07L8.031.414a.75.75 0 01.794-.09zM7.75 2.56L4.802 4.92a.75.75 0 01-.469.164H1.75v3.5h2.583a.75.75 0 01.469.165l2.948 2.358V2.56zM14.911.47a.75.75 0 011.061 0 9.084 9.084 0 010 12.844.75.75 0 01-1.06-1.06 7.584 7.584 0 000-10.724.75.75 0 010-1.06zM11.97 3.41a.75.75 0 011.06 0 4.917 4.917 0 010 6.953.75.75 0 11-1.06-1.06 3.417 3.417 0 000-4.832.75.75 0 010-1.06z' fill='%23262136'/%3E%3C/svg%3E");
}

.video-js .vjs-mute-control.vjs-vol-0 .vjs-icon-placeholder:before {
  content: url("data:image/svg+xml,%3Csvg width='19' height='14' fill='none' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M8.5 1.167L4.333 4.5H1v5h3.333L8.5 12.833V1.167zM17.17 4.5l-5 5M12.17 4.5l5 5' stroke='%23262136' stroke-width='1.5' stroke-linecap='round' stroke-linejoin='round'/%3E%3C/svg%3E");
}

.video-js .vjs-mute-control.vjs-vol-1 .vjs-icon-placeholder:before {
  content: url("data:image/svg+xml,%3Csvg width='19' height='14' viewBox='0 0 19 14' fill='none' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath fill-rule='evenodd' clip-rule='evenodd' d='M8.82489 0.32403C9.08474 0.44892 9.25 0.711703 9.25 1.00001V12.6667C9.25 12.955 9.08474 13.2178 8.82489 13.3427C8.56504 13.4675 8.25661 13.4324 8.03148 13.2523L4.07025 10.0833H1C0.585786 10.0833 0.25 9.74755 0.25 9.33334V4.33334C0.25 3.91913 0.585786 3.58334 1 3.58334H4.07025L8.03148 0.414355C8.25661 0.234253 8.56504 0.19914 8.82489 0.32403ZM7.75 2.56048L4.80185 4.91899C4.66887 5.02538 4.50364 5.08334 4.33333 5.08334H1.75V8.58334H4.33333C4.50364 8.58334 4.66887 8.6413 4.80185 8.74769L7.75 11.1062V2.56048Z' fill='%23262136'/%3E%3C/svg%3E%0A");
}

.video-js .vjs-mute-control.vjs-vol-2 .vjs-icon-placeholder:before {
  content: url("data:image/svg+xml,%3Csvg width='19' height='14' viewBox='0 0 19 14' fill='none' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath fill-rule='evenodd' clip-rule='evenodd' d='M8.82489 0.32403C9.08474 0.44892 9.25 0.711703 9.25 1.00001V12.6667C9.25 12.955 9.08474 13.2178 8.82489 13.3427C8.56504 13.4675 8.25661 13.4324 8.03148 13.2523L4.07025 10.0833H1C0.585786 10.0833 0.25 9.74755 0.25 9.33334V4.33334C0.25 3.91913 0.585786 3.58334 1 3.58334H4.07025L8.03148 0.414355C8.25661 0.234253 8.56504 0.19914 8.82489 0.32403ZM7.75 2.56048L4.80185 4.91899C4.66887 5.02538 4.50364 5.08334 4.33333 5.08334H1.75V8.58334H4.33333C4.50364 8.58334 4.66887 8.6413 4.80185 8.74769L7.75 11.1062V2.56048Z' fill='%23262136'/%3E%3Cpath fill-rule='evenodd' clip-rule='evenodd' d='M11.9698 3.41124C12.2627 3.11839 12.7376 3.11846 13.0304 3.4114C13.9521 4.33341 14.4699 5.58376 14.4699 6.88748C14.4699 8.19121 13.9521 9.44156 13.0304 10.3636C12.7376 10.6565 12.2627 10.6566 11.9698 10.3637C11.6768 10.0709 11.6767 9.596 11.9696 9.30307C12.6101 8.66235 12.9699 7.79346 12.9699 6.88748C12.9699 5.98151 12.6101 5.11262 11.9696 4.4719C11.6767 4.17896 11.6768 3.70409 11.9698 3.41124Z' fill='%23262136'/%3E%3C/svg%3E%0A");
}

.video-js .vjs-volume-control:hover .vjs-mouse-display {
  display: none !important;
}

.video-js .vjs-play-progress {
  background-color: black;
}

/* position video player inside the container */
.video-js .vjs-tech {
  position: static;
}

.video-js .vjs-time-tooltip {
  padding: 0.25em 0.75em;
  align-items: center;
  color: #333;
  background: #FCFCFD;
  border-radius: 99px;
  text-align: center;
  border: 1px solid #E0E0EB;
  display: flex;
  align-items: center;
  justify-content: center;
  top: -25px;
  font-size: 12px !important;
  width: 50px !important;
}

.video-js .vjs-play-progress.vjs-slider-bar .vjs-time-tooltip {
  visibility: hidden !important;
}

.video-js .vjs-progress-control .vjs-mouse-display {
  z-index: 2;
}

.ul-video-player {
  width: 100%;
  display: flex;
  flex-direction: column;
  height: auto;
  border: 1px solid #E6E6E6;
  background-color: white;
  box-sizing: border-box;
  border-radius: 4px;
  background-clip: border-box;
  overflow: hidden;
}

.video-js.vjs-fullscreen:not(.vjs-ios-native-fs) {
  border: none;
}

#video-response-player-secondary-video-player {
  max-width: 200px;
  margin-right: 20px;
  background-color: transparent;
}

#ul-card-video__player_recorder-video-recorder.vjs-fullscreen {
  display: table;
}

.video-js div.vjs-progress-control {
  margin-top: -3px;
}

.video-js .vjs-progress-control .vjs-slider {
  background-color: #B2BBBD;
}

.vjs-record.video-js .vjs-control.vjs-button.vjs-fullscreen-control {
  position:relative;
}

.video-js .vjs-fullscreen-control .vjs-icon-placeholder:before {
  content: url("data:image/svg+xml,%3Csvg width='16' height='16' viewBox='0 0 16 16' fill='none' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M9.82143 2.54004L12.2614 2.54004C12.9242 2.54004 13.4614 3.0773 13.4614 3.74004L13.4614 6.18004' stroke='black' stroke-width='1.5' stroke-linecap='round' stroke-linejoin='round'/%3E%3Cpath d='M6.17955 13.46L3.73955 13.46C3.07681 13.46 2.53955 12.9227 2.53955 12.26L2.53955 9.81996' stroke='black' stroke-width='1.5' stroke-linecap='round' stroke-linejoin='round'/%3E%3Cpath d='M12.7772 3.22266L9.36475 6.63516' stroke='black' stroke-width='1.5' stroke-linecap='round' stroke-linejoin='round'/%3E%3Cpath d='M6.29434 9.70605L2.88184 13.1186' stroke='black' stroke-width='1.5' stroke-linecap='round' stroke-linejoin='round'/%3E%3C/svg%3E");
}

.video-js.vjs-fullscreen .vjs-fullscreen-control .vjs-icon-placeholder:before {
  content: url("data:image/svg+xml,%3Csvg width='16' height='16' fill='none' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M1.583 9.813H5.25a1 1 0 011 1v3.666M5.375 10.688L1 15.061M14.917 5.813H11.25a1 1 0 01-1-1V1.146M15.063 1l-4.376 4.375' stroke='%23262136' stroke-width='1.5' stroke-linecap='round' stroke-linejoin='round'/%3E%3C/svg%3E");
}

.video-js .vjs-play-control.vjs-ended .vjs-icon-placeholder:before, .video-js .vjs-icon-replay:before {
  content: url("data:image/svg+xml,%3Csvg width='12' height='12' viewBox='0 0 12 12' fill='none' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M10.5363 6.40226L1.93958 10.7006C1.64037 10.8502 1.28833 10.6326 1.28833 10.2981V1.7014C1.28833 1.36688 1.64037 1.14931 1.93958 1.29891L10.5363 5.59727C10.868 5.76311 10.868 6.23642 10.5363 6.40226Z' stroke='black' stroke-width='1.5' stroke-linecap='round'/%3E%3C/svg%3E");
}

.video-js .vjs-play-control.vjs-playing .vjs-icon-placeholder:before, .vjs-icon-pause:before {
  content: url("data:image/svg+xml,%3Csvg width='16' height='16' viewBox='0 0 16 16' fill='none' xmlns='http://www.w3.org/2000/svg'%3E%3Crect x='3.61885' y='2.06074' width='3.16185' height='11.88' rx='0.9' fill='black' stroke='%23EDEDED' stroke-width='0.6' stroke-linecap='round'/%3E%3Crect x='9.21797' y='2.06074' width='3.16185' height='11.88' rx='0.9' fill='black' stroke='%23EDEDED' stroke-width='0.6' stroke-linecap='round'/%3E%3C/svg%3E%0A");
  padding: 2px;
}

.vjs-error-display {
  display: none;
}

.ul-video-player-video {
  position: relative;
  top: 0;
  left: 0;
  width: 100%;
}

.ul-video-container {
  width: 100%;
  height: auto;
  left: 0px;
  top: 0px;

  background-color: transparent;
  border-radius: 4px;

  align-items: start;
  display: flex;
  flex-direction: column;

  /* Inside Auto Layout */

  flex: none;
  order: 0;
  flex-grow: 0;
  margin: 10px 0px;
  position: relative;
}

.vjs-record button.vjs-device-button.vjs-control {
  background: rgba(255, 255, 255, 96);
  width: 100%;
  height: 100%;
  left: 0;
  top: 0;
  margin: 0;
  border-radius: 0;
  line-height: 0.6;
  padding: 10px;
  display: flex;
  align-items: center;
  flex-direction: column;
  justify-content: center;
  z-index: 3;
}

.vjs-record .vjs-device-button.vjs-control:before {
  font-size: 14px !important;
  color: #333;
  content: "Your browser needs to access your camera and microphone for video recording";
  line-height: 135%;
}

.vjs-record .vjs-device-button.vjs-control.permission-denied:before {
  font-size: 16px !important;
  color: #262136;
  content: "Unable to access your camera and microphone";
}

.vjs-record .vjs-device-button.vjs-control:after {
  display: inline-block;
  background: #F0F0F5;
  font-size: 13px;
  border-radius: 4px;
  content: "Request Permissions";
  padding: 1em 2em;
  color: #333;
  margin-top: 20px;
}

.vjs-record .vjs-device-button.vjs-control.permission-denied:after {
  display: inline-block;
  background: white;
  font-size: 13px;
  content: "Please go to your browser settings and update permissions to enable recording";
  padding: 1em;
  color: #4B575D;
  margin: 5px;
  line-height: 135%;
  text-align: center;
}

.vjs-control.vjs-button.ul-video-recorder-delete-button, .vjs-control.vjs-button.ul-video-recorder-toggle-button, .vjs-control.vjs-button.ul-video-recorder-camera-off-button-audio-only, .vjs-control.vjs-button.ul-video-recorder-camera-off-button {
  cursor: pointer;
}

.ul-video-recorder-delete-button .vjs-icon-placeholder:before {
  content: url("data:image/svg+xml,%3Csvg width='16' height='16' viewBox='0 0 16 16' fill='none' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M9.21234 7.37549V11.1193M2.53931 4.25595H13.4593H2.53931ZM5.57234 4.25595V3.00833C5.57222 2.84433 5.60354 2.68192 5.6645 2.53038C5.72546 2.37884 5.81488 2.24115 5.92762 2.12519C6.04037 2.00922 6.17424 1.91726 6.32158 1.85456C6.46892 1.79185 6.62683 1.75964 6.78628 1.75977H9.21234C9.37179 1.75964 9.5297 1.79185 9.67703 1.85456C9.82437 1.91726 9.95824 2.00922 10.071 2.12519C10.1837 2.24115 10.2732 2.37884 10.3341 2.53038C10.3951 2.68192 10.4264 2.84433 10.4263 3.00833V4.25595H5.57234ZM12.2463 4.25595V12.9912C12.2463 13.3223 12.1184 13.6399 11.8907 13.8741C11.6631 14.1082 11.3543 14.2398 11.0323 14.2398H4.96628C4.64432 14.2398 4.33555 14.1082 4.10789 13.8741C3.88023 13.6399 3.75234 13.3223 3.75234 12.9912V4.25595H12.2463ZM6.78628 7.37549V11.1193V7.37549Z' stroke='black' stroke-width='1.5' stroke-linecap='round' stroke-linejoin='round'/%3E%3C/svg%3E%0A");
}

.ul-video-recorder-toggle-button .vjs-icon-placeholder:before {
  content: url("data:image/svg+xml,%3Csvg width='16' height='16' viewBox='0 0 16 16' fill='none' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M8 0C12.4183 0 16 3.58172 16 8C16 12.4183 12.4183 16 8 16C3.58172 16 0 12.4183 0 8C0 3.58172 3.58172 0 8 0Z' fill='%23D15153'/%3E%3C/svg%3E");
}

.ul-video-recorder-toggle-button.ul-recording-in-session .vjs-icon-placeholder:before {
  content: url("data:image/svg+xml,%3Csvg width='12' height='12' viewBox='0 0 12 12' fill='none' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M12 10L12 2C12 0.89543 11.1046 -4.85396e-07 10 -4.37114e-07L2 -8.74228e-08C0.89543 -3.91405e-08 -4.85396e-07 0.895431 -4.37114e-07 2L-8.74228e-08 10C-3.91405e-08 11.1046 0.895431 12 2 12L10 12C11.1046 12 12 11.1046 12 10Z' fill='%23D15153'/%3E%3C/svg%3E%0A");
}

.ul-video-recorder-camera-off-button .vjs-icon-placeholder:before {
  content: url("data:image/svg+xml,%3Csvg width='16' height='16' viewBox='0 0 16 16' fill='none' xmlns='http://www.w3.org/2000/svg'%3E%3Cg clip-path='url(%23clip0_2645_4654)'%3E%3Cpath d='M15.1491 4.75L10.5991 8L15.1491 11.25V4.75Z' stroke='black' stroke-width='1.5' stroke-linecap='round' stroke-linejoin='round'/%3E%3Cpath d='M9.29912 3.4502H2.14912C1.43115 3.4502 0.849121 4.03223 0.849121 4.7502V11.2502C0.849121 11.9682 1.43115 12.5502 2.14912 12.5502H9.29912C10.0171 12.5502 10.5991 11.9682 10.5991 11.2502V4.7502C10.5991 4.03223 10.0171 3.4502 9.29912 3.4502Z' stroke='black' stroke-width='1.5' stroke-linecap='round' stroke-linejoin='round'/%3E%3C/g%3E%3Cdefs%3E%3CclipPath id='clip0_2645_4654'%3E%3Crect width='15.6' height='15.6' fill='white' transform='translate(0.199951 0.200195)'/%3E%3C/clipPath%3E%3C/defs%3E%3C/svg%3E");
}

.ul-video-recorder-camera-off-button-audio-only .vjs-icon-placeholder:before {
  content: url("data:image/svg+xml,%3Csvg width='22' height='15' fill='none' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath fill-rule='evenodd' clip-rule='evenodd' d='M.75 3A2.75 2.75 0 013.5.25h9.081A2.75 2.75 0 0115.331 3v9a2.75 2.75 0 01-2.75 2.75H3.5A2.75 2.75 0 01.75 12V3zM3.5 1.75c-.69 0-1.25.56-1.25 1.25v9c0 .69.56 1.25 1.25 1.25h9.081c.69 0 1.25-.56 1.25-1.25V3c0-.69-.56-1.25-1.25-1.25H3.5z' fill='%23262136'/%3E%3Cpath fill-rule='evenodd' clip-rule='evenodd' d='M14.53 2.03l-12 12-1.06-1.06 12-12 1.06 1.06zM20.87 1.525a.75.75 0 01.38.652v10.588a.75.75 0 01-1.134.644l-5.92-3.53a.75.75 0 01-.365-.643v-3.53a.75.75 0 01.366-.644l5.919-3.53a.75.75 0 01.754-.007zm-5.539 4.607V8.81l4.419 2.635V3.497l-4.419 2.635z' fill='%23262136'/%3E%3C/svg%3E");
  transform: scale(0.75);
}

.ul-upload-progress-label {
  padding: 0.15em 0.75em;
  align-items: center;
  font-size: 12px;
  color: #333;
  background: #FCFCFD;
  border-radius: 99px;
  text-align: center;
  border: 1px solid #E0E0EB;
  display: flex;
  align-items: center;
  justify-content: center;
  position: absolute;
  bottom: 75px;
  left: calc(50% - 65px);
  width: 130px;
  z-index: 5;
}

.ul-upload-progress-label__time {
  display: inline-flex;
  margin-left: 0.8em;
  align-items: center;
}

.ul-upload-progress-label__time:before {
  content: "";
  display: inline-flex;
  width: 1px;
  height: 12px;
  background-color: #E0E0EB;
  margin-right: 0.8em;
}

@keyframes grow {
  0% {
    transform: scale(1);
    background-color: #EEECFC;
  }
  50%  {
    transform: scale(1.2);
    background-color: #E1DFF4;
  }
  100% {
    transform: scale(1);
    background-color: #EEECFC;
  }
}

.ul-audio-recorder-placeholder:before {
  width: 80px;
  height: 80px;
  border-radius: 120px;
  background-color: #EEECFC;
  content: "";
  position: absolute;
  left: calc(50% - 40px);
  top: calc(50% - 40px);
  animation: 6s infinite grow;
  transform-origin: 50% 60%;
}

.ul-audio-recorder-placeholder:after {
  content: url("data:image/svg+xml,%3Csvg width='98' height='98' fill='none' xmlns='http://www.w3.org/2000/svg'%3E%3Cmask id='a' maskUnits='userSpaceOnUse' x='0' y='0' width='98' height='98'%3E%3Ccircle cx='49' cy='49' r='49' fill='%23EDECF8'/%3E%3C/mask%3E%3Cg mask='url(%23a)'%3E%3Ccircle cx='49' cy='49' r='50' fill='%23645CC2'/%3E%3Cpath fill-rule='evenodd' clip-rule='evenodd' d='M11.422 81.812c5.405-15.547 20.187-26.706 37.576-26.706 17.39 0 32.172 11.159 37.577 26.707-9.164 10.43-22.601 17.013-37.576 17.013-14.976 0-28.414-6.583-37.577-17.014z' fill='%23fff' fill-opacity='.6'/%3E%3Ccircle cx='49' cy='29' r='17' fill='%23fff' fill-opacity='.7'/%3E%3C/g%3E%3C/svg%3E");
  position: absolute;
  left: 50%;
  top: 50%;
  transform: translate(-50%, -50%);
  transform: translate(-50%, -50%) scale(0.6);
}

.ul-audio-recorder-placeholder {
  min-height: 150px;
  width: 100%;
  background-color: #fcfcfd;
  display: block;
  position: relative;
}

.vjs-fullscreen .ul-audio-recorder-placeholder {
  vertical-align: middle;
  display: table-cell;
}

.vjs-fullscreen .ul-control-panel {
  height: 80px;
  position: absolute;
  bottom: 0;
  left: 0;
  width: 100%;
  max-width: 100%;
  background-color: #F8F8F8;
}

.vjs-playback-rate .vjs-playback-rate-value {
  align-items: center;
  display: flex;
  font-size: 12px;
  justify-content: center;
}

.vjs-playback-rate .vjs-menu {
  left: -5px;
  bottom: 3px;
}

.vjs-menu-button-popup .vjs-menu .vjs-menu-content {
  background-color: white;
  border: 1px solid rgba(0, 0, 0, 0.1);
  box-sizing: border-box;
  border-radius: 4px;
}

.vjs-menu li {
  font-size: 12px;
  padding: 5px 0;
}

.vjs-menu li.vjs-selected {
  color: lightgray;
}

.vjs-menu li.vjs-menu-item:hover {
  background-color: rgba(0, 0, 0, 0.05);
}

.vjs-fullscreen .ul-buttons-panel {
  top: calc(50% - 30px);
  position: relative;
}

.vjs-fullscreen .vjs-record-indicator.vjs-control {
  bottom: 90px !important;
}

.vjs-record.video-js div.vjs-control.vjs-record-indicator {
  padding: 0.3em 0.75em 0.15em 15px;
  align-items: center;
  font-size: 12px;
  color: #333;
  background: #FCFCFD;
  border-radius: 99px;
  text-align: center;
  border: 1px solid #E0E0EB;
  display: flex;
  justify-content: center;
  align-items: center;
  position: absolute;
  bottom: 75px;
  top: auto;
  left: calc(50% - 21px);
  width: 43px;
  height: 16px;
  z-index: 4;
}

.vjs-record.video-js div.vjs-control.vjs-record-indicator:after {
  content: "";
  background-color: #EB5757;
  width: 6px;
  height: 6px;
  border-radius: 8px;
  animation: none;
  top: 4px;
  left: 5px;
}

.vjs-record.video-js div.vjs-control.vjs-record-indicator:before {
  position: relative;
  font-size: 9px;
  animation: none;
  opacity: 1;
  color: #333;
  top: auto;
  left: auto;
}

.ul-video-player-loading {
  display: inline-block;
  position: relative;
  width: 6rem;
  height: 6rem;

}
.ul-video-player-loading div {
  box-sizing: border-box;
  position: absolute;
  display: block;
  width: 80%;
  height: 80%;
  margin: 5px;
  border: 5px solid #666;
  border-radius: 50%;
  animation: lds-ring 1.2s cubic-bezier(0.5, 0, 0.5, 1) infinite;
  border-color: #666 transparent transparent transparent;
}

.first {
  animation-delay: -0.45s;
}
.second {
  animation-delay: -0.3s;
}
.third {
  animation-delay: -0.15s;
}

@keyframes lds-ring {
  0% {
    transform: rotate(0deg);
  }
  100% {
    transform: rotate(360deg);
  }
}

.ul-video-btn {
  width: 100%;
  border: 1px solid #E6E6E6;
  border-radius: 4px;
  background-color: rgba(0, 0, 0, 0.02);
  padding: 8px;
  font-weight: 500;
  font-size: 15px;
}

.ul-record-response-btn:before, .ul-record-response-btn:after, .ul-back-question-btn:before, .ul-back-question-btn:after {
  margin: 0 5px;
  vertical-align: middle;
}

.ul-record-response-btn:before {
  content: url("data:image/svg+xml,%3Csvg width='16' height='16' viewBox='0 0 16 16' fill='none' xmlns='http://www.w3.org/2000/svg'%3E%3Cg clip-path='url(%23clip0_2645_4654)'%3E%3Cpath d='M15.1491 4.75L10.5991 8L15.1491 11.25V4.75Z' stroke='black' stroke-width='1.5' stroke-linecap='round' stroke-linejoin='round'/%3E%3Cpath d='M9.29912 3.4502H2.14912C1.43115 3.4502 0.849121 4.03223 0.849121 4.7502V11.2502C0.849121 11.9682 1.43115 12.5502 2.14912 12.5502H9.29912C10.0171 12.5502 10.5991 11.9682 10.5991 11.2502V4.7502C10.5991 4.03223 10.0171 3.4502 9.29912 3.4502Z' stroke='black' stroke-width='1.5' stroke-linecap='round' stroke-linejoin='round'/%3E%3C/g%3E%3Cdefs%3E%3CclipPath id='clip0_2645_4654'%3E%3Crect width='15.6' height='15.6' fill='white' transform='translate(0.199951 0.200195)'/%3E%3C/clipPath%3E%3C/defs%3E%3C/svg%3E");
  display: inline-block;
  transform: translate(0px, 2px);
}

.ul-record-response-btn:after {
  content: 'Record your Response';
}

.ul-back-question-btn:before {
  content: url("data:image/svg+xml,%3Csvg width='15' height='16' viewBox='0 0 15 16' fill='none' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M13.8757 8.22361L1.1118 14.6056C0.945578 14.6887 0.75 14.5678 0.75 14.382V1.61803C0.75 1.43219 0.945579 1.31131 1.1118 1.39443L13.8757 7.77639C14.06 7.86852 14.06 8.13148 13.8757 8.22361Z' stroke='black' stroke-width='1.5' stroke-linecap='round'/%3E%3C/svg%3E");
  display: inline-block;
  transform: scale(0.85) translate(0, 1px);
  -moz-transform: scale(0.85) translate(0, 2px);
}

.ul-back-question-btn:after {
  content: 'Back to Question';
}

.hidden {
  display: none !important;
  opacity: 0;
  visibility: hidden;
}

.visible {
  visibility: visible;
  opacity: 1;
  animation: fade 0.3s;
}

@keyframes fade {
  0% {
      opacity: 0;
  }

  100% {
      opacity: 1;
  }
}

#ul-recording-countdown-screen {
  width: 100%;
  height: 100%;
  color: black;
  background-color: rgba(255, 255, 255, 0.8);
  position: absolute;
  text-align: center;
  font-size: 15px;
  z-index: 1;
  display: table;
}

.ul-countdown-text {
  vertical-align: middle;
  display: table-cell;
  transform: translate(0, -25px);
}

.vjs-fullscreen > #ul-recording-countdown-screen {
  font-size: 25px;
  transform: unset;
}

.vjs-poster {
  background-size: cover;
}
`,
        um = e => {
            const t = M.document.createElement("div");
            return t.className = "ul-video-player-loading", t.id = zo(e), ["first", "second", "third", "fourth"].map(n => {
                const r = M.document.createElement("div");
                r.className = n, t.appendChild(r)
            }), t
        },
        zo = e => e + "-loading-spiner",
        se = "hidden",
        Ku = ".m3u8",
        Wo = "questionId",
        Yo = "ul-video-recorder-camera-off-button",
        Qo = "ul-recording-in-session",
        cm = [{
            type: "link",
            content: `${Bt}/dependencies/videojs-record-4.5.0.min.css`
        }, {
            type: "script",
            content: `${Bt}/dependencies/RecordRTC-5.6.2.js`
        }, {
            type: "script",
            content: `${Bt}/dependencies/adapter.8.0.0.min.js`
        }, {
            type: "script",
            content: `${Bt}/dependencies/videojs-record-4.5.0.min.js`
        }, {
            type: "script",
            content: `${Bt}/userleap-web-upchunk-v2.2.2.js`
        }],
        $u = [{
            type: "link",
            content: `${Bt}/dependencies/video-js-7.18.0.min.css`
        }, {
            type: "script",
            content: `${Bt}/dependencies/video-js-7.18.0.min.js`
        }, {
            type: "style",
            content: lm
        }],
        Gu = "-video-player",
        qu = "-secondary-video-player",
        zu = "-video-recorder";
    let $e, Wu;
    const bt = async ({
            event: e,
            apiBase: t,
            headers: n,
            visitorId: r,
            envId: i,
            metadata: o
        }) => {
            const a = M.document.documentElement;
            if (!r || !i) return;
            const s = {
                event: `SDK - ${e}`,
                visitorId: r,
                environmentId: i,
                metadata: { ...o || {},
                    screenWidth: window.screen.width,
                    screenHeight: window.screen.height,
                    clientWidth: a.clientWidth,
                    clientHeight: a.clientHeight,
                    location: window.location.href,
                    language: navigator.language
                }
            };
            (await fetch(`${t}/sdk/1/visitors/${r}/analytics`, {
                method: "POST",
                cache: "no-cache",
                headers: n,
                body: JSON.stringify(s)
            })).ok || console.warn("[Sprig] (ERR-444) Failed to track analytics", e)
        },
        lt = async (e, t, n, r, i, o) => {
            bt({
                event: `Video Error ${t}`,
                apiBase: n,
                headers: r,
                visitorId: i,
                envId: o,
                metadata: {
                    errorMessage: e.message
                }
            });
            const a = M.document.documentElement,
                s = {
                    screenWidth: window.screen.width,
                    screenHeight: window.screen.height,
                    clientWidth: a.clientWidth,
                    clientHeight: a.clientHeight,
                    location: window.location.href,
                    language: navigator.language
                },
                l = {
                    action: t,
                    err: {
                        message: e.message,
                        stack: e.stack
                    },
                    meta: s,
                    vid: i,
                    envId: o
                };
            (await fetch(`${n}/sdk/1/errors`, {
                method: "POST",
                cache: "no-cache",
                headers: { ...r,
                    "userleap-platform": "video_recorder",
                    "x-ul-error": window.btoa(`userleap-${Date.now()}-error`)
                },
                body: JSON.stringify(l)
            })).ok || console.warn("[Sprig] (ERR-444) Failed to report error to API", e)
        },
        dm = (e, {
            type: t,
            content: n
        }) => new Promise(function(r, i) {
            let o;
            t === "script" ? (o = M.document.createElement("script"), o.src = n) : t === "link" ? (o = M.document.createElement("link"), o.rel = "stylesheet", o.href = n, o.type = "text/css") : (o = M.document.createElement("style"), o.innerHTML = n), o.onload = function() {
                r(n)
            }, o.onerror = function() {
                i(n)
            }, o.async = !1, o.id = btoa(n), e.appendChild(o)
        }),
        Yu = (e, t) => {
            if (e.length === 0) return t && t();
            Promise.all(e.reduce((n, r) => (n.push(dm(M.document.head, r)), n), [])).then(() => {
                M.videojs = M.document.defaultView.videojs, t && t()
            }).catch(function(n) {
                console.log(n + " failed to load")
            })
        },
        Qu = (e, t, n) => {
            if (t === "start" && (e.style.visibility = "visible"), t === "none") e.style.visibility = se;
            else if (t === "success") e.style.visibility = se, e.innerHTML = "Upload succeeded!";
            else {
                const r = Math.round(parseFloat(n));
                e.innerHTML = `Uploading <span class="ul-upload-progress-label__time">${r}%</span>`, e.style.background = `linear-gradient(to right, #E0E0EB 0%, #E0E0EB ${r}%, #FCFCFD ${r}%, #FCFCFD 100%)`
            }
        },
        Zo = (e, t) => {
            const n = M.videojs(e.id());
            return n == null ? void 0 : n.payload[t]
        },
        fm = (e, t, n, r, i) => {
            const {
                surveyId: o,
                responseGroupUid: a,
                visitorId: s,
                envId: l
            } = e.payload;
            e.on("deviceError", function() {
                console.warn("device error: ", e.deviceErrorCode), e.deviceErrorCode.message === "Permission denied" ? (e.deviceButton.addClass("permission-denied"), n && n(H.ERROR, {
                    type: H.PERMISSION_DENIED
                }), bt({
                    event: "Video Permission Denied",
                    apiBase: t,
                    headers: i,
                    visitorId: s,
                    envId: l,
                    metadata: {
                        questionId: Zo(e, Wo),
                        responseGroupUid: a,
                        surveyId: o
                    }
                })) : (n && n(H.ERROR, {
                    type: H.OTHER
                }), lt(new Error(e.deviceErrorCode.message), "recorderDeviceError", t, i, s, l))
            }), e.on("error", function(u, c) {
                lt(c || e.error(), "recorderError", t, i, s, l)
            }), e.on("startRecord", function(u, c) {
                r(e.uploadProgressLabel, "none"), bt({
                    event: "Video Record Start",
                    apiBase: t,
                    headers: i,
                    visitorId: s,
                    envId: l,
                    metadata: {
                        questionId: Zo(e, Wo),
                        responseGroupUid: a,
                        surveyId: o
                    }
                })
            }), e.on("finishRecord", async function() {
                r(e.uploadProgressLabel, "start", 0);
                const u = Zo(e, Wo);
                if (!o) {
                    const v = "internal error: missing fields in payload";
                    return n && n(H.ERROR, {
                        type: H.OTHER
                    }), lt(new Error(v), "finishRecord", t, i, s, l), null
                }
                e.record().stopDevice();
                const c = e.cameraOff ? H.MEDIA_TYPE_AUDIO : H.MEDIA_TYPE_VIDEO,
                    f = ct();
                bt({
                    event: "Video Record Finish",
                    apiBase: t,
                    headers: i,
                    visitorId: s,
                    envId: l,
                    metadata: {
                        mediaRecordingUid: f,
                        questionId: u,
                        responseGroupUid: a,
                        surveyId: o,
                        mediaType: c
                    }
                });
                const d = {
                    surveyId: o,
                    updatedAt: new Date().toISOString(),
                    mediaType: c,
                    mediaRecordingUid: f
                };
                u && (d.questionId = u), a && (d.responseGroupUid = a), s && (d.visitorId = s);
                const h = await (async () => {
                    const v = await fetch(`${t}/2/environments/integrations/upload`, {
                        method: "POST",
                        cache: "no-cache",
                        headers: {
                            "Content-Type": "application/json"
                        },
                        body: JSON.stringify(d)
                    });
                    if (v.ok) {
                        const m = await v.json();
                        return n && n(H.UPLOAD_STARTED, {
                            [H.UPLOAD_ID]: m.upload.id,
                            [H.MEDIA_TYPE]: c,
                            [H.MEDIA_RECORDING_UID]: f
                        }), m.upload.url
                    } else return n && n(H.ERROR, {
                        type: H.OTHER,
                        response: v
                    }), lt(new Error("failed to get upload response with url"), "finishRecord", t, i, s, l), null
                })();
                !h || ($e = M.document.defaultView.UpChunk.createUpload({
                    endpoint: h,
                    file: new M.document.defaultView.File([e.recordedData], `recording ${c} ${Date.now()}`),
                    chunkSize: 5120
                }), $e.startTime = Date.now(), bt({
                    event: "Video Upload Start",
                    apiBase: t,
                    headers: i,
                    visitorId: s,
                    envId: l,
                    metadata: {
                        mediaRecordingUid: f,
                        questionId: u,
                        responseGroupUid: a,
                        surveyId: o,
                        mediaType: c,
                        url: h
                    }
                }), $e.on("error", v => {
                    r(e.uploadProgressLabel, "none"), n && n(H.UPLOAD_FINISHED, {
                        [H.MEDIA_RECORDING_UID]: f
                    }), lt(v, "finishRecord", t, i, s, l)
                }), $e.on("progress", v => {
                    n && n(H.UPLOAD_PROGRESS, {
                        [H.MEDIA_RECORDING_UID]: f,
                        [H.UPLOAD_PROGRESS_PCT]: v.detail
                    }), r(e.uploadProgressLabel, "progress", v.detail)
                }), $e.on("success", () => {
                    r(e.uploadProgressLabel, "success"), n && n(H.UPLOAD_FINISHED, {
                        [H.MEDIA_RECORDING_UID]: f
                    }), bt({
                        event: "Video Upload Success",
                        apiBase: t,
                        headers: i,
                        visitorId: s,
                        envId: l,
                        metadata: {
                            mediaRecordingUid: f,
                            questionId: u,
                            responseGroupUid: a,
                            surveyId: o,
                            mediaType: c,
                            url: h,
                            elapsedMs: $e.startTime && Date.now() - $e.startTime
                        }
                    })
                }))
            })
        },
        Zu = (e, t) => {
            const n = new(M.videojs.getComponent("Component"))(e);
            return n.addClass("ul-buttons-panel"), t.map(r => {
                n.addChild(r)
            }), pm(n), n
        },
        pm = e => {
            e.children().forEach(t => {
                if (De[t.name_]) {
                    const n = Zr(De[t.name_], `ul-${De[t.name_]}`);
                    t.el_.appendChild(n)
                }
            })
        },
        Zr = (e, t = "") => {
            const n = M.document.createElement("span");
            return n.className = "ul-button-text", n.innerHTML = e, n.id = t, n
        },
        Xu = (e, t, n, r, i = !1, o) => {
            e.addClass("ul-video-player");
            const a = new(M.videojs.getComponent("Component"))(e);
            a.addClass("ul-control-panel"), e.progressBar = a.addChild("ProgressControl"), n && e.src(n), e.audioPlayerPlaceholder = new(M.videojs.getComponent("Component"))(e), e.audioPlayerPlaceholder.addClass("ul-audio-recorder-placeholder");
            const s = n && n.src ? bm(n.src) : null;
            n && (i || !s) ? (e.children()[0].classList.add("vjs-hidden"), M.document.getElementById(`${e.id()}_html5_api`).style.height = "0px") : (e.audioPlayerPlaceholder.hide(), M.document.getElementById(`${e.id()}_html5_api`).style.height = "100%", s && e.poster(s)), e.on("play", () => {
                !i && n && !s && mm(e, !1), o == null || o.play()
            }), e.on("pause", () => {
                o == null || o.pause()
            }), e.on("seeked", () => {
                o == null || o.currentTime(e.currentTime())
            }), e.on("ratechange", () => {
                o == null || o.playbackRate(e.playbackRate())
            }), e.addChild(e.audioPlayerPlaceholder, {}, 1), a.addChild(t), e.addChild(a), r && r(e)
        },
        hm = (e, t, n) => {
            e.addClass(`ul${qu}`);
            const r = new(M.videojs.getComponent("Component"))(e);
            t && e.src(t), e.addChild(r), n && n(e)
        },
        vm = (e, t, n, r, i, o, a, s = !1) => {
            Wu = Date.now();
            const u = Xr(t, {
                controls: !1,
                bigPlayButton: !1,
                fluid: !1,
                width: 1280,
                height: 720,
                playsinline: !0,
                plugins: {
                    record: {
                        audio: !0,
                        video: {
                            mandatory: {
                                minWidth: 1280,
                                minHeight: 720
                            }
                        },
                        frameWidth: 1280,
                        frameHeight: 720,
                        maxLength: 600,
                        autoMuteDevice: !0
                    }
                }
            });
            if (!u) return;
            u.payload = n;
            const {
                surveyId: c,
                questionId: f,
                responseGroupUid: d,
                visitorId: p,
                envId: h
            } = n;
            let v;
            const m = T => {
                    const U = Yo,
                        S = Yo + "-audio-only";
                    Qu(u.uploadProgressLabel, "none"), $e && $e.startTime >= Wu && $e.abort();
                    const V = M.document.getElementById("ul-camera-button");
                    T ? (u.children()[0].classList.add("vjs-hidden"), b.removeClass(U), b.addClass(S), V.innerHTML = De.TurnOnCamera, u.audioPlayerPlaceholder.removeClass("vjs-hidden"), v == null || v.getTracks().forEach(D => {
                        D.stop()
                    }), window.navigator.mediaDevices.getUserMedia({
                        video: !0,
                        audio: !0
                    }).then(D => {
                        v = D, D.getVideoTracks().forEach(X => {
                            X.enabled = !1
                        }), u.record().onDeviceReady(D)
                    }).catch(u.record().onDeviceError.bind(u.record()))) : (v == null || v.getVideoTracks().forEach(D => {
                        D.enabled = !0
                    }), u.children()[0].classList.remove("vjs-hidden"), u.record().getDevice(), b.removeClass(S), b.addClass(U), V.innerHTML = De.TurnOffCamera, u.audioPlayerPlaceholder.addClass("vjs-hidden"))
                },
                y = new(M.videojs.getComponent("Button"))(u, {
                    clickHandler: () => {
                        y.hasClass(se) || (bt({
                            event: "Video Delete Button Clicked",
                            apiBase: r,
                            headers: a,
                            visitorId: p,
                            envId: h,
                            metadata: {
                                questionId: f,
                                responseGroupUid: d,
                                surveyId: c
                            }
                        }), m(u.cameraOff), i(H.DELETE, {}), b.removeClass(se), y.addClass(se))
                    }
                });
            y.addClass("ul-video-recorder-delete-button"), y.el_.appendChild(Zr(De.DeleteButton, "ul-delete-button"));
            const _ = M.document.getElementById(t),
                E = () => {
                    _.classList.contains("vjs-fullscreen") && u.cameraOff ? _.style.display = "table" : _.style.display = "flex"
                };
            E();
            const b = new(M.videojs.getComponent("Button"))(u, {
                clickHandler: () => {
                    u.record().isRecording() || (u.cameraOff = !u.cameraOff, bt({
                        event: "Video Camera Button Clicked",
                        apiBase: r,
                        headers: a,
                        visitorId: n.visitorId,
                        envId: n.envId,
                        metadata: {
                            questionId: f,
                            responseGroupUid: d,
                            surveyId: c,
                            cameraOff: u.cameraOff
                        }
                    }), m(u.cameraOff), !y.hasClass(se) && y.addClass(se), i(H.DELETE, {}), E())
                }
            });
            b.addClass(Yo), b.el_.appendChild(Zr(De.TurnOffCamera, "ul-camera-button"));
            const w = new(M.videojs.getComponent("Button"))(u, {
                clickHandler: () => {
                    const T = M.document.getElementById("ul-recorder-toggle");
                    if (u.record().isRecording()) u.record().stop(), T && (T.innerHTML = De.RecordButton), w.removeClass(Qo), y.removeClass(se);
                    else {
                        const U = M.document.getElementById("ul-recording-countdown-screen");
                        if (U) U.remove(), T && (T.innerHTML = De.RecordButton), m(u.cameraOff), i(H.DELETE, {}), b.removeClass(se), y.addClass(se), w.removeClass(Qo), I.show();
                        else {
                            w.addClass(Qo), I.hide(), b.addClass(se), y.addClass(se), T && (T.innerHTML = De.StopButton);
                            const S = M.document.createElement("div");
                            S.id = "ul-recording-countdown-screen", _.insertBefore(S, _.children[1]), S.style.height = `${_.offsetHeight}px`, Ju(u, 3)
                        }
                    }
                }
            });
            w.addClass("ul-video-recorder-toggle-button"), w.el_.appendChild(Zr(De.RecordButton, "ul-recorder-toggle"));
            const x = M.document.createElement("p");
            x.style.visibility = "hidden", x.className = "ul-upload-progress-label", e.appendChild(x), u.uploadProgressLabel = x;
            const C = Zu(u, [y, b, "PlayToggle", w, "FullscreenToggle"]),
                I = C.children().find(T => T.name_ === "FullscreenToggle");
            I.hasClass("vjs-disabled") && I.hide();
            const k = C.children().find(T => T.name_ === "PlayToggle");
            k.hide(), o && b.addClass(se), !o && y.addClass(se), Xu(u, C, o, !1, s), u.on("stopRecord", () => {
                w.hide(), k.show(), I.show(), y.removeClass(se)
            }), u.on("deviceReady", () => {
                w.show(), k.hide(), y.addClass(se)
            }), fm(u, r, i, Qu, a), o && (u.deviceButton && u.deviceButton.hide(), u.src(o), k.show(), w.hide(), y.removeClass(se));
            const L = [{
                name: "microphone"
            }];
            !u.cameraOff && L.push({
                name: "camera"
            }), Promise.all(L.map(T => {
                var U;
                return (U = navigator == null ? void 0 : navigator.permissions) == null ? void 0 : U.query(T)
            })).then(T => {
                T.reduce((S, V) => S & V.state === "granted", !0) && u && (u.deviceButton && u.deviceButton.hide(), !o && u.record().getDevice())
            }).catch(T => {})
        },
        Ju = (e, t = 3) => {
            const n = M.document.getElementById("ul-recording-countdown-screen");
            n && t === 0 ? (n.remove(), e.record().start()) : n && (n.innerHTML = `<span class='ul-countdown-text'>Recording in... ${t}</span>`, setTimeout(() => {
                Ju(e, t - 1)
            }, 1e3))
        },
        ec = e => {
            const t = M.document.createElement("div");
            return t.className = "ul-video-container", t.appendChild(um(e)), t
        },
        Xo = (e, t) => {
            const n = M.document.createElement("video");
            n.id = e, n.className = "video-js vjs-default-skin ul-video-player-video";
            const r = M.document.createElement("p");
            r.className = "vjs-no-js", r.innerHTML = "To view this video please enable JavaScript, and consider upgrading to a web browser that";
            const i = M.document.createElement("a");
            return i.href = "https://videojs.com/html5-video-support/", i.target = "_blank", i.innerHTML = "supports HTML5 video", r.appendChild(i), n.appendChild(r), t.appendChild(n), t
        },
        mm = (e, t) => {
            t ? (e.children()[0].classList.add("vjs-hidden"), e.audioPlayerPlaceholder.show(), M.document.getElementById(`${e.id()}_html5_api`).style.height = "0px") : (e.children()[0].classList.remove("vjs-hidden"), e.audioPlayerPlaceholder.hide(), M.document.getElementById(`${e.id()}_html5_api`).style.height = "100%")
        },
        Xr = (e, t) => M.document.getElementById(e) ? t ? M.videojs(e, t) : M.videojs(e) : (console.error(`Error in finding player element with ID, ${e}`), null),
        gm = (e, t, n, r = !1, i = "https://api.sprig.com", o = document, a = null, s = null) => {
            M.document = o;
            const l = e + Gu,
                u = ec(l);
            return M.document.addEventListener("securitypolicyviolation", c => {
                lt(new Error(`Voice & Video feature violates ${c.violatedDirective} web page CSP policies for the question player.`), "playerDeviceError", i, {})
            }), Yu($u, () => {
                M.document.getElementById(zo(l)).remove(), Xo(l, u);
                const c = {
                    playsinline: !0,
                    playbackRates: [.5, 1, 1.5, 2],
                    fill: !0
                };
                try {
                    const f = e + qu;
                    Xo(f, u);
                    const d = Xr(l, c),
                        p = Xr(f, {
                            muted: !0,
                            ...c
                        });
                    if (!d || !p) return;
                    hm(p, a, s), a || p.addClass(se);
                    const h = Zu(d, ["PlaybackRateMenuButton", "PlayToggle", "FullscreenToggle"]),
                        v = h.children().find(m => m.name_ === "FullscreenToggle");
                    v.hasClass("vjs-disabled") && v.hide(), Xu(d, h, t, n, r, p)
                } catch (f) {
                    lt(new Error(`Error when creating video player object ${f}`), "playerDeviceError", i, {});
                    return
                }
            }), u
        },
        _m = (e, t = {}, n = "https://api.userleap.com", r, i, o, a = !1, s = document) => {
            M.document = s;
            const l = e + zu,
                u = ec(l);
            return M.document.addEventListener("securitypolicyviolation", c => {
                lt(new Error(`Voice & Video feature violates ${c.violatedDirective} web page CSP policies for the recorder player.`), "recorderDeviceError", n, o, t.visitorId, t.envId)
            }), Yu($u.concat(cm), () => {
                Xo(l, u), M.document.getElementById(zo(l)).remove();
                try {
                    vm(u, l, t, n, r, i, o, a)
                } catch (c) {
                    lt(new Error(`Error when creating video recorder player object ${c}`), "recorderDeviceError", n, o, t.visitorId, t.envId);
                    return
                }
            }), u
        },
        ym = e => {
            const t = e + zu;
            if (!!M.document.getElementById(t) && !!M.videojs) {
                try {
                    if (!M.videojs(t).record().stream) return
                } catch {
                    return
                }
                M.videojs(t).record().stop(), M.videojs(t).record().stopDevice()
            }
        },
        wm = e => {
            const t = Xr(e + Gu);
            t == null || t.pause()
        },
        bm = e => {
            if (!e) return null;
            const t = e.match(/https:\/\/stream.mux.com\/(.*)/);
            let n = t ? t[1] : null;
            return n.includes(Ku) && (n = n.replace(Ku, "")), n ? `https://image.mux.com/${n}/thumbnail.jpg?time=0` : null
        },
        H = {
            UPLOAD_STARTED: "upload.started",
            UPLOAD_PROGRESS: "upload.progress",
            UPLOAD_FINISHED: "upload.finished",
            DELETE: "delete",
            ERROR: "error",
            MEDIA_TYPE: "media.type",
            PERMISSION_DENIED: "permission_denied",
            OTHER: "other",
            UPLOAD_ID: "upload.id",
            UPLOAD_PROGRESS_PCT: "upload.progress.pct",
            MEDIA_RECORDING_UID: "media.recording.uid",
            MEDIA_TYPE_VIDEO: "video",
            MEDIA_TYPE_AUDIO: "audio"
        },
        De = {
            PlaybackRateMenuButton: "Speed",
            PlayToggle: "Play",
            FullscreenToggle: "Expand",
            TurnOnCamera: "Turn on",
            TurnOffCamera: "Turn off",
            DeleteButton: "Delete",
            RecordButton: "Record",
            StopButton: "Stop",
            PauseButton: "Pause"
        },
        zn = "ul-card-video__player_recorder",
        Em = "ul-card-video__skip_button",
        xm = "ul-video-interview-form",
        tc = "ul-video-btn",
        Cm = ({
            className: e,
            message: t,
            next: n,
            properties: r,
            questionId: i,
            type: o
        }) => {
            const {
                apiURL: a,
                envId: s,
                handleUploadUpdate: l,
                headers: u,
                responseGroupUid: c,
                surveyId: f,
                viewDocument: d,
                visitorId: p
            } = ee(S => ({
                apiURL: S.apiURL,
                envId: S.envId,
                handleUploadUpdate: S.handleUploadUpdate,
                headers: S.headers,
                responseGroupUid: S.responseGroupUid,
                surveyId: S.surveyId,
                viewDocument: S.viewDocument,
                visitorId: S.userId
            })), [h, v] = ue(!1), [m, y] = ue(null), [_, E] = ue(null), [b, w] = ue(0), x = u["userleap-platform"], C = r && r.videoUrl, I = (S, V) => {
                S === H.UPLOAD_STARTED ? (y(V[H.UPLOAD_ID]), E(V[H.MEDIA_RECORDING_UID]), v(!0)) : S === H.DELETE ? (y(null), E(null), v(!1)) : S === H.UPLOAD_PROGRESS ? isNaN(V[H.UPLOAD_PROGRESS_PCT]) ? l({
                    mediaRecordingUid: V[H.MEDIA_RECORDING_UID],
                    isComplete: !0
                }) : l({
                    mediaRecordingUid: V[H.MEDIA_RECORDING_UID],
                    progressPct: V[H.UPLOAD_PROGRESS_PCT]
                }) : S === H.UPLOAD_FINISHED && l({
                    mediaRecordingUid: V[H.MEDIA_RECORDING_UID],
                    isComplete: !0
                })
            }, k = S => {
                if (S && S.children.length === 0) {
                    const V = gm(zn, {
                        src: C,
                        type: "application/x-mpegURL"
                    }, void 0, r.mediaType === H.MEDIA_TYPE_AUDIO, a, d);
                    S.appendChild(V)
                }
            }, L = S => {
                if (S && S.children.length === 0) {
                    const V = _m(zn, {
                        surveyId: f,
                        responseGroupUid: c,
                        questionId: i,
                        visitorId: p,
                        envId: s
                    }, a, I, void 0, { ...u,
                        "x-ul-video-recorder-origin": "sdk"
                    }, r.mediaType === H.MEDIA_TYPE_AUDIO, d);
                    S.appendChild(V)
                }
            }, T = S => {
                S.preventDefault(), S.stopPropagation(), ym(zn), m && _ ? (l({
                    mediaRecordingUid: _,
                    isSubmitted: !0
                }), n({
                    value: {
                        mediaRecordingUid: _
                    },
                    questionId: i,
                    type: o
                })) : n({
                    value: null,
                    questionId: i,
                    type: o
                })
            }, U = () => g(yt, {
                defaultBody: () => g("button", {
                    className: `${tc} ul-record-response-btn`,
                    onClick: S => {
                        S.preventDefault(), S.stopPropagation(), wm(zn), w(1)
                    }
                }),
                properties: r
            });
            return g("div", {
                className: F(Me(A.CardMainContent, x)),
                style: {
                    marginTop: "unset"
                },
                children: g("form", {
                    className: F([e, A.VideoCard, A.FadeInTransition]),
                    id: xm,
                    children: [g(He, {
                        message: t,
                        properties: r
                    }), g("div", {
                        id: "ul-card-voice__video",
                        children: [g("div", {
                            children: [g("div", {
                                id: "ul-question-player-container",
                                style: {
                                    display: b === 0 ? "" : "none"
                                },
                                children: [g("div", {
                                    id: zn,
                                    ref: k
                                }), U()]
                            }), g("div", {
                                style: {
                                    display: b === 1 ? "block" : "none"
                                },
                                children: [g("button", {
                                    className: `${tc} ul-back-question-btn`,
                                    onClick: S => {
                                        S.preventDefault(), S.stopPropagation(), w(0)
                                    }
                                }), g("div", {
                                    id: "ul-recorder-player-container",
                                    ref: L
                                })]
                            })]
                        }), g(we, {
                            disabled: !h,
                            onClick: T,
                            children: hn(r)
                        }), g("button", {
                            className: `ul-card-text__button ${A.InactiveButton}`,
                            id: Em,
                            onClick: T,
                            style: {
                                display: r.required ? "none" : "block",
                                ...h ? {
                                    display: "none"
                                } : {}
                            },
                            children: Ho(r)
                        })]
                    })]
                })
            })
        },
        Sm = ({
            className: e
        }) => {
            const {
                headers: t,
                uploadProgress: n
            } = ee(a => ({
                headers: a.headers,
                uploadProgress: a.uploadProgress
            }));
            let r, i;
            Object.values(n).filter(a => a.isSubmitted).length > 1 ? (r = "Your responses are processing", i = "Please keep this tab open until your responses are fully processed.") : (r = "Your response is processing", i = "Please keep this tab open until your response is fully processed.");
            const o = Math.round(Math.min(99, ...Object.values(n).filter(a => a.isSubmitted).map(a => a.progressPct)));
            return g("div", {
                className: F(Me(A.CardMainContent, t["userleap-platform"])),
                children: g("div", {
                    className: F([e, "ul-card--uploading", A.FadeInTransition]),
                    children: [g("div", {
                        "aria-busy": "true",
                        "aria-label": "Processing...",
                        "aria-live": "polite",
                        className: A.LoadingSpinnerContainer,
                        role: "progressbar",
                        children: g("div", {
                            className: A.LoadingSpinner,
                            children: [g("div", {
                                className: A.LoadingSpinnerFirst
                            }), g("div", {
                                className: A.LoadingSpinnerSecond
                            }), g("div", {
                                className: A.LoadingSpinnerThird
                            }), g("div", {
                                className: A.LoadingSpinnerFourth
                            })]
                        })
                    }), g(He, {
                        message: `${r} (${o}% complete)`
                    }), g("p", {
                        className: A.Caption,
                        children: i
                    })]
                })
            })
        },
        nc = () => g("svg", {
            alt: "Powered by Sprig",
            fill: "none",
            height: "13",
            viewBox: "0 0 100 13",
            width: "100",
            xmlns: "http://www.w3.org/2000/svg",
            children: [g("path", {
                d: "M3.0369 0.839981H0.0249023V8.99998H1.3209V6.53998H2.8569C4.8969 6.53998 6.2409 5.37598 6.2409 3.62398C6.2409 1.95598 4.9689 0.839981 3.0369 0.839981ZM3.0009 5.35198H1.3209V2.02798H3.0009C4.1769 2.02798 4.9689 2.67598 4.9689 3.62398C4.9689 4.65598 4.1769 5.35198 3.0009 5.35198Z",
                fill: "#5D696F"
            }), g("path", {
                d: "M9.90653 3.21598C8.15453 3.21598 6.90653 4.45198 6.90653 6.17998C6.90653 7.90798 8.15453 9.14398 9.90653 9.14398C11.6585 9.14398 12.9065 7.90798 12.9065 6.17998C12.9065 4.45198 11.6585 3.21598 9.90653 3.21598ZM9.90653 8.01598C8.88653 8.01598 8.15453 7.23598 8.15453 6.17998C8.15453 5.11198 8.88653 4.34398 9.90653 4.34398C10.9265 4.34398 11.6585 5.11198 11.6585 6.17998C11.6585 7.23598 10.9265 8.01598 9.90653 8.01598Z",
                fill: "#5D696F"
            }), g("path", {
                d: "M20.9631 3.35998L19.7391 7.11598L18.3951 3.35998H17.3271L15.9831 7.12798L14.7591 3.35998H13.4151L15.4431 8.99998H16.5351L17.8671 5.08798L19.1871 8.99998H20.2791L22.3071 3.35998H20.9631Z",
                fill: "#5D696F"
            }), g("path", {
                d: "M25.7246 3.21598C24.0086 3.21598 22.8206 4.51198 22.8206 6.17998C22.8206 7.85998 24.0206 9.14398 25.7966 9.14398C27.0206 9.14398 28.0166 8.54398 28.3766 7.52398H27.0086C26.7806 7.88398 26.3606 8.05198 25.8086 8.05198C24.7526 8.05198 24.2126 7.40398 24.0926 6.55198H28.5206C28.7606 4.64398 27.5966 3.21598 25.7246 3.21598ZM25.7366 4.27198C26.6126 4.27198 27.2126 4.76398 27.2846 5.68798H24.1166C24.2606 4.89598 24.8006 4.27198 25.7366 4.27198Z",
                fill: "#5D696F"
            }), g("path", {
                d: "M31.1297 4.12798V3.35998H29.8817V8.99998H31.1297V5.44798C31.6337 4.78798 32.3177 4.45198 33.2177 4.41598V3.23998C32.3537 3.23998 31.6457 3.56398 31.1297 4.12798Z",
                fill: "#5D696F"
            }), g("path", {
                d: "M36.8222 3.21598C35.1062 3.21598 33.9182 4.51198 33.9182 6.17998C33.9182 7.85998 35.1182 9.14398 36.8942 9.14398C38.1182 9.14398 39.1142 8.54398 39.4742 7.52398H38.1062C37.8782 7.88398 37.4582 8.05198 36.9062 8.05198C35.8502 8.05198 35.3102 7.40398 35.1902 6.55198H39.6182C39.8582 4.64398 38.6942 3.21598 36.8222 3.21598ZM36.8342 4.27198C37.7102 4.27198 38.3102 4.76398 38.3822 5.68798H35.2142C35.3582 4.89598 35.8982 4.27198 36.8342 4.27198Z",
                fill: "#5D696F"
            }), g("path", {
                d: "M45.4886 0.47998V3.80398C45.0086 3.43198 44.3966 3.21598 43.6766 3.21598C42.0926 3.21598 40.8206 4.53598 40.8206 6.16798C40.8206 7.82398 42.0926 9.14398 43.6766 9.14398C44.3966 9.14398 45.0086 8.92798 45.4886 8.54398V8.99998H46.7246V0.47998H45.4886ZM43.8566 8.01598C42.8246 8.01598 42.0686 7.17598 42.0686 6.16798C42.0686 5.17198 42.8246 4.34398 43.8566 4.34398C44.4806 4.34398 45.0686 4.55998 45.4886 5.15998V7.18798C45.0686 7.79998 44.4806 8.01598 43.8566 8.01598Z",
                fill: "#5D696F"
            }), g("path", {
                d: "M54.6797 3.21598C53.9597 3.21598 53.3477 3.43198 52.8797 3.79198V0.47998H51.6317V8.99998H52.8797V8.55598C53.3477 8.92798 53.9597 9.14398 54.6797 9.14398C56.2637 9.14398 57.5477 7.82398 57.5477 6.16798C57.5477 4.53598 56.2637 3.21598 54.6797 3.21598ZM54.4997 8.01598C53.8757 8.01598 53.2997 7.79998 52.8797 7.21198V5.13598C53.2997 4.54798 53.8757 4.34398 54.4997 4.34398C55.5437 4.34398 56.2997 5.17198 56.2997 6.16798C56.2997 7.17598 55.5437 8.01598 54.4997 8.01598Z",
                fill: "#5D696F"
            }), g("path", {
                d: "M63.3347 3.34798L61.3907 7.76398L59.2667 3.34798H57.9347L60.8147 9.08398L59.6267 11.784H60.9347L64.6547 3.34798H63.3347Z",
                fill: "#5D696F"
            }), g("path", {
                d: "M71.1466 4.34661C69.8092 4.05038 69.131 3.53001 69.131 2.80065C69.131 2.04705 69.8546 1.47822 70.8142 1.47822C71.8034 1.47822 72.5496 2.10339 72.5496 2.9321V2.99813H73.9165V2.9321C73.9165 1.41764 72.5883 0.272705 70.8271 0.272705C69.9784 0.272705 69.2009 0.533191 68.6379 1.0057C68.3584 1.23619 68.1339 1.52487 67.9805 1.8511C67.8271 2.17733 67.7486 2.53303 67.7506 2.89273C67.7451 3.22255 67.8137 3.54949 67.9515 3.84994C68.0894 4.15038 68.293 4.41686 68.5478 4.63012C69.0218 5.04266 69.6945 5.34798 70.5463 5.5388C71.9806 5.85502 72.7078 6.39296 72.7078 7.13686C72.7078 7.94316 71.9156 8.55076 70.8682 8.55076C69.7804 8.55076 68.9599 7.87531 68.9599 6.97996V6.91393H67.5918V6.97996C67.5918 8.56348 68.9942 9.75688 70.8535 9.75688C71.7426 9.75688 72.5588 9.48731 73.1518 8.99662C73.446 8.75831 73.6827 8.4581 73.8445 8.1179C74.0063 7.7777 74.0891 7.40611 74.087 7.03024C74.087 5.6854 73.0991 4.78217 71.1466 4.34661Z",
                fill: "#5D696F"
            }), g("path", {
                d: "M78.7986 2.50806C78.2874 2.50175 77.7823 2.6176 77.3263 2.84576C76.8703 3.07391 76.4768 3.40759 76.1795 3.81837V2.66738H74.8789V12.0752H76.1795V8.48716C76.4768 8.8979 76.8703 9.23152 77.3263 9.45957C77.7824 9.68763 78.2875 9.80335 78.7986 9.79687C80.8167 9.79687 82.3381 8.23031 82.3381 6.15246C82.3381 4.07462 80.8167 2.50806 78.7986 2.50806ZM80.9835 6.42264C80.9316 6.9629 80.6921 7.46879 80.3056 7.8544C79.919 8.24001 79.4093 8.48156 78.863 8.53804C78.1369 8.61074 77.4605 8.40295 76.9583 7.95407C76.4561 7.50518 76.1795 6.86365 76.1795 6.15246C76.1795 4.7846 77.2122 3.75295 78.5815 3.75295C79.2904 3.75295 79.9306 4.02191 80.3776 4.51018C80.8387 5.01116 81.054 5.69025 80.9835 6.42264Z",
                fill: "#5D696F"
            }), g("path", {
                d: "M98.2908 2.6692V3.80747C97.6776 2.97875 96.7302 2.50806 95.6583 2.50806C93.6482 2.50806 92.1323 4.04615 92.1323 6.08582C92.1323 8.1255 93.6482 9.66299 95.6583 9.66299C96.7345 9.66299 97.6819 9.19714 98.2908 8.37691V8.55198C98.2908 9.96891 97.3906 10.8843 95.9974 10.8843C95.0561 10.8843 94.2718 10.4766 93.8996 9.79384L93.8806 9.7587H92.5389L92.5695 9.84654C92.7961 10.514 93.2392 11.0889 93.8303 11.4822C94.4233 11.8723 95.1726 12.0783 95.9974 12.0783C97.0552 12.0783 97.9554 11.7451 98.6017 11.1157C99.2481 10.4862 99.5915 9.6012 99.5915 8.56773V2.6692H98.2908ZM97.5611 7.842C97.0092 8.36418 96.2225 8.58348 95.4001 8.44294C94.9132 8.35796 94.4664 8.12184 94.1245 7.76889C93.7827 7.41593 93.5636 6.96452 93.4992 6.48019C93.3833 5.66541 93.631 4.89364 94.1786 4.36418C94.6383 3.92741 95.2542 3.68788 95.8919 3.69782C96.0464 3.69795 96.2006 3.71031 96.3531 3.73477C97.3459 3.89349 98.1314 4.70403 98.2632 5.71024C98.3749 6.53835 98.1179 7.31436 97.5611 7.842Z",
                fill: "#5D696F"
            }), g("path", {
                d: "M90.705 0.0995975C90.4602 0.046773 90.2043 0.0911971 89.9925 0.223269C89.7806 0.35534 89.6299 0.564452 89.5729 0.805409C89.5159 1.04637 89.5571 1.29982 89.6877 1.51098C89.8183 1.72215 90.0277 1.87407 90.2708 1.93391C90.3415 1.94954 90.4136 1.95747 90.486 1.95754C90.72 1.9579 90.9458 1.87325 91.1206 1.71973C91.2955 1.5662 91.407 1.35452 91.4341 1.125C91.4611 0.89547 91.4017 0.664135 91.2673 0.475046C91.1329 0.285958 90.9327 0.152325 90.705 0.0995975V0.0995975Z",
                fill: "#5D696F"
            }), g("path", {
                d: "M89.8366 8.39143H88.715C87.9178 8.39143 87.4389 7.85531 87.4389 6.95693C87.4389 6.08096 87.8681 5.03659 88.7432 3.76444L88.7548 3.74748V3.38825L85.0271 2.86727C85.0284 2.71553 84.9886 2.56622 84.9118 2.43478C84.8351 2.30335 84.7241 2.19458 84.5905 2.11973C84.2563 1.938 83.8908 1.938 83.5879 2.11368C83.4361 2.2023 83.3122 2.33077 83.23 2.4848C83.1477 2.63884 83.1103 2.8124 83.1219 2.98618C83.1336 3.15996 83.1938 3.32714 83.2958 3.46914C83.3979 3.61114 83.5379 3.72238 83.7001 3.79049L82.5405 9.63753H83.8283L84.8977 4.08551L86.9115 4.42111C86.3701 5.38007 86.0953 6.27421 86.0953 7.07869C86.0953 8.56347 87.0041 9.53576 88.4734 9.62965V9.63753H91.1341V2.69099H89.8366V8.39143Z",
                fill: "#5D696F"
            })]
        }),
        Im = () => {
            const {
                border: e,
                cards: t,
                headers: n,
                index: r,
                marketingUrl: i,
                showSurveyBrand: o,
                slugName: a,
                surveyId: s,
                viewedCardCount: l
            } = ee(v => ({
                border: v.border,
                cards: v.cards,
                headers: v.headers,
                index: v.index,
                marketingUrl: v.marketingUrl,
                showSurveyBrand: v.showSurveyBrand,
                slugName: v.slugName,
                surveyId: v.surveyId,
                viewedCardCount: v.viewedCardCount
            })), u = _t(null), c = t.filter(v => v.type !== R.Uploading && v.type !== R.Thanks), f = Rv(t, r), d = l + 1, p = d / (d + f);
            Ie(() => {
                u.current && (u.current.style.width = `${p*100}%`)
            }, [p]);
            const h = () => o ? g("a", {
                href: `${i}?utm_source=survey_branding&utm_medium=website&utm_campaign=${a}&utm_content=${s}`,
                rel: "noreferrer",
                style: {
                    display: "block",
                    margin: "5px 0"
                },
                target: "_blank",
                children: g(nc, {})
            }) : null;
            return !c || c.length === 1 ? g("footer", {
                className: "ul-footer",
                style: o ? {} : {
                    marginBottom: "10px"
                },
                children: h()
            }) : g("footer", {
                className: `ul-footer ${n["userleap-platform"]==="link"?"ul-footer__link":""}`,
                children: [c.length > 1 && g("div", {
                    id: "ul-progress-bar-container",
                    children: g("div", {
                        id: "ul-progress-bar-current",
                        ref: u,
                        style: {
                            border: `1px solid ${e||"#000"}`
                        }
                    })
                }), o && g("a", {
                    href: `${i}?utm_source=survey_branding&utm_medium=website&utm_campaign=${a}&utm_content=${s}`,
                    rel: "noreferrer",
                    style: {
                        display: "block",
                        margin: "5px 0"
                    },
                    target: "_blank",
                    children: g(nc, {})
                })]
            })
        },
        km = () => {
            const {
                answers: e,
                border: t,
                cards: n,
                close: r,
                configureExitOnOverlayClick: i,
                destroy: o,
                endCard: a,
                eventEmitFn: s,
                fontFamily: l,
                headers: u,
                index: c,
                next: f,
                showStripes: d,
                update: p,
                useMobileStyling: h,
                viewDocument: v
            } = ee(S => ({
                answers: S.answers,
                border: S.border,
                cards: S.cards,
                close: S.close,
                configureExitOnOverlayClick: S.configureExitOnOverlayClick,
                destroy: S.destroy,
                endCard: S.endCard,
                eventEmitFn: S.eventEmitFn,
                fontFamily: S.fontFamily,
                headers: S.headers,
                index: S.index,
                next: S.next,
                showStripes: S.showStripes,
                update: S.update,
                useMobileStyling: S.useMobileStyling,
                viewDocument: S.viewDocument
            })), m = _t(null), y = _t(!1), {
                props: _,
                type: E,
                name: b
            } = n[c], w = n.length;
            Ie(() => {
                m.current && (m.current.classList.contains("ul-app--visible") || m.current.classList.add("ul-app--visible"), !y.current && s && (y.current = !0, s(K.SurveyAppeared)))
            }, [s]), Ie(() => {
                p()
            }, [c, p]), Ie(() => {
                i(() => r())
            }, [r, i]);
            const x = () => r(Wt),
                C = S => {
                    S.key === "Enter" && x()
                },
                I = async function(S) {
                    f({
                        data: S,
                        completeSurvey: () => {
                            o(Wt)
                        },
                        endCard: a
                    }), yf(v)
                };
            if (e) {
                for (const S of e)
                    if (S.questionId === b) {
                        let V;
                        if (E === R.MultipleChoice) {
                            const D = _.options.find(({
                                value: X
                            }) => X === S.value);
                            if (!D) break;
                            V = {
                                [D.id]: D.value
                            }
                        } else V = S.value;
                        I({
                            value: V,
                            type: E,
                            questionId: S.questionId
                        });
                        break
                    }
            }
            const k = () => [Tt.Email, Tt.Link].includes(u["userleap-platform"]) ? !1 : !a || c + 1 !== w,
                L = () => h ? {
                    borderColor: t
                } : {
                    borderColor: t,
                    margin: "15px"
                },
                T = () => {
                    const S = {
                        className: "ul-card",
                        next: I,
                        questionId: b,
                        type: E
                    };
                    switch (E) {
                        case R.ConsentLegal:
                            return te(Fv, { ...S,
                                ..._,
                                key: b
                            });
                        case R.Likert:
                            return te(Hv, { ...S,
                                ..._,
                                key: b
                            });
                        case R.MultipleChoice:
                            return te(Kv, { ...S,
                                ..._,
                                key: b
                            });
                        case R.MultipleSelect:
                            return te($v, { ...S,
                                ..._,
                                key: b
                            });
                        case R.NPS:
                            return te(Gv, { ...S,
                                key: b,
                                props: _
                            });
                        case R.Open:
                            return te(qv, { ...S,
                                ..._,
                                key: b
                            });
                        case R.RecordedTask:
                            return te(rm, { ...S,
                                ..._,
                                key: b
                            });
                        case R.TextUrlPrompt:
                            return te(am, { ...S,
                                ..._,
                                key: b
                            });
                        case R.Thanks:
                            return te(sm, { ...S,
                                ..._,
                                key: b
                            });
                        case R.Uploading:
                            return te(Sm, { ...S,
                                ..._,
                                key: b
                            });
                        case R.VideoVoice:
                            return te(Cm, { ...S,
                                ..._,
                                key: b
                            });
                        default:
                            return null
                    }
                },
                U = S => {
                    var z;
                    const V = window.sprigAPI,
                        D = S.target;
                    if (!V || !D) return;
                    const X = [D, D.parentElement];
                    for (const ve of X)
                        if (((z = ve == null ? void 0 : ve.tagName) == null ? void 0 : z.toLowerCase()) === "a") {
                            S.preventDefault(), V == null || V.openUrl(ve.href);
                            return
                        }
                };
            return g("div", {
                className: F("ul-app", Qt(u) ? "ul-app--visible" : "ul-app--overlay"),
                id: Wt,
                onClick: U,
                ref: m,
                style: {
                    "--theme": t,
                    ...l ? {
                        fontFamily: l.replace(";", "")
                    } : {}
                },
                children: g("div", {
                    className: "ul-app__container",
                    children: [g("div", {
                        className: F(ie(A.CardContainer, h)),
                        style: L(),
                        children: [d && g("div", {
                            className: "ul-header__container",
                            children: g("div", {
                                className: "ul-header",
                                children: "For development purposes only"
                            })
                        }), T(), g(Im, {})]
                    }), k() && g("div", {
                        className: F(ie(A.CloseContainer, h)),
                        children: g("div", {
                            "aria-label": "Close button",
                            className: A.CloseButton,
                            onClick: x,
                            onKeyPress: C,
                            role: "button",
                            tabIndex: 0,
                            children: g("svg", {
                                fill: "none",
                                height: "18px",
                                viewBox: "0 0 13 13",
                                width: "18px",
                                xmlns: "http://www.w3.org/2000/svg",
                                children: g("path", {
                                    d: "M2.54964 1.78369L1.78369 2.54964L5.73405 6.5L1.78369 10.4504L2.54964 11.2163L6.5 7.26595L10.4504 11.2163L11.2163 10.4504L7.26595 6.5L11.2163 2.54964L10.4504 1.78369L6.5 5.73405L2.54964 1.78369Z",
                                    fill: "#262136"
                                })
                            })
                        })
                    })]
                })
            })
        },
        Tm = `html,body,p,ol,ul,li,dl,dt,dd,blockquote,figure,fieldset,legend,textarea,pre,iframe,hr,h1,h2,h3,h4,h5,h6{margin:0;padding:0}h1,h2,h3,h4,h5,h6{font-size:100%;font-weight:400}button,input,select,textarea{margin:0}html{box-sizing:border-box}*,*:before,*:after{box-sizing:inherit}.ul-card{flex:1 1 auto;border-radius:2px;display:flex;flex-direction:column;font-size:17px;line-height:19px;text-align:left;margin:auto}.ul-card__container--desktop{border:2px solid #fff;box-shadow:0 0 15px #00000026}.ul-card__container--mobile{border-width:0;box-shadow:0 0 5px #00000040;margin-top:5px}.ul-card__container{background:#ffffff;border-radius:6px;display:flex;flex-direction:column;flex-grow:1;flex:1 1 auto;font-size:17px;line-height:23px;overflow:auto;padding:20px 20px 5px;position:relative;text-align:center;word-break:break-word}.ul-card-vertical__button-wrapper{flex-direction:column;align-items:center}.ul-card__button-wrapper{margin-top:4px;margin-bottom:3px;display:flex;gap:16px;justify-content:center}.ul-rich-text-body{min-height:2em}.ul-rich-text-body,.ul-rich-text-body p{margin-top:10px;margin-bottom:10px}.ul-rich-text-body li{margin:5px 0 5px 20px}.ul-rich-text-body p,.ul-rich-text-body li{font-size:15px;line-height:130.35%;letter-spacing:.02em;color:#343442;text-align:left;white-space:pre-line}.ul-rich-text-body:last-child,.ul-rich-text-body li:last-child{margin-bottom:15px}.ul-card-main-content__link,.ul-card-main-content__email{flex-grow:55;display:flex}.ul-card-main-content__web,.ul-card-main-content__android,.ul-card-main-content__ios{padding-top:15px;margin-bottom:5px}.ul-question{color:#343442;display:block;font-size:20px;line-height:125%;font-weight:500;cursor:default;text-align:left}.ul-caption{flex:1 0 auto;margin-top:8px;margin-bottom:15px;font-size:15px;line-height:130.35%;letter-spacing:.02em;color:#6c6c6e;text-align:left}.ul-card__choices{margin:5px 0 0;flex:1 0}.choice--mobile{border:2px solid #e6e6e6}.choice--desktop{border:1px solid #e6e6e6}.choice{align-items:flex-start;color:#262136;cursor:pointer;display:flex;justify-content:flex-start;flex-direction:column;box-sizing:border-box;border-radius:3px;margin-bottom:7px;font-size:15px;line-height:20px;padding:10px 20px 10px 15px;background-color:#00000003}.choice--desktop:hover,.choice--desktop:active,.choice--mobile:active{background-color:#0000000d}.choice-label-container{display:flex;flex-direction:row;justify-content:flex-start;align-items:center;width:100%;height:fit-content;flex:0 0 fit-content}.choice-text-entry-container{width:100%;height:fit-content;flex:0 1 fit-content;overflow:hidden}.choice .choice-text-input--mobile{max-height:63px}.choice .choice-text-input--desktop{max-height:150px}.choice .choice-text-input{box-sizing:border-box;background-color:transparent;color:#343442;font-family:-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Helvetica,Arial,sans-serif,"Apple Color Emoji","Segoe UI Emoji",Segoe UI Symbol;min-height:20px;max-height:60px;padding:0;margin-top:8px;resize:none;width:100%;font-size:14px;line-height:20px;outline:none;border:none;overflow-wrap:break-word}.choice .choice-text-input::placeholder{color:#6c6c6e80}.ul-thanks-check{text-align:center;margin-bottom:20px}.ul-card--thanks-content{padding:20px 0 10px}.ul-card--thanks .ul-question{padding-top:0;text-align:center}.ul-card--thanks .ul-caption{padding-top:0;text-align:center;overflow-wrap:break-word;hyphens:auto;hyphenate-limit-lines:no-limit}.ul-card--uploading .ul-question{padding-top:15px;text-align:center}.ul-card--uploading .ul-caption{padding-top:5px;text-align:center;overflow-wrap:break-word}.ul-loading-spinner-container{font-size:1.8rem;flex-grow:1;width:100%;height:100%;display:flex;align-items:center;justify-content:center}.ul-loading-spinner{display:inline-block;position:relative;width:6rem;height:6rem}.ul-loading-spinner div{box-sizing:border-box;display:block;position:absolute;width:80%;height:80%;margin:5px;border:5px solid #152e3e;border-radius:50%;animation:lds-ring 1.2s cubic-bezier(.5,0,.5,1) infinite;border-color:#152e3e transparent transparent transparent}.ul-loading-spinner .first{animation-delay:-.45s}.ul-loading-spinner .second{animation-delay:-.3s}.ul-loading-spinner .third{animation-delay:-.15s}@keyframes lds-ring{0%{transform:rotate(0)}to{transform:rotate(360deg)}}.select-checkbox{height:16px;width:16px;border-radius:3px;border:1px solid #323232;display:flex;box-sizing:border-box;box-shadow:inset 3px 3px #0000001a;background-color:"transparent";align-items:center;justify-content:center}.select-radio{height:16px;width:16px;border-radius:16px;border:1px solid #323232;display:flex;box-sizing:border-box;box-shadow:inset 2px 2px #0000001a;background-color:"transparent";align-items:center;justify-content:center}.fade-in-transition{animation:fadeIn .4s ease-in;-webkit-animation:fadeIn .4s ease-in;-moz-animation:fadeIn .4s ease-in;-o-animation:fadeIn .4s ease-in;-ms-animation:fadeIn .4s ease-in}@keyframes fadeIn{0%{opacity:0}to{opacity:1}}@-moz-keyframes fadeIn{0%{opacity:0}to{opacity:1}}@-webkit-keyframes fadeIn{0%{opacity:0}to{opacity:1}}@-o-keyframes fadeIn{0%{opacity:0}to{opacity:1}}@-ms-keyframes fadeIn{0%{opacity:0}to{opacity:1}}[class^=CenteredSurveyLayout] .ul-header__container,[class^=QuestionConceptTestLayout] .ul-header__container,.ul-websurvey-frame .ul-card__container,.ul-websurvey-frame-mobile .ul-card__container{margin-bottom:unset}[class^=CenteredSurveyLayout] .ul-card__container,[class^=QuestionConceptTestLayout] .ul-card__container,.ul-websurvey-frame .ul-card__container,.ul-websurvey-frame-mobile .ul-card__container{box-shadow:unset;border-radius:unset;border:none!important;position:unset}@media only screen and (min-height: 600px) and (width: 600px){.ul-card{position:relative;top:-20px}}.ul-vertical-centered-container{display:flex;flex-direction:column;align-items:center}.ul-consent-legal__name-input--mobile{border:2px solid #e6e6e6}.ul-consent-legal__name-input--desktop{border:1px solid #e6e6e6}.ul-consent-legal__name-input{background:rgba(0,0,0,.01);box-sizing:border-box;color:#343442;font-family:-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Helvetica,Arial,sans-serif,"Apple Color Emoji","Segoe UI Emoji",Segoe UI Symbol;padding:10px 20px 10px 15px;border-radius:3px;font-size:15px;line-height:20px;margin-bottom:7px;width:100%}.ul-consent-legal__name-input::placeholder{color:#6c6c6e80}.ul-consent-legal__name-input:focus{outline:none;background:white}.ul-consent-legal__name-input--desktop:hover:not(:focus){background-color:#0000000d}.ul-card__consent-legal .choice{font-size:15px;padding:10px 15px;background-color:#00000003}.ul-card__consent-legal .choice--desktop:hover,.ul-card__consent-legal .choice--desktop:active,.ul-card__consent-legal .choice--mobile:active{background-color:#0000000d}.ul-card--likert__numbers{align-items:center;border-radius:5px;display:flex;flex-direction:row;flex:1 0;justify-content:center;margin:5px 0 0}.likert-number--mobile{border:2px solid #e6e6e6;margin-left:-2px}.likert-number--desktop{border:1px solid #e6e6e6;margin-left:-1px}.likert-number{align-items:center;cursor:pointer;display:flex;justify-content:center;flex:1 0;background-color:#00000003;font-size:18px;line-height:24px;height:67px}.likert-number:active,.likert-number--desktop:hover{background-color:#0000000d;font-weight:500}.likert-number-1{border-top-left-radius:5px;border-bottom-left-radius:5px}.likert-last-option{border-top-right-radius:5px;border-bottom-right-radius:5px}.likert-star--mobile{margin-left:-2px}.likert-star--desktop{margin-left:-1px}.likert-star{align-items:center;cursor:pointer;display:flex;justify-content:space-between;flex:1 0;color:transparent;font-size:18px;line-height:24px;height:67px}.likert-smiley--mobile{margin-left:-2px}.likert-smiley--desktop{margin-left:-1px}.likert-smiley{align-items:center;cursor:pointer;display:flex;justify-content:space-between;flex:1 0;color:transparent;line-height:24px;height:67px}.likert-smiley circle:not(:first-child){fill-opacity:1}.ul-card--likert__labels{align-items:center;color:#262136;display:flex;flex-direction:row;flex:1 0;font-weight:500;font-size:13px;line-height:15px;justify-content:space-between;margin:7px 0 10px}.ul-card--likert__labels span:last-child{text-align:right}.select-label{flex:1;overflow-wrap:anywhere;cursor:pointer;padding-left:15px}.ul-card--nps__numbers{align-items:center;border-radius:5px;display:flex;flex-direction:row;flex:1 0;justify-content:center;margin:5px 0 0}.nps-number--mobile{border:2px solid #e6e6e6;margin-left:-2px}.nps-number--desktop{border:1px solid #e6e6e6;margin-left:-1px}.nps-number{align-items:center;cursor:pointer;display:flex;justify-content:center;flex:1 0;background-color:#00000003;font-size:18px;line-height:24px;height:67px}.nps-number:active,.nps-number--desktop:hover{background-color:#0000000d;font-weight:500}.nps-number-0{border-top-left-radius:5px;border-bottom-left-radius:5px}.nps-number-10{border-top-right-radius:5px;border-bottom-right-radius:5px}.ul-card--nps__labels{align-items:center;color:#262136;display:flex;flex-direction:row;flex:1 0;font-weight:500;font-size:13px;line-height:15px;justify-content:space-between;margin:7px 0 10px}.ul-card--nps__labels span:last-child{text-align:right}.ul-card-text{flex:1 0 auto;margin-top:2px;margin-bottom:3px;align-items:center;display:flex;flex-wrap:wrap;justify-content:center;padding:0}.ul-card-text__container{align-items:center;box-sizing:border-box;border-radius:3px;display:flex;justify-content:center;margin-bottom:12px;flex:1 0 100%}.ul-card-text__input--mobile{border:2px solid #e6e6e6;max-height:63px}.ul-card-text__input--desktop{border:1px solid #e6e6e6;max-height:150px}.ul-card-text__input{background:rgba(0,0,0,.01);box-sizing:border-box;color:#343442;font-family:-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Helvetica,Arial,sans-serif,"Apple Color Emoji","Segoe UI Emoji",Segoe UI Symbol;min-height:63px;overflow:auto;padding:12px;resize:none;width:100%;border-radius:3px;font-size:15px;line-height:20px;overflow-wrap:break-word}.ul-card-text__input::placeholder{color:#6c6c6e80}.ul-card-text__input:focus{outline:none;background:white}.ul-card-text__input--desktop:hover:not(:focus){background-color:#0000000d}.ul-card__text-url-prompt-button{text-decoration:none;text-overflow:ellipsis;overflow:hidden;white-space:nowrap}#ul-card-voice__video{align-items:center;display:flex;flex-direction:column}#ul-card-voice__video>div{margin-bottom:10px;width:100%}#ul-card-video__player_recorder{width:100%;width:-moz-available;width:-webkit-fill-available;width:fill-available}.ul-card-record__task{flex:1 0 auto;margin-top:2px;margin-bottom:3px;align-items:center;display:flex;flex-wrap:wrap;justify-content:center;padding:0}#ul-record-task-upload-progress,#ul-record-task-video-preview{width:100%;height:150px}.ul-permission-graphics-container{width:100%;height:150px;background-color:#0000000d;text-align:center;flex-direction:column;margin-left:auto;margin-right:auto;border-radius:5px;display:flex;align-items:center;font-size:15px;color:#000000b3}.ul-av-permission-denied-paragraph{margin:auto 15px;font-size:12px}.ul-av-permission-denied-headline{font-size:14px;color:#262136;text-decoration:underline;font-size:12px}.ul-permission-body{color:#000;margin:5px auto 5px 5px;line-height:135%;text-align:center}.ul-select-tab-container{width:240px;height:46px;background:#ffffff;border-radius:5px;text-align:left;align-items:center;display:flex;padding:0 5px;margin-top:20px;margin-bottom:auto}.ul-select-tab-text{color:#4b575d;margin:5px;line-height:135%;text-align:center}button.ul-task-skip-button{color:#000;background-color:#fff}#ul-task-detail-container{margin-top:0;margin-bottom:0;overflow:auto}#ul-task-detail-container.ul-rich-text-body p,#ul-task-detail-container.ul-rich-text-body li,#ul-task-detail-container.ul-rich-text-body{color:#4c4c4c}#ul-task-detail-container :first-child{margin-top:0}#ul-task-detail-container :last-child{margin-bottom:20px}.ul-horizontal-button-container{width:100%;display:flex;flex-direction:row}.ul-skip-button-below{margin-top:5px}.ul-horizontal-button-container-center{justify-content:center}.ul-vertical-button-container-center{display:flex;flex-direction:column;align-items:center}.ul-horizontal-button-container-left{justify-content:flex-start}.ul_recorded-task-inset-spacing{margin-top:5px;margin-bottom:24px}.ul_permission_svg_container{justify-content:center}.ul-card-text__button{background-color:var(--theme);border-radius:3px;border:none;color:#fff;cursor:pointer;font-size:15px;font-weight:500;line-height:18px;padding:10.5px 21px}.ul-card-text__button:disabled,.ul-card-text__button.sprig-button-disabled{background-color:#0000001a;color:#0003}.ul-card-text__button.ul-button-inactive{background-color:#fff!important;color:#5d696f!important}.ul-card-skip__button{color:#00000080;background:none;border:none;font-size:15px;font-family:-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Helvetica,Arial,sans-serif,"Apple Color Emoji","Segoe UI Emoji",Segoe UI Symbol;cursor:pointer}.ul-card-button-group{align-items:center;display:flex;gap:30px}html,body{cursor:default;font-family:-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Helvetica,Arial,sans-serif,"Apple Color Emoji","Segoe UI Emoji",Segoe UI Symbol;height:100%;overflow:hidden;-webkit-tap-highlight-color:transparent;-webkit-user-select:none;-webkit-touch-callout:none}b{font-weight:500}#ul-app{opacity:0;width:100%;flex-grow:2;display:flex}#ul-app.ul-app--overlay{position:absolute;bottom:0;transition:opacity .1s ease-out;transition-delay:.1s}#ul-app.ul-app--visible{opacity:1;bottom:0}.ul-app__container{width:100%;display:flex;flex-direction:column;max-height:100vh}.ul-header__container{margin-bottom:15px}.ul-header{align-items:center;background:repeating-linear-gradient(120deg,#ebebeb,#ebebeb 24px,#fff 24px,#fff 48px);border-bottom:2px solid #ebebeb;display:flex;font-size:14px;font-weight:500;height:40px;justify-content:center;left:0;position:absolute;top:0;width:100%}.ul-footer{display:flex;flex-direction:column;align-items:center;justify-content:center;margin-top:auto;flex-grow:1;width:100%}.ul-footer-bubble{display:inline-block;margin:0 3px;width:7px;height:7px;border-radius:3px;border:1px solid transparent}.close-container--desktop,.close-container--mobile{height:22px;width:22px;border-radius:22px;background-color:#fff;align-items:center;justify-content:center}.close-container--desktop{top:25px;right:25px}.close-container--mobile{top:15px;right:10px}.close-container{background:transparent;box-sizing:border-box;display:flex;position:absolute}.close-btn{height:18px;width:18px;align-items:center;justify-content:center;display:flex;cursor:pointer}.ul-app__container{transition:opacity .3s ease-out}.ul-center-horizontally{text-align:center}#ul-progress-bar-container{width:100%;height:2px;background-color:#0000001a;border-radius:2px;max-width:250px;margin:25px 0}#ul-progress-bar-current{transition:width 1s ease;width:0%;height:0;border-radius:2px}.prototype-button{width:100%;background:rgba(0,0,0,.01);border:1.5px solid #e6e6e6;border-radius:4px 0 0 4px;flex:none;flex-grow:1;margin:0;padding:20px 0;font-size:14px;font-family:inherit;text-decoration:underline}.prototype-button:hover{cursor:pointer}
`,
        Lm = (e, t) => {
            const n = [...e],
                r = new Set([R.VideoVoice, R.RecordedTask]);
            return e.some(i => r.has(i.type)) && n.push({
                name: -2,
                props: {
                    routingOptions: []
                },
                type: R.Uploading
            }), t && n.push({
                name: -1,
                props: {
                    routingOptions: []
                },
                type: R.Thanks
            }), n
        },
        Rm = ({
            mode: e = null,
            viewWindow: t,
            viewDocument: n
        }) => {
            const r = n.documentElement;
            return {
                mode: e,
                sw: t.screen.width,
                sh: t.screen.height,
                cw: r.clientWidth,
                ch: r.clientHeight,
                p: t.location.href,
                l: t.navigator.language
            }
        };

    function Am(e, t = !0) {
        var w;
        const {
            answers: n,
            apiURL: r,
            customStyles: i,
            endCard: o,
            eventEmitFn: a,
            fontFamilyURL: s,
            frame: l,
            previewKey: u,
            UpChunk: c,
            viewDocument: f,
            viewWindow: d
        } = e, p = Qt(e.headers) ? e.frame : f.body, h = q, v = Lm(e.cards, !!o);
        qr.configure(h, {
            cards: v,
            hasEndCard: !!o,
            apiURL: r,
            UpChunk: c
        }), ee.setState({
            apiURL: r,
            answers: n,
            border: e.border,
            index: e.startingQuestionIdx || 0,
            cards: v,
            configureExitOnOverlayClick: e.configureExitOnOverlayClick,
            customMetadata: e.customMetadata,
            endCard: e.endCard,
            envId: e.envId,
            eventEmitFn: a,
            fontFamily: e.fontFamily,
            frame: l,
            headers: e.headers,
            hasViewedEmbed: !1,
            isPreview: e.isPreview,
            marketingUrl: "https://sprig.com",
            meta: Rm({
                mode: e.mode,
                viewWindow: d,
                viewDocument: f
            }),
            mode: e.mode,
            previewKey: u,
            recorder: qr,
            recorderEventEmitter: h,
            responseGroupUid: e.responseGroupUid,
            showStripes: e.showStripes,
            showSurveyBrand: e.showSurveyBrand,
            slugName: e.slugName,
            styleNonce: e.styleNonce,
            surveyId: e.surveyId,
            tabTitle: e.tabTitle,
            uploadingCardViewed: !1,
            uploadProgress: {},
            useMobileStyling: e.useMobileStyling,
            useDesktopPrototype: e.useDesktopPrototype,
            userId: e.userId,
            viewDocument: e.viewDocument,
            visitorAttributes: e.visitorAttributes,
            viewedCardCount: e.startingQuestionIdx || 0
        });
        const {
            seen: m
        } = ee.getState();
        m();
        const {
            head: y
        } = f, _ = f.createElement("style");
        if (_.id = "sprig-style", _.textContent = Tm, _.nonce = e.styleNonce, y.appendChild(_), e.fontFamily && s && parent) {
            const x = f.createElement("link");
            x.rel = "stylesheet", x.href = s, y.appendChild(x)
        }
        if (e.customStyles && Ga(f, i, e.styleNonce), !c)
            if (e.installationMethod !== Lt.Npm) {
                const x = f.createElement("script");
                x.src = "https://cdn.sprig.com/userleap-web-upchunk-v2.2.2.js", x.onload = () => {
                    qr.setUpChunk(d.UpChunk)
                }, x.onerror = () => {
                    console.warn("[Sprig] - recording functionality not configured due to UpChunk library load failure")
                }, y.appendChild(x)
            } else console.warn("[Sprig] - recording functionality not configured due to missing UpChunk dependency");
        const E = "2.24.1",
            b = a || ((w = l.eventEmitter) == null ? void 0 : w.emit);
        b == null || b(xe.VerifyViewVersion, {
            [kt.ViewVersion]: E
        }), p && t && un(g(km, {}), p)
    }
    const Om = {
        configure: Am
    };
    window.UserLeap && window.Sprig && (window.Sprig._gtm ? window.Sprig = window.UserLeap : window.UserLeap = window.Sprig), window.UserLeap || (window.UserLeap = window.Sprig), window.Sprig || (window.Sprig = window.UserLeap);
    const Dm = "rgba(255,255,255, 0.95)",
        Um = "rgba(0,0,0,0.9)",
        Pm = "360px",
        Jo = "0px",
        rc = () => {
            window.UserLeap.container = document.createElement("div"), window.UserLeap.container.className = "ul-container", document.body.appendChild(window.UserLeap.container)
        },
        ic = e => {
            Fm();
            const t = window.UserLeap.container;
            if (!!t) try {
                document.body.removeChild(t), window.UserLeap.container = null, be("trackStartUrl", null), q.emit(K.SurveyLifeCycle, {
                    state: "dismissed"
                }), q.emit(K.SurveyClosed, {
                    name: K.SurveyClosed,
                    initiator: e
                })
            } catch (n) {
                console.warn(`[Sprig] (ERR-412) Error removing UserLeap container by ${e} ` + t), n instanceof Error && window.UserLeap.reportError("dismissActiveSurvey", n)
            }
        },
        oc = () => {
            q.on(K.SurveyWillClose, ({
                initiator: e
            }) => {
                ic(e)
            })
        },
        Nm = (e, t) => {
            const r = { ...{
                        position: "fixed",
                        overflow: "auto",
                        top: "0px",
                        left: "0px",
                        display: "none",
                        height: "100%",
                        width: "100%",
                        transition: "background-color 0.3s ease-out",
                        zIndex: 2147483646
                    }
                },
                i = t ? e.overlayStyleMobile : e.overlayStyle;
            r["background-color"] = i === "light" ? Dm : Um, t || (r.margin = "auto"), window.UserLeap.container && Object.assign(window.UserLeap.container.style, r)
        },
        Mm = (e, t, n) => {
            var s, l;
            const r = {
                    position: "fixed",
                    bottom: "0px",
                    right: Jo,
                    border: 0,
                    backgroundColor: "rgba(0,0,0,0)",
                    zIndex: 2147483646
                },
                i = Object.assign({}, t, window.UserLeap);
            let o, a = !1;
            return n ? ((s = window.UserLeap.windowDimensions) != null && s.width ? r.width = `${window.UserLeap.windowDimensions.width}px` : r.width = "100%", (l = window.UserLeap.windowDimensions) != null && l.height ? r.maxHeight = `${window.UserLeap.windowDimensions.height-20}px` : window.UserLeap.maxHeight ? r.maxHeight = window.UserLeap.maxHeight : r.maxHeight = `${document.body.clientHeight-20}px`, ["light", "dark"].includes(i.overlayStyleMobile) && (a = !0)) : (r.width = Pm, r.maxHeight = window.UserLeap.maxHeight || "66vh", i.framePosition === bn.BottomLeft ? o = {
                left: Jo
            } : i.framePosition === bn.TopLeft ? o = {
                left: Jo,
                top: "0px"
            } : i.framePosition === bn.TopRight ? o = {
                top: "0px"
            } : i.framePosition === bn.Center && (a = !0, o = {
                margin: "auto",
                position: "static"
            }, r.maxHeight = null)), a && Nm(i, n), Object.assign(e.style, r, o), a
        },
        jm = (e, t) => {
            var s, l;
            const n = "ul-frame";
            rc(), Vm();
            const r = document.createElement("iframe");
            r.id = n, r.setAttribute("title", "Sprig User Feedback Dialog");
            const i = Mm(r, e, t);
            oc(), r.setHeight = u => {
                parseInt(r.style.height) != u && (r.style.height = `${u}px`, q.emit(K.SurveyHeight, {
                    name: K.SurveyHeight,
                    contentFrameHeight: u
                }))
            }, (s = window.UserLeap.container) == null || s.appendChild(r), e && (t ? e.exitOnOverlayClickMobile : e.exitOnOverlayClick) && window.UserLeap.container && (window.UserLeap.container.onclick = () => {
                q.emit(K.CloseSurveyOnOverlayClick)
            }), q.emit(K.SurveyLifeCycle, {
                state: "presented"
            }), q.emit(K.SurveyPresented, {
                name: K.SurveyPresented
            });
            const o = (l = r.contentWindow) == null ? void 0 : l.document;
            o && (o.open("text/html", "replace"), o.write("<!doctype html><head></head><body></body></html>"), o.close());
            const a = o == null ? void 0 : o.head;
            return {
                frameId: n,
                contentWinDocHead: a,
                contentWindow: r.contentWindow,
                hasOverlay: i,
                iframe: r
            }
        },
        ac = {
            [K.SurveyFadingOut]: () => {
                window.UserLeap.container && Object.assign(window.UserLeap.container.style, {
                    "background-color": "rgba(0,0,0,0)"
                })
            }
        },
        Vm = () => {
            Object.entries(ac).forEach(([e, t]) => {
                q.on(e, t)
            })
        },
        Fm = () => {
            Object.entries(ac).forEach(([e, t]) => {
                q.off(e, t)
            })
        },
        Bm = "!launch_darkly_";
    class Hm {
        constructor() {
            me(this, "_ldData", {})
        }
        getAllLaunchDarklyVariations() {
            return this._ldData
        }
        setLDFlagsVariations(t) {
            try {
                return !t || typeof t != "object" || Array.isArray(t) ? !1 : (Object.keys(this._ldData).forEach(n => {
                    delete this._ldData[n]
                }), Object.keys(t).forEach(n => {
                    var r;
                    return this._ldData[`${Bm}${n}`] = ((r = t[n]) != null ? r : 0) + 1
                }), !0)
            } catch (n) {
                return n instanceof Error && window.UserLeap.reportError("setAllLDFlagsVariations", n), console.warn("[Sprig] An issue had occured when setting LaunchDarkly flags and variations."), !1
            }
        }
    }
    const ea = new Hm;
    Object.freeze(ea);
    const Km = "!optimizely_experiments_";
    class $m {
        constructor() {
            me(this, "_optimizelyData", {})
        }
        setOptimizelyExperiment(t, n = !0) {
            if (!t || typeof t != "object") return !1;
            const {
                experiments: r
            } = t;
            try {
                return n && Object.keys(this._optimizelyData).map(i => {
                    delete this._optimizelyData[i]
                }), r && r.map(i => {
                    const {
                        id: o,
                        variation: a
                    } = i, s = this.transformExperimentId(o);
                    a && typeof a == "string" && (this._optimizelyData[s] = a)
                }), !0
            } catch (i) {
                return i instanceof Error && window.UserLeap.reportError("setOptimizelyExperiment", i), !1
            }
        }
        getAllOptimizelyExperiments() {
            return this._optimizelyData
        }
        getOptimizelyVariationName(t) {
            return this._optimizelyData[this.transformExperimentId(t)]
        }
        transformExperimentId(t) {
            return Km + t
        }
        getAndSetWebOptimizelyExperiments() {
            var t;
            try {
                if (window && window.optimizely && typeof window.optimizely.get == "function") {
                    const n = (t = window.optimizely.get("state")) == null ? void 0 : t.getExperimentStates({
                        isActive: !0
                    });
                    if (n) {
                        const r = Object.keys(n).map(i => {
                            var o, a;
                            return (o = n[i].variation) != null && o.name ? {
                                id: i,
                                variation: (a = n[i].variation) == null ? void 0 : a.name
                            } : {
                                id: i,
                                variation: "Original"
                            }
                        });
                        return this.setOptimizelyExperiment({
                            experiments: r
                        }, !1), !0
                    }
                    return !1
                }
                return !1
            } catch (n) {
                return n instanceof Error && window.UserLeap.reportError("getAndSetWebOptimizely", n), !1
            }
        }
    }
    const Jr = new $m;
    Object.freeze(Jr);
    class Gm {
        constructor(t, n) {
            me(this, "paused");
            me(this, "queue");
            me(this, "ul");
            this.ul = t, this.paused = !1, this.queue = [], this.flush(n)
        }
        flush(t) {
            const n = t.length;
            if (n)
                for (let r = 0; r < n; r++) this.push(t[r])
        }
        isPaused() {
            return this.paused
        }
        pause() {
            this.paused = !0
        }
        unpause() {
            this.paused = !1;
            const t = this.queue.slice();
            this.empty(), this.flush(t)
        }
        push(t) {
            if (this.paused) this.queue.push(t);
            else if (t instanceof Function) t();
            else {
                const n = Array.prototype.slice.call(t, 1),
                    r = t[0],
                    i = this.ul[r];
                i instanceof Function ? i.apply(this.ul, n) : r && console.warn("[Sprig] (ERR-100) No valid UserLeap action called", r)
            }
        }
        perform(t) {
            if (this.paused) {
                let n = () => {};
                const r = new Promise(function(i) {
                    n = function() {
                        i(t())
                    }
                });
                return this.queue.push(n), r
            } else return t()
        }
        empty() {
            this.queue.length = 0
        }
    }
    const qm = ["popState", "pushState", "replaceState"],
        zm = {
            test: "test"
        },
        Wn = "!email",
        Wm = ["ios", "android"],
        Et = "environments",
        ta = "pageUrl",
        Ht = "visitors",
        sc = "ul-view-sdk-script",
        lc = Object.freeze({
            contains: (e, t) => t.includes(e),
            notContains: (e, t) => !t.includes(e),
            exactly: (e, t) => t === e,
            notExactly: (e, t) => t !== e,
            startsWith: (e, t) => t.startsWith(e),
            endsWith: (e, t) => t.endsWith(e),
            regex: (e, t) => new RegExp(e).test(t),
            legacy: (e, t) => new RegExp(e, "i").test(t)
        });

    function na(e, t) {
        const {
            matchType: n,
            pattern: r
        } = e, i = n ? lc[n] : lc.legacy;
        let o = !1;
        try {
            o = i(r, t)
        } catch (a) {
            const s = `[Sprig] (ERR-445) Failed to check url match with pattern ${r}`;
            a instanceof Error && (console.warn(s, a), a.stack = JSON.stringify(e), window.UserLeap.reportError(s, a))
        }
        return o
    }

    function Ym(e, t) {
        const {
            pageUrlEvents: n,
            interactiveEvents: r,
            dismissOnPageChange: i
        } = window.UserLeap._config;
        if (!i) return !0;
        const o = [];
        n && n.length && o.push(...n), r && r.length && o.push(...r);
        const a = e && o.find(s => s.id === e);
        return a ? na(a, window.location.href) : t === window.location.href
    }

    function Yn(e) {
        const {
            pageUrlEvents: t,
            interactiveEvents: n,
            dismissOnPageChange: r,
            platform: i
        } = window.UserLeap._config;
        if (i && i !== Tt.Web) return;
        const o = Kt("trackStartUrl"),
            a = o ? String(o) : null;
        t && tg(window.location.href), n && (cc(), Qm()), r && a && a !== window.location.href && e && qm.includes(e.type) && window.UserLeap("dismissActiveSurvey", Ye.PageChange)
    }
    const uc = {
            capture: !0
        },
        Qm = () => {
            const t = window.UserLeap._config.interactiveEvents.filter(r => na(r, window.location.href)).map(r => {
                    const {
                        name: i,
                        properties: o
                    } = r, {
                        selector: a,
                        innerText: s
                    } = o;
                    return a ? l => {
                        if (Yt(l.target)) try {
                            l.target.closest(a) && window.UserLeap("track", i)
                        } catch {}
                        return !1
                    } : l => (Yt(l.target) && l.target.innerText === s && window.UserLeap("track", i), !1)
                }),
                n = r => t.forEach(i => i(r));
            window.UserLeap._config.interactiveEventsHandler = n, window.addEventListener("click", n, uc)
        },
        cc = () => {
            window.UserLeap._config.interactiveEventsHandler && window.removeEventListener("click", window.UserLeap._config.interactiveEventsHandler, uc), delete window.UserLeap._config.interactiveEventsHandler
        };

    function Zm() {
        ["hashchange", "popstate"].forEach(e => window.addEventListener(e, Yn, !0))
    }

    function Xm() {
        ["hashchange", "popstate"].forEach(e => window.removeEventListener(e, Yn, !0)), window.UserLeap._config.interactiveEvents && cc()
    }

    function Ge(e, t, n) {
        const r = [window.UserLeap._API_URL, "sdk", e];
        return t && t.forEach(i => {
            r.push(i), i === Et ? r.push(window.UserLeap.envId) : i === Ht && r.push(ra())
        }), n && r.push(n), r.join("/")
    }

    function Jm(e, t) {
        let n = Ge("1", [Et], "questions?");
        return e != null && (n += `&vid=${e}`), t && (t.surveyId && (n += `&surveyid=${t.surveyId}`), t.surveyTemplateId && (n += `&surveytemplateid=${t.surveyTemplateId}`)), n
    }

    function eg() {
        try {
            if (typeof localStorage < "u" && (localStorage.setItem("is_available", "yes"), localStorage.getItem("is_available") === "yes")) return localStorage.removeItem("is_available"), !0
        } catch {
            return !1
        }
        return !1
    }

    function Kt(e) {
        if (!window.UserLeap.localStorageAvailable) return null;
        const t = localStorage.getItem(ge.Credentials);
        if (t) try {
            const r = JSON.parse(t)[window.UserLeap.envId];
            return r && r[e] || null
        } catch (n) {
            n instanceof Error && (n.stack = t, window.UserLeap.reportError("Failed to parse local storage credentials", n)), console.warn("[Sprig] (ERR-427) Failed to lookup saved ids", n)
        }
        return null
    }

    function be(e, t) {
        if (!window.UserLeap.localStorageAvailable) return;
        const n = localStorage.getItem(ge.Credentials);
        let r = {};
        if (n) try {
            r = JSON.parse(n)
        } catch (o) {
            o instanceof Error && (o.stack = n, window.UserLeap.reportError("Failed to parse local storage credentials", o)), console.warn("[Sprig] (ERR-427) Failed to lookup saved ids", o)
        }
        let i = r[window.UserLeap.envId];
        i ? i[e] = t : i = {
            [e]: t
        }, r[window.UserLeap.envId] = i;
        try {
            localStorage.setItem(ge.Credentials, JSON.stringify(r))
        } catch (o) {
            o instanceof Error && console.warn(`[Sprig] (ERR-426) Unable to write to Local Storage:: ${o.message}`)
        }
    }

    function dc() {
        window.previewMode || (window.UserLeap.visitorId = ct(), be("vid", window.UserLeap.visitorId), q.emit(K.VisitorIDUpdated, {
            visitorId: window.UserLeap.visitorId
        }))
    }

    function ra() {
        return window.previewMode ? "0" : window.UserLeap.visitorId || ""
    }

    function tg(e) {
        if (!window.UserLeap.localStorageAvailable || e.endsWith("mock_snippet.html")) return;
        const t = window.UserLeap._config.pageUrlEvents;
        if (t && t.length) {
            let s = !1;
            for (let l = 0; l < t.length && (s = na(t[l], e), !s); l++);
            if (!s) return
        }
        window.UserLeap.debugMode && console.info("[DEBUG] Sprig trackPageView", e);
        const n = 10,
            r = 1;
        let i = [];
        const o = {
                viewedAt: Date.now(),
                location: e
            },
            a = localStorage.getItem(ge.PageViews);
        try {
            if (i = a ? JSON.parse(a) : [], Array.isArray(i) || (i = []), i.length > 0) {
                const s = i[i.length - 1],
                    l = (Date.now() - s.viewedAt) / 1e3;
                (s.location != e && l > r || l > n) && (window.UserLeap._queue.push(["track", ta, null, {
                    url: e
                }]), i.push(o))
            } else window.UserLeap._queue.push(["track", ta, null, {
                url: e
            }]), i.push(o);
            i.length > 5 && i.splice(0, i.length - 5);
            try {
                localStorage.setItem(ge.PageViews, JSON.stringify(i))
            } catch (s) {
                s instanceof Error && console.warn(`[Sprig] Unable to write to Local Storage: ${s.message}`)
            }
        } catch (s) {
            s instanceof Error && (s.stack = a || "", window.UserLeap.reportError("trackPageView", s)), console.warn("[Sprig] (ERR-425) Failed to update page views in local storage")
        }
    }

    function ng() {
        const e = "Backbone" in window && window.Backbone && window.Backbone.history ? window.Backbone.history : window.history;
        "pushState" in e && (e.pushState = (t => function(...r) {
            const i = t.apply(this, r),
                o = new Event("pushState");
            return window.dispatchEvent(o), Yn(o), i
        })(e.pushState)), "replaceState" in e && (e.replaceState = (t => function(...r) {
            const i = t.apply(this, r),
                o = new Event("replaceState");
            return window.dispatchEvent(o), Yn(o), i
        })(e.replaceState)), Zm()
    }
    async function ia(e, t) {
        const n = ra();
        e && !t && (window.UserLeap._config.mode = zm.test);
        const r = await xt(Jm(n, e), {}, 0, !0);
        return r.ok ? (r.json.delay && await ur(r.json.delay), fc(r.json)) : (r.reportError && r.error && (console.warn("[Sprig] (ERR-414) Failed to request questions from the server", r.error), window.UserLeap.reportError("getQuestions", r.error)), {
            success: !1,
            surveyState: "no survey"
        })
    }
    const fc = async (e, t) => {
        var S, V, D, X;
        const {
            context: n,
            endCard: r,
            locale: i,
            productConfig: o,
            questions: a,
            responseGroupUid: s,
            surveyId: l,
            uuid: u,
            vid: c,
            sessionReplay: f
        } = e, d = En(window.UserLeap), p = oa(d), h = rg(d);
        if (f && Js({
                responseGroupId: s,
                surveyId: l,
                visitorId: c,
                replayParams: f,
                completeUploadHeaders: d,
                apiUrl: window.UserLeap._API_URL
            }), c == null || !a || !a.length) return {
            success: !1,
            message: "[Sprig] no survey found",
            surveyState: "no survey"
        };
        if (window.UserLeap.container) {
            const z = "[Sprig] (ERR-409) Found an existing Survey container, aborting rendering of this survey";
            return console.warn(z), {
                success: !1,
                message: z,
                surveyState: "no survey"
            }
        }
        if (c !== window.UserLeap.visitorId && u !== window.UserLeap.visitorId && !window.previewMode) {
            const z = "Attempted to display survey to a different visitor";
            return window.UserLeap.reportError("DisplaySurvey", new Error(z)), {
                success: !1,
                message: z,
                surveyState: "no survey"
            }
        }
        if (!(t ? await t(l) : !0)) return {
            success: !1,
            message: "[Sprig] Callback returned false, aborting rendering of survey",
            surveyState: "no survey"
        };
        Si.disable(), q.emit(K.SurveyWillPresent, {
            name: K.SurveyWillPresent,
            [Ba.SurveyId]: l
        });
        let m, y = document.createElement("div"),
            _, E, b;
        const w = z => {
            const {
                [kt.ViewVersion]: ve
            } = z;
            ve !== d["x-ul-sdk-version"] && ic(), q.removeListener(xe.VerifyViewVersion, w)
        };
        q.on(xe.VerifyViewVersion, w), Qt(d) ? (m = "ul-direct-embeded-frame", _ = document.head, E = window, b = !1, p && (rc(), y.id = m, window.UserLeap.container.appendChild(y), oc(), q.emit(K.SurveyLifeCycle, {
            state: "presented"
        }), q.emit(K.SurveyPresented, {
            name: K.SurveyPresented
        }))) : {
            frameId: m,
            contentWinDocHead: _,
            contentWindow: E,
            hasOverlay: b,
            iframe: y
        } = jm(o, h), window.UserLeap.frameId = m, window.UserLeap.useMobileStyling = h;
        const x = z => {
                q.on(K.CloseSurveyOnOverlayClick, z)
            },
            C = Object.assign({
                frame: y,
                envId: window.UserLeap.envId,
                surveyId: l,
                userId: u,
                visitorAttributes: {
                    externalUserId: window.UserLeap.userId,
                    email: window.UserLeap.email
                },
                cards: a,
                context: n,
                locale: i,
                fontFamily: window.UserLeap.fontFamily,
                fontFamilyURL: window.UserLeap.fontFamilyURL,
                apiURL: window.UserLeap._API_URL,
                responseGroupUid: s,
                headers: d,
                endCard: r,
                useMobileStyling: h,
                mobileSDKVersion: window.UserLeap.mobileSDKVersion,
                configureExitOnOverlayClick: x,
                eventEmitFn: q.emit.bind(q),
                ulEvents: Ha,
                viewDocument: E == null ? void 0 : E.document,
                viewWindow: E,
                tabTitle: document.title,
                startingQuestionIdx: (S = window.UserLeap.config) == null ? void 0 : S.startingQuestionIdx,
                styleNonce: window.UserLeap.styleNonce,
                previewKey: (V = window.UserLeap) != null && V.localStorageAvailable ? (D = window.localStorage) == null ? void 0 : D.getItem(ge.Preview) : null
            }, window.UserLeap._config);
        (X = window.UserLeap.config) != null && X.startingQuestionIdx && (window.UserLeap.config = { ...window.UserLeap.config,
            startingQuestionIdx: null
        }), window.UserLeap.customStyles && (C.customStyles = window.UserLeap.customStyles), E && (E.__cfg = C);

        function I() {
            const z = document.createElement("script");
            return window.UserLeap.nonce && z.setAttribute("nonce", window.UserLeap.nonce), z.id = sc, z
        }
        const k = window.UserLeap.viewSDKURL ? window.UserLeap.viewSDKURL : C.path,
            L = document.getElementById(sc);
        L && L.remove();
        const T = I(),
            U = () => {
                window.UserLeap.container && Object.assign(window.UserLeap.container.style, {
                    display: "flex"
                })
            };
        return C.installationMethod === Lt.Npm ? (Om.configure(C), b && window.UserLeap.container && U()) : k && (T.src = k, b && T.addEventListener("load", () => {
            window.UserLeap.container && U()
        }), E == null || E.addEventListener("error", z => {
            z.target instanceof HTMLScriptElement && z.target.src === k && window.UserLeap.reportError("loadFrameScript", new Error("Frame script failed to load"))
        }, {
            capture: !0,
            once: !0
        })), _ == null || _.appendChild(T), {
            success: !0,
            surveyState: "ready"
        }
    };

    function rg(e) {
        if (window.UserLeap.useMobileStyling !== void 0) return window.UserLeap.useMobileStyling;
        const t = window.UserLeap.windowDimensions && window.UserLeap.windowDimensions.width || document.body.clientWidth;
        return oa(e) || t > 10 && t < vf
    }

    function oa(e) {
        return Wm.includes(e[Ne.Platform])
    }

    function ig(e) {
        let t = e.length;
        for (; t;) {
            const n = Math.floor(Math.random() * t);
            t -= 1;
            const r = e[t];
            e[t] = e[n], e[n] = r
        }
    }

    function og(e) {
        if (!e) return;
        window.UserLeap._config = e, e.mute && window.UserLeap._queue.pause();
        const {
            interactiveEvents: t,
            pageUrlEvents: n,
            dismissOnPageChange: r
        } = e;
        t && ig(t), (t || n || r) && (ng(), Yn())
    }
    async function xt(e, t, n = 0, r = !1) {
        var o, a;
        t.headers = Object.assign(En(window.UserLeap), t.headers);
        const i = await je(e, t, n, r);
        if (i.ok) {
            const s = (o = i.headers) == null ? void 0 : o.get("Authorization"),
                l = s ? s.split(" ") : void 0,
                u = l && l.length === 2 ? l[1] : void 0,
                c = (a = i.headers) == null ? void 0 : a.get(Ne.VisitorID);
            u && c && (c !== window.UserLeap.visitorId || window.UserLeap.token !== u) && (be("token", u), be("vid", c), q.emit(K.VisitorIDUpdated, {
                visitorId: c
            }), window.UserLeap.token = u, window.UserLeap.visitorId = c)
        }
        return i.json && i.json.logMessage && console.warn(`[Sprig] ${i.json.logMessage}`), i
    }
    async function ag(e) {
        var t;
        !((t = e == null ? void 0 : e.json) != null && t.delay) || (window.UserLeap.delayingSurvey = !0, await ur(e.json.delay), window.UserLeap.delayingSurvey = !1)
    }
    const sg = function(e) {
        if (!window.UserLeap) return;
        const t = async (r = {}) => {
                var h, v, m, y, _;
                const {
                    userId: i,
                    anonymousId: o,
                    metadata: a = {},
                    properties: s,
                    showSurveyCallback: l
                } = r;
                let {
                    eventName: u
                } = r;
                if (window.UserLeap.debugMode && u !== ta && console.info("[DEBUG] Sprig track", r), e.mode === "test") return;
                const c = window.UserLeap.localStorageAvailable && (h = localStorage.getItem(ge.Preview)) != null ? h : void 0;
                if (e.requireUserIdForTracking && !window.UserLeap.userId && !i) {
                    const E = "[Sprig] - Skipping tracking without userId";
                    return console.warn(E), {
                        success: !1,
                        message: E,
                        surveyState: "no survey"
                    }
                }
                if (!u || u.trim().length === 0) {
                    u = u ? String(u) : "";
                    const E = "[Sprig] - Invalid event name " + u;
                    return console.warn(E), {
                        success: !1,
                        message: E,
                        surveyState: "no survey"
                    }
                }
                const f = window.location.href;
                if (a.url || (a.url = f), be("trackStartUrl", f), (m = (v = window.UserLeap) == null ? void 0 : v._config) != null && m.optimizelyEnabled) {
                    const E = En(window.UserLeap);
                    oa(E) || Jr.getAndSetWebOptimizelyExperiments(), a.optimizelyExperiments = Object.assign({}, Jr.getAllOptimizelyExperiments())
                }(_ = (y = window.UserLeap) == null ? void 0 : y._config) != null && _.launchDarklyEnabled && (a.launchDarklyFlags = ea.getAllLaunchDarklyVariations()), i && (window.UserLeap.userId = i), o && (window.UserLeap.partnerAnonymousId = o), s && (a.eventProperties = s);
                const d = window.UserLeap.delayingSurvey ? await xt(Ge("1", [Ht], "events/batch"), {
                    body: JSON.stringify({
                        events: [{
                            event: u,
                            metadata: a
                        }],
                        previewKey: c
                    }),
                    method: "POST"
                }, 0, !0) : await xt(Ge("1", [Ht], "events"), {
                    body: JSON.stringify({
                        event: u,
                        metadata: a,
                        previewKey: c
                    }),
                    method: "POST"
                }, 0, !0);
                if (!d.ok) {
                    const E = "[Sprig] (ERR-421) Failed to track event";
                    return d.reportError && (console.warn(E, d.error), d.error && window.UserLeap.reportError("track", d.error)), {
                        success: !1,
                        message: E,
                        error: d.error,
                        surveyState: "no survey"
                    }
                }
                i && be("uid", i), o && be("aid", o);
                const p = d.json;
                return p.invalidPreviewKey && window.UserLeap.localStorageAvailable && localStorage.removeItem(ge.Preview), await ag(d), Ym(p.eventId, f) ? fc(p, l) : {
                    success: !1,
                    message: "Study should not be displayed after page navigation",
                    surveyState: "no survey"
                }
            },
            n = {
                async displaySurvey(r) {
                    return console.warn("[Sprig] displaySurvey should only be used to debug your studies; not intended for production usage."), window.UserLeap("dismissActiveSurvey", Ye.Override), ia({
                        surveyId: r
                    }, !0)
                },
                _previewSurvey(r) {
                    window.UserLeap("dismissActiveSurvey", Ye.Override), ia({
                        surveyTemplateId: r
                    }, !1)
                },
                _reviewSurvey(r) {
                    window.UserLeap("dismissActiveSurvey", Ye.Override), ia({
                        surveyId: r
                    }, !1)
                },
                previewSurvey(r) {
                    n._previewSurvey(r)
                },
                reviewSurvey(r) {
                    n._reviewSurvey(r)
                },
                mute() {
                    window.UserLeap._queue.pause()
                },
                unmute() {
                    window.UserLeap._queue.unpause()
                },
                setVisitorToken() {
                    console.warn("[Sprig] setVisitorToken is deprecated.")
                },
                dismissActiveSurvey(r = Ye.API) {
                    q.emit(K.SurveyWillClose, {
                        name: K.SurveyWillClose,
                        initiator: r
                    })
                },
                async setAttribute(r, i) {
                    if (!r || !i && i !== 0) {
                        const o = "[Sprig] - Disregarding empty attribute / value provided";
                        return console.warn(o), {
                            success: !1,
                            message: o
                        }
                    }
                    return this.setAttributes({
                        [r]: i
                    })
                },
                async setAttributes(r) {
                    if (r == null || Object.keys(r).length === 0) {
                        const i = "[Sprig] - Disregarding empty attributes provided";
                        return console.warn(i), {
                            success: !1,
                            message: i
                        }
                    }
                    return this.identifyAndSetAttributes({
                        attributes: r
                    })
                },
                async identifyAndSetAttributes(r) {
                    if (window.UserLeap.debugMode && console.info("[DEBUG] Sprig identifyAndSetAttributes", r), e.mode === "test") return;
                    if (r === null || typeof r != "object" || !(r.userId || r.anonymousId || r.attributes)) {
                        const u = "[Sprig] - Disregarding empty payload provided";
                        return console.warn(u), {
                            success: !1,
                            message: u
                        }
                    }
                    const {
                        userId: i,
                        anonymousId: o,
                        attributes: a
                    } = r;
                    if (e.requireUserIdForTracking && !window.UserLeap.userId && !i) {
                        const u = "[Sprig] - Skipping tracking without userId";
                        return console.warn(u), {
                            success: !1,
                            message: u
                        }
                    }
                    if (!a && (!i || window.UserLeap.userId === i) && (!o || window.UserLeap.partnerAnonymousId === o)) return {
                        success: !0
                    };
                    const s = {};
                    i && (s.userId = window.UserLeap.userId = i), o && (s.partnerAnonymousId = window.UserLeap.partnerAnonymousId = o);
                    let l;
                    return a ? (a.email && !Object.prototype.hasOwnProperty.call(a, Wn) && (a[Wn] = a.email, delete a.email), l = await xt(Ge("1", [Et, Ht], "attributes"), {
                        body: JSON.stringify(a),
                        method: "PUT"
                    }), !l.ok && l.reportError && (console.warn("[Sprig] (ERR-432) identifyAndSetAttributes failed", l.error), l.error && window.UserLeap.reportError("identifyAndSetAttributes", l.error))) : l = await xt(Ge("1", [Et, Ht]), {
                        body: JSON.stringify(s),
                        method: "PUT"
                    }), a && a[Wn] && (window.UserLeap.email = a[Wn]), l.ok && (i && be("uid", i), o && be("aid", o)), {
                        success: !!l.ok
                    }
                },
                async removeAttributes(r) {
                    if (window.UserLeap.debugMode && console.info("[DEBUG] Sprig removeAttributes", r), e.mode === "test") return;
                    if (r == null || r.length === 0) {
                        const o = "[Sprig] - Disregarding empty attributes provided";
                        return console.warn(o), {
                            success: !1,
                            message: o
                        }
                    }
                    if (e.requireUserIdForTracking && !window.UserLeap.userId) {
                        const o = "[Sprig] - Skipping tracking without userId";
                        return console.warn(o), {
                            success: !1,
                            message: o
                        }
                    }
                    const i = await xt(Ge("1", [Et, Ht], "attributes"), {
                        body: JSON.stringify({
                            delete: r
                        }),
                        method: "DELETE"
                    });
                    return !i.ok && i.reportError && (console.warn("[Sprig] (ERR-433) Remove attributes failed", i.error), i.error && window.UserLeap.reportError("removeAttributes", i.error)), {
                        success: !!i.ok
                    }
                },
                async addSurveyListener(r) {
                    q.on(K.SurveyLifeCycle, r)
                },
                async removeSurveyListener(r) {
                    q.removeListener(K.SurveyLifeCycle, r)
                },
                async addListener(r, i) {
                    q.on(r, i)
                },
                async removeListener(r, i) {
                    q.removeListener(r, i)
                },
                async removeAllListeners() {
                    q.removeAllListeners()
                },
                setVisitorAttribute(r, i) {
                    return console.warn("[Sprig] setVisitorAttribute is deprecated. Please use setAttribute"), n.setAttribute(r, i)
                },
                async setEmail(r) {
                    return n.setAttribute(Wn, r)
                },
                async setVisitorEmail(r) {
                    return console.warn("[Sprig] setVisitorEmail is deprecated. Please use setEmail"), n.setEmail(r)
                },
                async setUserId(r) {
                    if (window.UserLeap.debugMode && console.info("[DEBUG] Sprig setUserId", r), r == null) {
                        const a = `[Sprig] - Invalid userId ${r}`;
                        return console.warn(a), {
                            success: !1,
                            message: a
                        }
                    }
                    if (e.mode === "test" || r === window.UserLeap.userId) return;
                    window.UserLeap.userId = r;
                    const i = window.UserLeap.visitorId,
                        o = await xt(Ge("1", [Et, Ht]), {
                            body: JSON.stringify({
                                userId: r
                            }),
                            method: "PUT"
                        });
                    if (!o.ok) {
                        o.reportError && (console.warn("[Sprig] (ERR-420) Failed to set user id", o.error), o.error && window.UserLeap.reportError("setUserId", o.error));
                        return
                    }
                    i !== window.UserLeap.visitorId && el(), be("uid", r)
                },
                async setPartnerAnonymousId(r) {
                    if (window.UserLeap.debugMode && console.info("[DEBUG] Sprig setPartnerAnonymousId", r), r == null) {
                        const i = `[Sprig] - Invalid partnerAnonymousId ${r}`;
                        return console.warn(i), {
                            success: !1,
                            message: i
                        }
                    }
                    return window.UserLeap.partnerAnonymousId = r, be("aid", r), {
                        success: !0
                    }
                },
                async track(r, i, o = {}, a = void 0) {
                    return t({
                        eventName: r,
                        properties: i,
                        metadata: o,
                        showSurveyCallback: a
                    })
                },
                async identifyAndTrack(r) {
                    return await t(r)
                },
                applyStyles(r) {
                    if (window.UserLeap.customStyles = r, window.UserLeap.container) {
                        const i = window.UserLeap.container.children[0].contentDocument;
                        if (i) {
                            const o = i.getElementById(A.CustomStyle);
                            o ? o.textContent = r : Ga(i, r, window.UserLeap.styleNonce)
                        }
                    }
                },
                setWindowDimensions(r, i) {
                    var l, u;
                    const o = typeof r == "string" ? parseInt(r, 10) : r,
                        a = typeof i == "string" ? parseInt(i, 10) : i;
                    if (!isNaN(o) && !isNaN(a) && (window.UserLeap.windowDimensions = {
                            width: o,
                            height: a
                        }), !window.UserLeap.frameId) return;
                    const s = document.getElementById(window.UserLeap.frameId);
                    !s || (window.UserLeap.useMobileStyling && ((l = window.UserLeap.windowDimensions) != null && l.width && (s.style.width = `${window.UserLeap.windowDimensions.width}px`), (u = window.UserLeap.windowDimensions) != null && u.height && (s.style.maxHeight = `${window.UserLeap.windowDimensions.height-20}px`), s.contentDocument && (s.style.height = String(qa(s.contentDocument)) + "px")), q.emit(K.SurveyDimensions, {
                        name: K.SurveyDimensions,
                        contentFrameWidth: s.clientWidth,
                        contentFrameHeight: s.clientHeight
                    }))
                },
                logoutUser() {
                    window.UserLeap.debugMode && console.info("[DEBUG] Sprig logout"), window.UserLeap.visitorId = null, window.UserLeap.userId = null, window.UserLeap.partnerAnonymousId = null, window.UserLeap.token = null, window.UserLeap.email = null, window.UserLeap.localStorageAvailable && (localStorage.removeItem(ge.Credentials), localStorage.removeItem(ge.PageViews)), window.UserLeap._queue.isPaused() && window.UserLeap._queue.empty(), dc(), el(), window.UserLeap._queue.unpause()
                },
                teardown() {
                    Xm(), window.UserLeap("dismissActiveSurvey", Ye.API), delete window.UserLeap, delete window.Sprig, delete window._Sprig
                },
                integrateOptimizely(r, i = !0) {
                    var o, a;
                    if (!((a = (o = window.UserLeap) == null ? void 0 : o._config) != null && a.optimizelyEnabled)) {
                        console.warn("[SPRIG] Optimizely integration is currently not enabled for your product.");
                        return
                    }
                    try {
                        const s = typeof r == "string" ? JSON.parse(r) : r;
                        Jr.setOptimizelyExperiment(s, i)
                    } catch (s) {
                        console.warn("[Sprig] Error with integrating Optimizely data"), s instanceof Error && window.UserLeap.reportError("integrateOptimizely", s)
                    }
                },
                integrateOptimizelyClient(r) {
                    var o, a;
                    if (!((a = (o = window.UserLeap) == null ? void 0 : o._config) != null && a.optimizelyEnabled)) {
                        console.warn("[SPRIG] Optimizely integration is currently not enabled for your product.");
                        return
                    }
                    const i = ({
                        experiment: s,
                        variation: l
                    }) => {
                        const u = {
                            experiments: [{
                                id: s.id,
                                variation: l.key
                            }]
                        };
                        window.UserLeap("integrateOptimizely", u, !1)
                    };
                    r.notificationCenter.addNotificationListener(cf.NOTIFICATION_TYPES.ACTIVATE, i)
                },
                importLaunchDarklyData(r) {
                    var i, o;
                    if (!((o = (i = window.UserLeap) == null ? void 0 : i._config) != null && o.launchDarklyEnabled)) {
                        console.warn("[SPRIG] LaunchDarkly integration is currently not enabled for your product.");
                        return
                    }
                    ea.setLDFlagsVariations(r)
                }
            };
        Object.assign(window.UserLeap, n)
    };
    async function lg(e) {
        const t = En(window.UserLeap);
        let n = await je(Ge("1", [Et], "config"), {
            headers: t
        });
        const r = "TypeError";
        if (window.UserLeap.error = n.error, !n.ok && n.error && n.error.name === r && (window.UserLeap._API_URL = "https://api.sprig.com", window.UserLeap.reportError("sprigDomainRequest", n.error), n = await je(Ge("1", [Et], "config"), {
                headers: t
            })), !n.ok) return n.reportError && (console.warn("[Sprig] (ERR-422) Failed to load configuration", n.error), n.error && window.UserLeap.reportError("applyRemoteConfig", n.error)), Ii("Disabled: failed to fetch configuration"), e;
        const i = n.json;
        return i != null && i.disabled ? (Ii(`Disabled: ${i.disabled}`), {
            disabled: i.disabled
        }) : Object.assign({}, i, e)
    }
    async function ug(e, t, n = {}) {
        const r = window.__cfg && window.__cfg.mode,
            i = ra(),
            o = window.UserLeap.envId,
            a = window.document.documentElement,
            s = {
                mode: r,
                screenWidth: window.screen.width,
                screenHeight: window.screen.height,
                clientWidth: a.clientWidth,
                clientHeight: a.clientHeight,
                location: window.location.href,
                language: window.navigator.language,
                ...n
            },
            l = {
                action: e,
                err: {
                    message: t.message,
                    stack: t.stack
                },
                meta: s,
                vid: i,
                envId: o
            };
        (await xt(Ge("1", null, "errors"), {
            method: "POST",
            headers: {
                [Ne.Error]: window.btoa(`userleap-${Date.now()}-error`)
            },
            body: JSON.stringify(l)
        }, 0, !0)).ok || console.warn("[Sprig] (ERR-444) Failed to report error to API", t)
    }

    function cg(e = {}) {
        const t = new URLSearchParams(window.location.search).get("sprigPreviewKey"),
            n = eg();
        window.UserLeap.localStorageAvailable = n, n && t && localStorage.setItem(ge.Preview, t), window.UserLeap.UPDATES = Ha;
        async function r() {
            if (window.UserLeap.loaded) return;
            if (window.UserLeap.reportError = ug, window.UserLeap.loaded = !0, window.UserLeap._config = Object.assign({}, e, window.UserLeap.config), window.UserLeap.delayingSurvey = !1, window.UserLeap._config && typeof window.UserLeap._config == "object")
                for (const l in window.UserLeap._config) window.UserLeap[l] = window.UserLeap._config[l];
            if (!window.UserLeap.envId)
                if (window.UserLeap.appId) window.UserLeap.envId = window.UserLeap.appId;
                else throw new Error("Missing Environment id");
            window.UserLeap.debugMode && console.info("[DEBUG] Sprig debug mode enabled");
            const i = window.UserLeap.sampleRate;
            if (i)
                if (!n) window.UserLeap.debugMode && console.info("[DEBUG] Sprig cannot sample users without localStorage permissions");
                else {
                    let l = Kt("sampled");
                    if (l === null && (l = Math.random() < i, be("sampled", l)), !l) return
                }
            else n && Kt("sampled") !== null && be("sampled", null);
            window.UserLeap._API_URL || (window.UserLeap._API_URL = "https://api.sprig.com");
            const o = [...window.UserLeap._queue];
            window.UserLeap._queue = new Gm(window.UserLeap, []), window.UserLeap._queue.pause();
            for (let l = 0; l < o.length; l++) window.UserLeap._queue.push(o[l]);
            const a = Kt("token");
            a ? (window.UserLeap.token = a, window.UserLeap.visitorId = Kt("vid"), window.UserLeap.userId = Kt("uid"), window.UserLeap.partnerAnonymousId = Kt("aid")) : (window.UserLeap.localStorageAvailable && localStorage.removeItem(ge.Credentials), dc());
            const s = await lg(e);
            bh(window.document, s.maxReplayDurationSeconds, window.UserLeap.replayNonce, window.UserLeap.maxInflightReplayRequests, s.replaySettings), sg(s), await og(s), window.UserLeap._queue.unpause(), q.emit(K.SDKReady), q.emit(K.VisitorIDUpdated, {
                visitorId: window.UserLeap.visitorId
            })
        }
        document.readyState === "complete" ? r() : window.attachEvent ? window.attachEvent("onload", r) : window.addEventListener("load", r, !1)
    }
    const dg = "sprig-web-view-sdk";
    let pc;
    pc = {
        path: `https://cdn.sprig.com/${dg}-v2.24.1.js`
    }, cg(pc)
});